#!/bin/bash
# ============================================================
# 🇮🇳 "हिंदी के पंडित" — Hostinger VPS पर Deploy करने की पूरी गाइड
# ============================================================
#
# ✅ इस फ़ाइल को अपने लैपटॉप पर save करें
# ✅ Terminal/Command Prompt खोलें
# ✅ एक-एक कमांड कॉपी-पेस्ट करके चलाएं
#
# ⏱️ Total Time: ~30 minutes
# 💰 Total Cost: ₹149/month (VPS) + ₹700/year (Domain) = ~₹860/साल
#
# ============================================================


# ============================================================
# PHASE 1: डोमेन खरीदें (15 minutes)
# ============================================================
# 1. hostinger.in पर जाएं
# 2. Domain Search में "hindikepandit.com" टाइप करें
# 3. Domain खरीदें (~₹700/साल)
# 4. VPS Hosting खरीदें (KVM 1 Plan - ₹149/महीना)
#    → OS: Ubuntu 22.04 LTS चुनें
# 5. ईमेल में आए credentials सुरक्षित रखें:
#    - Server IP Address: ___________
#    - Root Password: ___________


# ============================================================
# PHASE 2: GitHub पर कोड Upload करें (10 minutes)
# ============================================================
# ---- अपने लैपटॉप पर ये commands चलाएं ----

# 1. GitHub पर नया Repository बनाएं:
#    → github.com खोलें
#    → "+" → "New Repository"
#    → Name: hindi-ke-pandit
#    → Public चुनें
#    → "Create Repository" क्लिक करें

# 2. अपने project folder में जाएं:
cd /path/to/your/project

# 3. Git initialize और push करें:
git init
git add .
git commit -m "हिंदी के पंडित - पहला version"
git branch -M main
git remote add origin https://github.com/YOUR_USERNAME/hindi-ke-pandit.git
git push -u origin main
# (YOUR_USERNAME जगह अपना GitHub username डालें)


# ============================================================
# PHASE 3: VPS सर्वर Setup करें (15 minutes)
# ============================================================
# ---- अपने लैपटॉप Terminal से SSH करें ----

# 1. SSH से सर्वर से कनेक्ट हों:
ssh root@YOUR_SERVER_IP
# (YOUR_SERVER_IP जगह अपना server IP डालें, password डालें)

# 2. सिस्टम अपडेट करें:
apt update && apt upgrade -y

# 3. Node.js 20 इंस्टॉल करें:
curl -fsSL https://deb.nodesource.com/setup_20.x | bash -
apt install -y nodejs
node -v    # v20.x.x दिखना चाहिए
npm -v     # 10.x.x दिखना चाहिए

# 4. Bun (JavaScript runtime) इंस्टॉल करें:
curl -fsSL https://bun.sh/install | bash
source ~/.bashrc
bun -v     # 1.x.x दिखना चाहिए

# 5. PM2 इंस्टॉल करें (ये आपकी website को 24/7 चलाएगा):
npm install -g pm2

# 6. Nginx इंस्टॉल करें (Web Server / Reverse Proxy):
apt install -y nginx
systemctl start nginx
systemctl enable nginx

# 7. Git इंस्टॉल करें:
apt install -y git


# ============================================================
# PHASE 4: वेबसाइट कोड Upload + Setup (10 minutes)
# ============================================================
# ---- VPS पर (SSH में) ये commands चलाएं ----

# 1. Project folder बनाएं:
mkdir -p /var/www/hindikepandit
cd /var/www/hindikepandit

# 2. GitHub से कोड clone करें:
git clone https://github.com/YOUR_USERNAME/hindi-ke-pandit.git .

# 3. Dependencies इंस्टॉल करें:
bun install

# 4. Database Setup:
export DATABASE_URL="file:/var/www/hindikepandit/db/custom.db"
npx prisma generate
npx prisma db push

# 5. Seed Data डालें (sample articles):
npx prisma db seed

# 6. Production Build करें:
bun run build

# 7. PM2 से चलाएं (24/7 चलेगा):
pm2 start "DATABASE_URL=file:/var/www/hindikepandit/db/custom.db bun run start" --name "hindi-ke-pandit"
pm2 save
pm2 startup    # Enter करें जो command दिखे वो copy-paste करें


# ============================================================
# PHASE 5: Nginx Configure करें (5 minutes)
# ============================================================
# ---- VPS पर (SSH में) ये commands चलाएं ----

# 1. Nginx config फ़ाइल बनाएं:
nano /etc/nginx/sites-available/hindikepandit
# (नीचे वाला कोड पेस्ट करें — YOUR_SERVER_IP जगह अपना IP डालें)

# ---- नीचे वाला कोड nano editor में paste करें ----
# server {
#     listen 80;
#     server_name hindikepandit.com www.hindikepandit.com YOUR_SERVER_IP;
#
#     location / {
#         proxy_pass http://localhost:3000;
#         proxy_http_version 1.1;
#         proxy_set_header Upgrade $http_upgrade;
#         proxy_set_header Connection 'upgrade';
#         proxy_set_header Host $host;
#         proxy_set_header X-Real-IP $remote_addr;
#         proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
#         proxy_set_header X-Forwarded-Proto $scheme;
#         proxy_cache_bypass $http_upgrade;
#     }
#
#     # Static files caching
#     location /_next/static {
#         proxy_pass http://localhost:3000;
#         proxy_cache_valid 200 365d;
#         add_header Cache-Control "public, immutable";
#     }
# }
# ---- paste करने के बाद: Ctrl+X → Y → Enter ----

# 2. Config Enable करें:
ln -s /etc/nginx/sites-available/hindikepandit /etc/nginx/sites-enabled/
rm -f /etc/nginx/sites-enabled/default    # default हटाएं

# 3. Test और Restart:
nginx -t           # "syntax is ok" दिखना चाहिए
systemctl restart nginx


# ============================================================
# PHASE 6: DNS Setup (Domain को Server से जोड़ें)
# ============================================================
# ---- Hostinger Dashboard पर जाएं → Domains → DNS ----

# DNS Records (ये 3 records add करें):

# Type    Name       Value                    TTL
# ----    ----       -----                    ----
# A       @          YOUR_SERVER_IP           3600
# A       www        YOUR_SERVER_IP           3600
# CNAME   *          hindikepandit.com        3600

# ⏳ DNS Propagate होने में 10-30 minutes लग सकते हैं
# Check: https://dnschecker.org पर अपना डोमेन डालें


# ============================================================
# PHASE 7: SSL Certificate (HTTPS) लगाएं (2 minutes)
# ============================================================
# ---- VPS पर (SSH में) ये commands चलाएं ----
# (DNS propagate होने के बाद करें)

apt install -y certbot python3-certbot-nginx
certbot --nginx -d hindikepandit.com -d www.hindikepandit.com
# Email डालें, Y → 2 → Y


# ============================================================
# PHASE 8: Firewall Setup (Security)
# ============================================================
# ---- VPS पर (SSH में) ये commands चलाएं ----

ufw allow 22     # SSH
ufw allow 80     # HTTP
ufw allow 443    # HTTPS
ufw --force enable
ufw status


# ============================================================
# ✅ DONE! आपकी वेबसाइट लाइव है!
# ============================================================
# अब browser में https://hindikepandit.com खोलें
#
# 🎉 Congratulations!


# ============================================================
# 📋 Daily Use Commands (आपको बार-बार ज़रूरत पड़ेगी)
# ============================================================

# वेबसाइट का Status देखें:
pm2 status

# वेबसाइट Restart करें (अगर code update किया हो):
cd /var/www/hindikepandit
git pull origin main
bun install
bun run build
pm2 restart hindi-ke-pandit

# Logs देखें:
pm2 logs hindi-ke-pandit

# Nginx Restart:
systemctl restart nginx

# SSL Renew (हर 3 months):
certbot renew

# Database Backup लें:
cp /var/www/hindikepandit/db/custom.db /var/www/hindikepandit/db/backup-$(date +%Y%m%d).db
