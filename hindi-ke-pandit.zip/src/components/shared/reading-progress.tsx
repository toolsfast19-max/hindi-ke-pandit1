'use client'

import React, { useCallback, useEffect, useRef, useState } from 'react'
import { useAppStore } from '@/store'

export function ReadingProgress() {
  const { currentPage } = useAppStore()
  const [progress, setProgress] = useState(0)
  const isPostPage = currentPage === 'post'

  const handleScroll = useCallback(() => {
    const scrollTop = window.scrollY
    const docHeight = document.documentElement.scrollHeight - window.innerHeight
    if (docHeight <= 0) {
      setProgress(100)
      return
    }
    const scrollPercent = (scrollTop / docHeight) * 100
    setProgress(Math.min(scrollPercent, 100))
  }, [])

  useEffect(() => {
    if (!isPostPage) return

    const handleInitialScroll = () => {
      requestAnimationFrame(handleScroll)
    }

    window.addEventListener('scroll', handleScroll, { passive: true })
    handleInitialScroll()

    return () => {
      window.removeEventListener('scroll', handleScroll)
    }
  }, [isPostPage, handleScroll])

  // Reset progress to 0 when leaving post page (outside effect)
  const displayProgress = isPostPage ? progress : 0

  if (!isPostPage) return null

  return (
    <div className="fixed top-0 left-0 z-50 h-[3px] w-full bg-transparent">
      <div
        className="h-full bg-gradient-to-r from-emerald-500 via-teal-500 to-cyan-500 transition-[width] duration-150 ease-out"
        style={{ width: `${displayProgress}%` }}
      />
    </div>
  )
}
