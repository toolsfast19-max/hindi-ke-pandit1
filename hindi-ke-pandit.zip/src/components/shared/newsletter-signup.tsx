'use client'

import React, { useState } from 'react'
import { BookOpen, Mail, Send, CheckCircle2, Loader2 } from 'lucide-react'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { toast } from 'sonner'

export function NewsletterSignup() {
  const [email, setEmail] = useState('')
  const [loading, setLoading] = useState(false)
  const [subscribed, setSubscribed] = useState(false)

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    if (!email || subscribed) return

    setLoading(true)
    try {
      const res = await fetch('/api/newsletter', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ email }),
      })
      if (res.ok) {
        setSubscribed(true)
        toast.success('सब्सक्रिप्शन सफल! 🎉', {
          description: 'आपने सफलतापूर्वक न्यूज़लेटर सब्सक्राइब कर लिया।',
        })
      } else {
        const data = await res.json()
        toast.error('त्रुटि', {
          description: data.error || 'कृपया बाद में पुनः प्रयास करें।',
        })
      }
    } catch {
      toast.error('त्रुटि', {
        description: 'नेटवर्क त्रुटि। कृपया बाद में पुनः प्रयास करें।',
      })
    } finally {
      setLoading(false)
    }
  }

  if (subscribed) {
    return (
      <div className="relative overflow-hidden rounded-2xl bg-gradient-to-br from-emerald-600 via-teal-600 to-cyan-600 p-6 text-white sm:p-8">
        <div className="absolute inset-0 bg-[url('data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iMjAwIiBoZWlnaHQ9IjIwMCIgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIj48ZGVmcz48cGF0dGVybiBpZD0iYSIgcGF0dGVyblVuaXRzPSJ1c2VyU3BhY2VPblVzZSIgd2lkdGg9IjQwIiBoZWlnaHQ9IjQwIiBwYXR0ZXJuVHJhbnNmb3JtPSJyb3RhdGUoNDUpIj48cGF0aCBkPSJNLTEwIDMwaDYwIiBzdHJva2U9InJnYmEoMjU1LDI1NSwyNTUsMC4xKSIgc3Ryb2tlLXdpZHRoPSIxIi8+PC9wYXR0ZXJuPjwvZGVmcz48cmVjdCBmaWxsPSJ1cmwoI2EpIiB3aWR0aD0iMTAwJSIgaGVpZ2h0PSIxMDAlIi8+PC9zdmc+')] opacity-40" />
        <div className="relative flex flex-col items-center gap-4 text-center">
          <div className="flex h-16 w-16 items-center justify-center rounded-full bg-white/20">
            <CheckCircle2 className="h-8 w-8" />
          </div>
          <h3 className="text-xl font-bold sm:text-2xl">
            सब्सक्रिप्शन सफल! 🎉
          </h3>
          <p className="text-sm text-white/80">
            आपने सफलतापूर्वक हिंदी के पंडित न्यूज़लेटर सब्सक्राइब कर लिया है। अब आपको
            नवीनतम लेख सीधे अपने ईमेल में मिलेंगे।
          </p>
        </div>
      </div>
    )
  }

  return (
    <div className="relative overflow-hidden rounded-2xl bg-gradient-to-br from-emerald-600 via-teal-600 to-cyan-600 p-6 text-white sm:p-8">
      {/* Decorative Background */}
      <div className="absolute inset-0 bg-[url('data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iMjAwIiBoZWlnaHQ9IjIwMCIgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIj48ZGVmcz48cGF0dGVybiBpZD0iYSIgcGF0dGVyblVuaXRzPSJ1c2VyU3BhY2VPblVzZSIgd2lkdGg9IjQwIiBoZWlnaHQ9IjQwIiBwYXR0ZXJuVHJhbnNmb3JtPSJyb3RhdGUoNDUpIj48cGF0aCBkPSJNLTEwIDMwaDYwIiBzdHJva2U9InJnYmEoMjU1LDI1NSwyNTUsMC4xKSIgc3Ryb2tlLXdpZHRoPSIxIi8+PC9wYXR0ZXJuPjwvZGVmcz48cmVjdCBmaWxsPSJ1cmwoI2EpIiB3aWR0aD0iMTAwJSIgaGVpZ2h0PSIxMDAlIi8+PC9zdmc+')] opacity-40" />
      <div className="absolute -right-8 -top-8 h-32 w-32 rounded-full bg-white/10" />
      <div className="absolute -bottom-6 -left-6 h-24 w-24 rounded-full bg-white/10" />

      <div className="relative flex flex-col items-center gap-5 text-center">
        <div className="flex h-12 w-12 items-center justify-center rounded-xl bg-white/20">
          <BookOpen className="h-6 w-6" />
        </div>
        <div className="space-y-2">
          <h3 className="text-xl font-bold sm:text-2xl">
            हिंदी के पंडित न्यूज़लेटर
          </h3>
          <p className="text-sm text-white/80">
            नवीनतम लेख सीधे अपने ईमेल में पाएं
          </p>
        </div>

        <form
          onSubmit={handleSubmit}
          className="flex w-full max-w-md flex-col gap-3 sm:flex-row"
        >
          <div className="relative flex-1">
            <Mail className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-white/50" />
            <Input
              type="email"
              placeholder="अपना ईमेल दर्ज करें"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              required
              className="h-11 border-white/20 bg-white/10 pl-10 text-white placeholder:text-white/50 focus-visible:border-white/40 focus-visible:ring-white/20"
            />
          </div>
          <Button
            type="submit"
            disabled={loading || !email}
            className="h-11 bg-white px-6 font-semibold text-emerald-700 shadow-lg hover:bg-white/90"
          >
            {loading ? (
              <Loader2 className="h-4 w-4 animate-spin" />
            ) : (
              <>
                <Send className="h-4 w-4" />
                सब्सक्राइब
              </>
            )}
          </Button>
        </form>
        <p className="text-xs text-white/60">
          हम आपके ईमेल को सुरक्षित रखेंगे। कभी स्पैम नहीं।
        </p>
      </div>
    </div>
  )
}
