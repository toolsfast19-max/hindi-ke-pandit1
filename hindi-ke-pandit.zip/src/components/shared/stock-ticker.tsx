'use client'

import React from 'react'
import { TrendingUp, TrendingDown, Minus } from 'lucide-react'

interface StockItem {
  name: string
  value: string
  change: number
  changePercent: string
}

const stockData: StockItem[] = [
  { name: 'NIFTY 50', value: '22,147.30', change: 124.50, changePercent: '+0.56%' },
  { name: 'SENSEX', value: '72,765.80', change: -89.20, changePercent: '-0.12%' },
  { name: 'RELIANCE', value: '2,894.55', change: 34.15, changePercent: '+1.19%' },
  { name: 'TCS', value: '3,876.20', change: -12.40, changePercent: '-0.32%' },
  { name: 'HDFC BANK', value: '1,642.30', change: 18.75, changePercent: '+1.15%' },
  { name: 'INFOSYS', value: '1,523.80', change: 8.90, changePercent: '+0.59%' },
  { name: 'BAJAJ FINANCE', value: '6,789.45', change: -56.30, changePercent: '-0.82%' },
  { name: 'ICICI BANK', value: '1,123.60', change: 15.20, changePercent: '+1.37%' },
]

export function StockTicker() {
  const doubledData = [...stockData, ...stockData]

  return (
    <div className="w-full overflow-hidden border-b bg-muted/50 py-2">
      <div className="ticker-animation flex items-center gap-6">
        {doubledData.map((stock, index) => {
          const isPositive = stock.change > 0
          const isNegative = stock.change < 0

          return (
            <div
              key={`${stock.name}-${index}`}
              className="flex shrink-0 items-center gap-2 rounded-md border bg-card px-3 py-1.5 shadow-sm"
            >
              <span className="whitespace-nowrap text-xs font-semibold text-foreground">
                {stock.name}
              </span>
              <span className="whitespace-nowrap text-xs font-medium text-muted-foreground">
                ₹{stock.value}
              </span>
              <span
                className={`flex items-center gap-0.5 whitespace-nowrap text-xs font-bold ${
                  isPositive
                    ? 'text-green-600 dark:text-green-400'
                    : isNegative
                      ? 'text-red-600 dark:text-red-400'
                      : 'text-yellow-600 dark:text-yellow-400'
                }`}
              >
                {isPositive ? (
                  <TrendingUp className="h-3 w-3" />
                ) : isNegative ? (
                  <TrendingDown className="h-3 w-3" />
                ) : (
                  <Minus className="h-3 w-3" />
                )}
                {stock.changePercent}
              </span>
            </div>
          )
        })}
      </div>
    </div>
  )
}
