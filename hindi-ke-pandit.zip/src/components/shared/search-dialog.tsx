'use client'

import React, { useEffect, useState, useCallback } from 'react'
import {
  Search,
  FileText,
  TrendingUp,
  Wheat,
  Cpu,
  Loader2,
} from 'lucide-react'
import {
  CommandDialog,
  CommandInput,
  CommandList,
  CommandEmpty,
  CommandGroup,
  CommandItem,
} from '@/components/ui/command'
import { useAppStore } from '@/store'
import type { Post } from '@/lib/types'

const categoryIcons: Record<string, React.ElementType> = {
  TrendingUp,
  Wheat,
  Cpu,
}

const categoryColors: Record<string, string> = {
  'share-market': '#16a34a',
  krishi: '#ca8a04',
  technology: '#0891b2',
}

const categoryIconNames: Record<string, string> = {
  'share-market': 'TrendingUp',
  krishi: 'Wheat',
  technology: 'Cpu',
}

interface SearchResult {
  id: string
  title: string
  slug: string
  excerpt: string
  categoryName: string
  categorySlug: string
}

export function SearchDialog() {
  const { searchOpen, setSearchOpen, navigate } = useAppStore()
  const [query, setQuery] = useState('')
  const [results, setResults] = useState<SearchResult[]>([])
  const [loading, setLoading] = useState(false)

  useEffect(() => {
    if (!searchOpen) {
      setQuery('')
      setResults([])
    }
  }, [searchOpen])

  const fetchResults = useCallback(async (searchQuery: string) => {
    if (!searchQuery.trim()) {
      setResults([])
      return
    }

    setLoading(true)
    try {
      const res = await fetch(
        `/api/search?q=${encodeURIComponent(searchQuery.trim())}`
      )
      if (res.ok) {
        const data = await res.json()
        const mapped: SearchResult[] = (data.posts || []).map(
          (post: Post) => ({
            id: post.id,
            title: post.title,
            slug: post.slug,
            excerpt: post.excerpt,
            categoryName:
              post.category?.nameHindi ||
              post.category?.name ||
              'अन्य',
            categorySlug: post.category?.slug || 'other',
          })
        )
        setResults(mapped)
      } else {
        setResults([])
      }
    } catch {
      setResults([])
    } finally {
      setLoading(false)
    }
  }, [])

  useEffect(() => {
    const timer = setTimeout(() => {
      fetchResults(query)
    }, 300)

    return () => clearTimeout(timer)
  }, [query, fetchResults])

  const handleSelect = (slug: string) => {
    setSearchOpen(false)
    navigate('post', { slug })
  }

  return (
    <CommandDialog
      open={searchOpen}
      onOpenChange={setSearchOpen}
      title="लेख खोजें"
      description="कोई भी लेख खोजें..."
    >
      <CommandInput
        placeholder="लेख खोजें..."
        value={query}
        onValueChange={setQuery}
      />
      <CommandList>
        <CommandEmpty>
          {loading ? (
            <div className="flex items-center justify-center gap-2 py-6">
              <Loader2 className="h-4 w-4 animate-spin text-muted-foreground" />
              <span className="text-sm text-muted-foreground">
                खोज रहे हैं...
              </span>
            </div>
          ) : query.trim() ? (
            <div className="flex flex-col items-center gap-2 py-6">
              <Search className="h-8 w-8 text-muted-foreground/50" />
              <span className="text-sm text-muted-foreground">
                &quot;{query}&quot; के लिए कोई परिणाम नहीं मिला
              </span>
            </div>
          ) : (
            <span className="py-6 text-center text-sm text-muted-foreground">
              खोजने के लिए कुछ टाइप करें...
            </span>
          )}
        </CommandEmpty>

        {results.length > 0 && (
          <CommandGroup heading={`परिणाम (${results.length})`}>
            {results.map((result) => {
              const Icon =
                categoryIcons[categoryIconNames[result.categorySlug]] || FileText
              const color =
                categoryColors[result.categorySlug] || '#6b7280'

              return (
                <CommandItem
                  key={result.id}
                  value={result.title}
                  onSelect={() => handleSelect(result.slug)}
                  className="flex items-start gap-3 py-3"
                >
                  <div
                    className="mt-0.5 flex h-8 w-8 shrink-0 items-center justify-center rounded-lg"
                    style={{ backgroundColor: `${color}15` }}
                  >
                    <Icon
                      className="h-4 w-4"
                      style={{ color }}
                    />
                  </div>
                  <div className="flex flex-col gap-1 overflow-hidden">
                    <span className="text-sm font-medium leading-snug">
                      {result.title}
                    </span>
                    <div className="flex items-center gap-2">
                      <span
                        className="rounded-full px-2 py-0.5 text-[10px] font-medium text-white"
                        style={{ backgroundColor: color }}
                      >
                        {result.categoryName}
                      </span>
                      <span className="truncate text-xs text-muted-foreground">
                        {result.excerpt}
                      </span>
                    </div>
                  </div>
                </CommandItem>
              )
            })}
          </CommandGroup>
        )}
      </CommandList>
    </CommandDialog>
  )
}
