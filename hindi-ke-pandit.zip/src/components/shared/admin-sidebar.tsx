'use client'

import React, { useEffect, useState } from 'react'
import {
  LayoutDashboard,
  FileText,
  MessageSquare,
  Mail,
  Settings,
  LogOut,
  Shield,
  Users,
} from 'lucide-react'
import { Separator } from '@/components/ui/separator'
import { Badge } from '@/components/ui/badge'
import {
  Sheet,
  SheetContent,
  SheetHeader,
  SheetTitle,
  SheetDescription,
} from '@/components/ui/sheet'
import { useAppStore } from '@/store'

interface DashboardStats {
  subscribers: number
  messages: number
}

const adminLinks = [
  {
    label: 'डैशबोर्ड',
    description: 'साइट का अवलोकन',
    icon: LayoutDashboard,
    params: { section: 'dashboard' },
  },
  {
    label: 'पोस्ट प्रबंधन',
    description: 'लेख बनाएं और संपादित करें',
    icon: FileText,
    params: { section: 'posts' },
  },
  {
    label: 'टिप्पणियाँ',
    description: 'कमेंट्स की समीक्षा करें',
    icon: MessageSquare,
    params: { section: 'comments' },
  },
  {
    label: 'संपर्क संदेश',
    description: 'संदेश पढ़ें और जवाब दें',
    icon: Mail,
    params: { section: 'messages' },
    badge: 'messages' as const,
  },
  {
    label: 'सेटिंग्स',
    description: 'साइट सेटिंग्स प्रबंधित करें',
    icon: Settings,
    params: { section: 'settings' },
  },
]

export function AdminSidebar() {
  const { isAdminOpen, setAdminOpen, navigate } = useAppStore()
  const [stats, setStats] = useState<DashboardStats>({ subscribers: 0, messages: 0 })

  useEffect(() => {
    if (!isAdminOpen) return

    const fetchStats = async () => {
      try {
        const [subRes, msgRes] = await Promise.all([
          fetch('/api/dashboard').catch(() => null),
          fetch('/api/contact').catch(() => null),
        ])

        if (subRes?.ok) {
          const subData = await subRes.json()
          setStats((prev) => ({
            ...prev,
            subscribers: subData.subscribers ?? 0,
          }))
        }
        if (msgRes?.ok) {
          const msgData = await msgRes.json()
          setStats((prev) => ({
            ...prev,
            messages: msgData.unread ?? msgData.total ?? 0,
          }))
        }
      } catch {
        // Silently fail - stats will remain 0
      }
    }

    fetchStats()
  }, [isAdminOpen])

  const handleNavigate = (params: Record<string, string>) => {
    setAdminOpen(false)
    navigate('admin', params)
  }

  const handleClose = () => {
    setAdminOpen(false)
  }

  return (
    <Sheet open={isAdminOpen} onOpenChange={setAdminOpen}>
      <SheetContent side="right" className="w-80 overflow-y-auto">
        <SheetHeader className="pb-2">
          <SheetTitle className="flex items-center gap-2 text-lg">
            <Shield className="h-5 w-5 text-primary" />
            एडमिन पैनल
          </SheetTitle>
          <SheetDescription>
            अपनी साइट का प्रबंधन करें
          </SheetDescription>
        </SheetHeader>

        <Separator className="my-3" />

        {/* Stats Overview */}
        <div className="mb-4 grid grid-cols-2 gap-3">
          <div className="flex flex-col gap-1 rounded-lg border bg-muted/50 p-3">
            <div className="flex items-center gap-2">
              <Users className="h-4 w-4 text-muted-foreground" />
              <span className="text-xs text-muted-foreground">सब्सक्राइबर्स</span>
            </div>
            <span className="text-xl font-bold">{stats.subscribers}</span>
          </div>
          <div className="flex flex-col gap-1 rounded-lg border bg-muted/50 p-3">
            <div className="flex items-center gap-2">
              <Mail className="h-4 w-4 text-muted-foreground" />
              <span className="text-xs text-muted-foreground">संदेश</span>
            </div>
            <span className="text-xl font-bold">
              {stats.messages}
              {stats.messages > 0 && (
                <Badge variant="destructive" className="ml-1.5 scale-90 px-1 py-0 text-[10px]">
                  नया
                </Badge>
              )}
            </span>
          </div>
        </div>

        <Separator className="my-3" />

        {/* Navigation Links */}
        <nav className="flex flex-col gap-1">
          {adminLinks.map((link) => {
            const Icon = link.icon
            return (
              <button
                key={link.label}
                onClick={() => handleNavigate(link.params)}
                className="flex items-center gap-3 rounded-lg px-3 py-2.5 text-left transition-colors hover:bg-accent"
              >
                <div className="flex h-9 w-9 shrink-0 items-center justify-center rounded-lg bg-muted">
                  <Icon className="h-4 w-4 text-muted-foreground" />
                </div>
                <div className="flex flex-1 flex-col">
                  <span className="text-sm font-medium">{link.label}</span>
                  <span className="text-xs text-muted-foreground">
                    {link.description}
                  </span>
                </div>
                {link.badge === 'messages' && stats.messages > 0 && (
                  <Badge
                    variant="destructive"
                    className="ml-auto shrink-0 text-xs"
                  >
                    {stats.messages}
                  </Badge>
                )}
              </button>
            )
          })}
        </nav>

        <Separator className="my-3" />

        {/* Footer */}
        <div className="flex flex-col gap-1 px-1">
          <button
            onClick={handleClose}
            className="flex items-center gap-3 rounded-lg px-3 py-2.5 text-left text-sm text-muted-foreground transition-colors hover:bg-accent hover:text-foreground"
          >
            <LogOut className="h-4 w-4" />
            एडमिन पैनल बंद करें
          </button>
        </div>
      </SheetContent>
    </Sheet>
  )
}
