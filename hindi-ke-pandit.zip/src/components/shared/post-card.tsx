'use client'

import React from 'react'
import {
  TrendingUp,
  Wheat,
  Cpu,
  Eye,
  Clock,
  Calendar,
} from 'lucide-react'
import { Badge } from '@/components/ui/badge'
import { useAppStore } from '@/store'
import type { Post } from '@/lib/types'

const categoryIcons: Record<string, React.ElementType> = {
  TrendingUp,
  Wheat,
  Cpu,
}

const categoryColors: Record<string, string> = {
  'share-market': '#16a34a',
  krishi: '#ca8a04',
  technology: '#0891b2',
}

const categoryNames: Record<string, string> = {
  'share-market': 'शेयर मार्केट',
  krishi: 'कृषि',
  technology: 'टेक्नोलॉजी',
}

const categoryIconNames: Record<string, string> = {
  'share-market': 'TrendingUp',
  krishi: 'Wheat',
  technology: 'Cpu',
}

interface PostCardProps {
  post: Post
}

const hindiMonths = [
  'जनवरी', 'फरवरी', 'मार्च', 'अप्रैल', 'मई', 'जून',
  'जुलाई', 'अगस्त', 'सितंबर', 'अक्टूबर', 'नवंबर', 'दिसंबर',
]

function formatDateHindi(dateStr: string): string {
  const date = new Date(dateStr)
  const day = date.getDate()
  const month = hindiMonths[date.getMonth()]
  const year = date.getFullYear()
  return `${day} ${month} ${year}`
}

function estimateReadTime(content: string): number {
  const wordsPerMinute = 200
  const textContent = content.replace(/<[^>]*>/g, '')
  const wordCount = textContent.split(/\s+/).filter(Boolean).length
  const minutes = Math.ceil(wordCount / wordsPerMinute)
  return Math.max(1, minutes)
}

export function PostCard({ post }: PostCardProps) {
  const { navigate } = useAppStore()

  const categorySlug = post.category?.slug || post.categoryId
  const categoryName = post.category?.nameHindi || categoryNames[categorySlug] || 'अन्य'
  const categoryColor = post.category?.color || categoryColors[categorySlug] || '#6b7280'
  const iconName = post.category?.icon || categoryIconNames[categorySlug] || 'Cpu'
  const Icon = categoryIcons[iconName] || Cpu

  const readTime = estimateReadTime(post.content)
  const formattedDate = formatDateHindi(post.createdAt)

  return (
    <article
      onClick={() => navigate('post', { slug: post.slug })}
      className="group cursor-pointer overflow-hidden rounded-xl border bg-card text-card-foreground shadow-sm transition-all duration-300 hover:-translate-y-1 hover:shadow-lg"
    >
      {/* Cover Image */}
      <div className="relative aspect-video overflow-hidden">
        <img
          src={post.coverImage || '/placeholder-post.jpg'}
          alt={post.title}
          className="h-full w-full object-cover transition-transform duration-500 group-hover:scale-105"
        />
        <div className="absolute inset-0 bg-gradient-to-t from-black/60 via-transparent to-transparent" />
        {/* Category Badge */}
        <div className="absolute bottom-3 left-3">
          <Badge
            className="border-0 text-white shadow-md"
            style={{
              backgroundColor: categoryColor,
            }}
          >
            <Icon className="mr-1 h-3 w-3" />
            {categoryName}
          </Badge>
        </div>
        {/* Read Time */}
        {post.featured && (
          <div className="absolute right-3 top-3">
            <Badge variant="secondary" className="bg-yellow-500/90 text-white border-0">
              ⭐ फीचर्ड
            </Badge>
          </div>
        )}
      </div>

      {/* Content */}
      <div className="flex flex-col gap-3 p-4">
        {/* Title */}
        <h3 className="line-clamp-2 text-base font-semibold leading-snug tracking-tight transition-colors group-hover:text-primary">
          {post.title}
        </h3>

        {/* Excerpt */}
        <p className="line-clamp-2 text-sm leading-relaxed text-muted-foreground">
          {post.excerpt}
        </p>

        {/* Meta */}
        <div className="flex items-center gap-3 text-xs text-muted-foreground pt-1">
          <span className="flex items-center gap-1">
            <Calendar className="h-3.5 w-3.5" />
            {formattedDate}
          </span>
          <span className="flex items-center gap-1">
            <Eye className="h-3.5 w-3.5" />
            {post.viewCount > 1000
              ? `${(post.viewCount / 1000).toFixed(1)}K`
              : post.viewCount}
          </span>
          <span className="flex items-center gap-1">
            <Clock className="h-3.5 w-3.5" />
            {readTime} मिनट
          </span>
        </div>
      </div>
    </article>
  )
}
