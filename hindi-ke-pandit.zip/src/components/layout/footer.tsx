'use client'

import React, { useState } from 'react'
import {
  BookOpen,
  TrendingUp,
  Wheat,
  Cpu,
  Facebook,
  Twitter,
  Instagram,
  Youtube,
  Send,
  Mail,
  Heart,
} from 'lucide-react'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Separator } from '@/components/ui/separator'
import { useAppStore } from '@/store'
import { CATEGORIES } from '@/lib/types'
import { toast } from 'sonner'

const categoryIcons: Record<string, React.ElementType> = {
  TrendingUp,
  Wheat,
  Cpu,
}

const importantLinks = [
  { label: 'हमारे बारे में', page: 'about' as const },
  { label: 'संपर्क करें', page: 'contact' as const },
  { label: 'गोपनीयता नीति', page: 'privacy' as const },
  { label: 'नियम और शर्तें', page: 'terms' as const },
  { label: 'अस्वीकरण', page: 'disclaimer' as const },
]

const socialLinks = [
  { icon: Facebook, label: 'Facebook', href: '#' },
  { icon: Twitter, label: 'Twitter', href: '#' },
  { icon: Instagram, label: 'Instagram', href: '#' },
  { icon: Youtube, label: 'YouTube', href: '#' },
]

export function Footer() {
  const { navigate } = useAppStore()
  const [email, setEmail] = useState('')
  const [loading, setLoading] = useState(false)

  const handleNewsletter = async (e: React.FormEvent) => {
    e.preventDefault()
    if (!email) return

    setLoading(true)
    try {
      const res = await fetch('/api/newsletter', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ email }),
      })
      if (res.ok) {
        toast.success('सब्सक्रिप्शन सफल! 🎉', {
          description: 'आपने सफलतापूर्वक न्यूज़लेटर सब्सक्राइब कर लिया।',
        })
        setEmail('')
      } else {
        const data = await res.json()
        toast.error('त्रुटि', {
          description: data.error || 'कृपया बाद में पुनः प्रयास करें।',
        })
      }
    } catch {
      toast.error('त्रुटि', {
        description: 'नेटवर्क त्रुटि। कृपया बाद में पुनः प्रयास करें।',
      })
    } finally {
      setLoading(false)
    }
  }

  return (
    <footer className="mt-auto border-t bg-muted/40">
      <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
        {/* Main Footer Content */}
        <div className="grid gap-8 py-10 sm:grid-cols-2 lg:grid-cols-4">
          {/* About Section */}
          <div className="space-y-4">
            <div className="flex items-center gap-2">
              <div className="flex h-8 w-8 items-center justify-center rounded-lg bg-primary">
                <BookOpen className="h-5 w-5 text-primary-foreground" />
              </div>
              <span className="text-lg font-bold">हिंदी के पंडित</span>
            </div>
            <p className="text-sm leading-relaxed text-muted-foreground">
              हिंदी के पंडित एक विश्वसनीय हिंदी ब्लॉग है जो शेयर मार्केट, कृषि और
              टेक्नोलॉजी से जुड़ी नवीनतम जानकारी, टिप्स और गाइड प्रदान करता है।
              हमारा लक्ष्य हिंदी भाषियों को गुणवत्तापूर्ण सामग्री उपलब्ध कराना है।
            </p>
            {/* Social Links */}
            <div className="flex items-center gap-2">
              {socialLinks.map((social) => {
                const Icon = social.icon
                return (
                  <a
                    key={social.label}
                    href={social.href}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="flex h-9 w-9 items-center justify-center rounded-full bg-muted text-muted-foreground transition-colors hover:bg-primary hover:text-primary-foreground"
                  >
                    <Icon className="h-4 w-4" />
                    <span className="sr-only">{social.label}</span>
                  </a>
                )
              })}
            </div>
          </div>

          {/* Categories */}
          <div className="space-y-4">
            <h3 className="text-sm font-semibold uppercase tracking-wider">
              श्रेणियाँ
            </h3>
            <ul className="space-y-2.5">
              {Object.values(CATEGORIES).map((cat) => {
                const Icon = categoryIcons[cat.icon] || Cpu
                return (
                  <li key={cat.slug}>
                    <button
                      onClick={() => navigate('category', { category: cat.slug })}
                      className="flex items-center gap-2 text-sm text-muted-foreground transition-colors hover:text-foreground"
                    >
                      <Icon className="h-3.5 w-3.5" style={{ color: cat.color }} />
                      {cat.nameHindi}
                    </button>
                  </li>
                )
              })}
            </ul>
          </div>

          {/* Important Links */}
          <div className="space-y-4">
            <h3 className="text-sm font-semibold uppercase tracking-wider">
              महत्वपूर्ण लिंक
            </h3>
            <ul className="space-y-2.5">
              {importantLinks.map((link) => (
                <li key={link.page}>
                  <button
                    onClick={() => navigate(link.page)}
                    className="text-sm text-muted-foreground transition-colors hover:text-foreground"
                  >
                    {link.label}
                  </button>
                </li>
              ))}
            </ul>
          </div>

          {/* Newsletter */}
          <div className="space-y-4">
            <h3 className="text-sm font-semibold uppercase tracking-wider">
              न्यूज़लेटर
            </h3>
            <p className="text-sm text-muted-foreground">
              नवीनतम लेख और अपडेट सीधे अपने ईमेल में पाएं।
            </p>
            <form onSubmit={handleNewsletter} className="flex gap-2">
              <div className="relative flex-1">
                <Mail className="absolute left-2.5 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
                <Input
                  type="email"
                  placeholder="आपका ईमेल"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  className="h-9 pl-9"
                  required
                />
              </div>
              <Button
                type="submit"
                size="icon"
                className="h-9 w-9 shrink-0"
                disabled={loading}
              >
                <Send className="h-4 w-4" />
                <span className="sr-only">सब्सक्राइब</span>
              </Button>
            </form>
          </div>
        </div>

        <Separator />

        {/* Bottom Bar */}
        <div className="flex flex-col items-center justify-between gap-2 py-6 sm:flex-row">
          <p className="flex items-center gap-1 text-xs text-muted-foreground">
            © 2024 हिंदी के पंडित. सर्वाधिकार सुरक्षित।
          </p>
          <p className="flex items-center gap-1 text-xs text-muted-foreground">
            ❤️ से बनाया गया
          </p>
        </div>
      </div>
    </footer>
  )
}
