'use client'

import React, { useEffect, useSyncExternalStore } from 'react'
import { useTheme } from 'next-themes'
import {
  BookOpen,
  Search,
  Sun,
  Moon,
  Menu,
  Shield,
  TrendingUp,
  Wheat,
  Cpu,
  Home,
  Info,
  Phone,
} from 'lucide-react'
import { Button } from '@/components/ui/button'
import {
  Sheet,
  SheetContent,
  SheetHeader,
  SheetTitle,
  SheetDescription,
} from '@/components/ui/sheet'
import {
  Tooltip,
  TooltipContent,
  TooltipTrigger,
} from '@/components/ui/tooltip'
import { Separator } from '@/components/ui/separator'
import { useAppStore } from '@/store'
import { CATEGORIES } from '@/lib/types'

const navLinks = [
  { label: 'होम', page: 'home' as const, icon: Home },
  ...Object.values(CATEGORIES).map((cat) => ({
    label: cat.nameHindi,
    page: 'category' as const,
    slug: cat.slug,
    icon:
      cat.icon === 'TrendingUp'
        ? TrendingUp
        : cat.icon === 'Wheat'
          ? Wheat
          : Cpu,
  })),
  { label: 'About Us', page: 'about' as const, icon: Info },
  { label: 'Contact Us', page: 'contact' as const, icon: Phone },
]

export function Header() {
  const {
    navigate,
    searchOpen,
    setSearchOpen,
    mobileMenuOpen,
    setMobileMenuOpen,
    isAdminOpen,
    setAdminOpen,
  } = useAppStore()
  const { theme, setTheme } = useTheme()
  const mounted = useSyncExternalStore(
    () => () => {},
    () => true,
    () => false
  )

  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if ((e.metaKey || e.ctrlKey) && e.key === 'k') {
        e.preventDefault()
        setSearchOpen(true)
      }
    }
    document.addEventListener('keydown', handleKeyDown)
    return () => document.removeEventListener('keydown', handleKeyDown)
  }, [setSearchOpen])

  return (
    <>
      <header className="sticky top-0 z-40 w-full border-b bg-background/80 backdrop-blur-md supports-[backdrop-filter]:bg-background/60">
        <div className="mx-auto flex h-14 max-w-7xl items-center justify-between px-4 sm:px-6 lg:px-8">
          {/* Logo */}
          <button
            onClick={() => navigate('home')}
            className="flex items-center gap-2 transition-opacity hover:opacity-80"
          >
            <div className="flex h-8 w-8 items-center justify-center rounded-lg bg-primary">
              <BookOpen className="h-5 w-5 text-primary-foreground" />
            </div>
            <span className="text-lg font-bold tracking-tight">
              हिंदी के पंडित
            </span>
          </button>

          {/* Desktop Navigation */}
          <nav className="hidden items-center gap-1 md:flex">
            {navLinks.map((link) => {
              const Icon = link.icon
              return (
                <button
                  key={link.label}
                  onClick={() => {
                    if (link.slug) {
                      navigate('category', { category: link.slug })
                    } else {
                      navigate(link.page)
                    }
                  }}
                  className="flex items-center gap-1.5 rounded-md px-3 py-1.5 text-sm font-medium text-muted-foreground transition-colors hover:bg-accent hover:text-accent-foreground"
                >
                  <Icon className="h-4 w-4" />
                  {link.label}
                </button>
              )
            })}
          </nav>

          {/* Right side actions */}
          <div className="flex items-center gap-1">
            {/* Search */}
            <Tooltip>
              <TooltipTrigger asChild>
                <Button
                  variant="ghost"
                  size="icon"
                  onClick={() => setSearchOpen(true)}
                  className="relative"
                >
                  <Search className="h-4 w-4" />
                  <kbd className="pointer-events-none absolute right-1 top-1/2 hidden -translate-y-1/2 select-none items-center gap-0.5 rounded border bg-muted px-1 font-mono text-[10px] font-medium text-muted-foreground sm:flex">
                    <span className="text-xs">⌘</span>K
                  </kbd>
                </Button>
              </TooltipTrigger>
              <TooltipContent>खोजें (Ctrl+K)</TooltipContent>
            </Tooltip>

            {/* Theme Toggle */}
            <Tooltip>
              <TooltipTrigger asChild>
                <Button
                  variant="ghost"
                  size="icon"
                  onClick={() => setTheme(theme === 'dark' ? 'light' : 'dark')}
                >
                  {mounted && theme === 'dark' ? (
                    <Sun className="h-4 w-4" />
                  ) : (
                    <Moon className="h-4 w-4" />
                  )}
                  <span className="sr-only">
                    {mounted && theme === 'dark' ? 'लाइट मोड' : 'डार्क मोड'}
                  </span>
                </Button>
              </TooltipTrigger>
              <TooltipContent>
                {mounted && theme === 'dark' ? 'लाइट मोड' : 'डार्क मोड'}
              </TooltipContent>
            </Tooltip>

            {/* Admin */}
            <Tooltip>
              <TooltipTrigger asChild>
                <Button
                  variant="ghost"
                  size="icon"
                  onClick={() => setAdminOpen(true)}
                >
                  <Shield className="h-4 w-4" />
                  <span className="sr-only">एडमिन पैनल</span>
                </Button>
              </TooltipTrigger>
              <TooltipContent>एडमिन पैनल</TooltipContent>
            </Tooltip>

            {/* Mobile Menu */}
            <Button
              variant="ghost"
              size="icon"
              className="md:hidden"
              onClick={() => setMobileMenuOpen(true)}
            >
              <Menu className="h-5 w-5" />
              <span className="sr-only">मेनू</span>
            </Button>
          </div>
        </div>
      </header>

      {/* Mobile Menu Sheet */}
      <Sheet open={mobileMenuOpen} onOpenChange={setMobileMenuOpen}>
        <SheetContent side="right" className="w-72 overflow-y-auto">
          <SheetHeader className="pb-2">
            <SheetTitle className="flex items-center gap-2 text-lg">
              <BookOpen className="h-5 w-5 text-primary" />
              हिंदी के पंडित
            </SheetTitle>
            <SheetDescription>मेनू</SheetDescription>
          </SheetHeader>
          <Separator className="my-2" />
          <nav className="flex flex-col gap-1">
            {navLinks.map((link) => {
              const Icon = link.icon
              return (
                <button
                  key={link.label}
                  onClick={() => {
                    if (link.slug) {
                      navigate('category', { category: link.slug })
                    } else {
                      navigate(link.page)
                    }
                    setMobileMenuOpen(false)
                  }}
                  className="flex items-center gap-3 rounded-lg px-3 py-2.5 text-sm font-medium text-foreground transition-colors hover:bg-accent"
                >
                  <Icon className="h-4 w-4 text-muted-foreground" />
                  {link.label}
                </button>
              )
            })}
          </nav>
          <Separator className="my-3" />
          <div className="flex flex-col gap-2 px-3">
            <Button
              variant="outline"
              size="sm"
              onClick={() => {
                setTheme(theme === 'dark' ? 'light' : 'dark')
              }}
              className="flex items-center justify-center gap-2"
            >
              {mounted && theme === 'dark' ? (
                <>
                  <Sun className="h-4 w-4" /> लाइट मोड
                </>
              ) : (
                <>
                  <Moon className="h-4 w-4" /> डार्क मोड
                </>
              )}
            </Button>
            <Button
              variant="outline"
              size="sm"
              onClick={() => {
                setAdminOpen(true)
                setMobileMenuOpen(false)
              }}
              className="flex items-center justify-center gap-2"
            >
              <Shield className="h-4 w-4" /> एडमिन पैनल
            </Button>
          </div>
        </SheetContent>
      </Sheet>
    </>
  )
}
