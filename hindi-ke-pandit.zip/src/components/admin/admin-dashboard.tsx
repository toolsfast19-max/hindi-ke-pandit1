'use client'

import React, { useState, useEffect, useCallback, useMemo } from 'react'
import dynamic from 'next/dynamic'
import { useAppStore } from '@/store'
import type { Post, Category, Comment, Newsletter, ContactMessage } from '@/lib/types'
import { toast } from 'sonner'

import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Textarea } from '@/components/ui/textarea'
import { Label } from '@/components/ui/label'
import { Badge } from '@/components/ui/badge'
import { Switch } from '@/components/ui/switch'
import { Skeleton } from '@/components/ui/skeleton'
import { Separator } from '@/components/ui/separator'
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '@/components/ui/table'
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select'
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from '@/components/ui/alert-dialog'

import {
  LayoutDashboard,
  FileText,
  PlusCircle,
  MessageSquare,
  Users,
  Mail,
  Settings,
  Eye,
  EyeOff,
  Pencil,
  Trash2,
  ArrowLeft,
  Search,
  ChevronLeft,
  ChevronRight,
  CheckCircle2,
  XCircle,
  Clock,
  TrendingUp,
  Send,
  Star,
  Image as ImageIcon,
  Link2,
  AlertTriangle,
  RefreshCw,
  BarChart3,
  Globe,
  Shield,
} from 'lucide-react'

// Dynamic import for MDXEditor (client-only)
const MdxEditorClient = dynamic(
  () => import('./mdx-editor-client').then((mod) => ({ default: mod.MdxEditorClient })),
  {
    ssr: false,
    loading: () => (
      <div className="space-y-3 rounded-lg border p-4">
        <Skeleton className="h-4 w-3/4" />
        <Skeleton className="h-4 w-1/2" />
        <Skeleton className="h-4 w-5/6" />
        <Skeleton className="h-4 w-2/3" />
        <Skeleton className="h-4 w-4/5" />
        <Skeleton className="h-32 w-full" />
      </div>
    ),
  }
)

// ==================== HELPER FUNCTIONS ====================

function formatDate(dateStr: string): string {
  try {
    const date = new Date(dateStr)
    return date.toLocaleDateString('hi-IN', {
      year: 'numeric',
      month: 'short',
      day: 'numeric',
    })
  } catch {
    return dateStr
  }
}

function formatDateTime(dateStr: string): string {
  try {
    const date = new Date(dateStr)
    return date.toLocaleDateString('hi-IN', {
      year: 'numeric',
      month: 'short',
      day: 'numeric',
      hour: '2-digit',
      minute: '2-digit',
    })
  } catch {
    return dateStr
  }
}

function generateSlug(title: string): string {
  return title
    .toLowerCase()
    .trim()
    .replace(/[^\w\s-]/g, '')
    .replace(/[\s_]+/g, '-')
    .replace(/^-+|-+$/g, '')
    .substring(0, 80) || `post-${Date.now()}`
}

function truncate(str: string, len: number): string {
  if (!str) return ''
  return str.length > len ? str.substring(0, len) + '...' : str
}

// ==================== TAB DEFINITIONS ====================

const TABS = [
  { value: 'dashboard', label: 'डैशबोर्ड', icon: LayoutDashboard },
  { value: 'posts', label: 'पोस्टें', icon: FileText },
  { value: 'comments', label: 'टिप्पणियाँ', icon: MessageSquare },
  { value: 'subscribers', label: 'सब्सक्राइबर्स', icon: Users },
  { value: 'messages', label: 'संदेश', icon: Mail },
  { value: 'settings', label: 'सेटिंग्स', icon: Settings },
]

// ==================== LOADING SKELETONS ====================

function DashboardSkeleton() {
  return (
    <div className="space-y-6">
      <div className="grid gap-4 grid-cols-2 md:grid-cols-3 lg:grid-cols-6">
        {Array.from({ length: 6 }).map((_, i) => (
          <Skeleton key={i} className="h-28 rounded-xl" />
        ))}
      </div>
      <div className="grid gap-6 md:grid-cols-2">
        <Skeleton className="h-80 rounded-xl" />
        <Skeleton className="h-80 rounded-xl" />
      </div>
    </div>
  )
}

function TableSkeleton({ rows = 5 }: { rows?: number }) {
  return (
    <div className="space-y-3">
      {Array.from({ length: rows }).map((_, i) => (
        <Skeleton key={i} className="h-12 w-full" />
      ))}
    </div>
  )
}

// ==================== STATS CARD ====================

function StatCard({
  icon: Icon,
  value,
  label,
  color,
}: {
  icon: React.ElementType
  value: number
  label: string
  color: string
}) {
  return (
    <Card className="gap-0 overflow-hidden py-0">
      <div className="flex items-center gap-3 p-4">
        <div
          className="flex h-10 w-10 shrink-0 items-center justify-center rounded-lg"
          style={{ backgroundColor: `${color}15` }}
        >
          <Icon className="h-5 w-5" style={{ color }} />
        </div>
        <div className="min-w-0">
          <p className="text-2xl font-bold leading-none">{value.toLocaleString('hi-IN')}</p>
          <p className="mt-1 text-xs text-muted-foreground truncate">{label}</p>
        </div>
      </div>
      <div className="h-0.5" style={{ backgroundColor: color }} />
    </Card>
  )
}

// ==================== DASHBOARD OVERVIEW ====================

function DashboardOverview({
  onNavigate,
}: {
  onNavigate: (section: string, params?: Record<string, string>) => void
}) {
  const [stats, setStats] = useState<{
    totalPosts: number
    publishedPosts: number
    draftPosts: number
    totalComments: number
    pendingComments: number
    totalSubscribers: number
    totalViews: number
    unreadMessages: number
  } | null>(null)
  const [recentPosts, setRecentPosts] = useState<(Post & { category: Category })[]>([])
  const [recentComments, setRecentComments] = useState<Comment[]>([])
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    const fetchData = async () => {
      try {
        const res = await fetch('/api/dashboard')
        if (res.ok) {
          const data = await res.json()
          setStats(data.stats)
          setRecentPosts(data.recentPosts || [])
          setRecentComments(data.recentComments || [])
        }
      } catch {
        toast.error('डैशबोर्ड डेटा लोड करने में त्रुटि')
      } finally {
        setLoading(false)
      }
    }
    fetchData()
  }, [])

  if (loading) return <DashboardSkeleton />

  return (
    <div className="space-y-6">
      {/* Stats Grid */}
      <div className="grid gap-4 grid-cols-2 md:grid-cols-3 lg:grid-cols-6">
        <StatCard icon={FileText} value={stats?.totalPosts ?? 0} label="कुल पोस्टें" color="#16a34a" />
        <StatCard icon={CheckCircle2} value={stats?.publishedPosts ?? 0} label="प्रकाशित" color="#0891b2" />
        <StatCard icon={Edit3Icon} value={stats?.draftPosts ?? 0} label="ड्राफ्ट" color="#ca8a04" />
        <StatCard icon={MessageSquare} value={stats?.totalComments ?? 0} label="टिप्पणियाँ" color="#8b5cf6" />
        <StatCard icon={Users} value={stats?.totalSubscribers ?? 0} label="सब्सक्राइबर्स" color="#ec4899" />
        <StatCard icon={Eye} value={stats?.totalViews ?? 0} label="कुल व्यूज़" color="#f97316" />
      </div>

      {/* Quick Actions */}
      <div className="flex flex-wrap gap-3">
        <Button onClick={() => onNavigate('new-post')} className="gap-2 bg-emerald-600 hover:bg-emerald-700">
          <PlusCircle className="h-4 w-4" />
          नई पोस्ट लिखें
        </Button>
        <Button variant="outline" onClick={() => onNavigate('posts')} className="gap-2">
          <FileText className="h-4 w-4" />
          सभी पोस्टें देखें
        </Button>
        <Button variant="outline" onClick={() => onNavigate('comments')} className="gap-2">
          <MessageSquare className="h-4 w-4" />
          टिप्पणियाँ
          {stats?.pendingComments ? (
            <Badge variant="destructive" className="ml-1 text-xs">{stats.pendingComments}</Badge>
          ) : null}
        </Button>
        <Button variant="outline" onClick={() => onNavigate('messages')} className="gap-2">
          <Mail className="h-4 w-4" />
          संदेश
          {stats?.unreadMessages ? (
            <Badge variant="destructive" className="ml-1 text-xs">{stats.unreadMessages}</Badge>
          ) : null}
        </Button>
      </div>

      {/* Recent Posts & Comments */}
      <div className="grid gap-6 lg:grid-cols-2">
        {/* Recent Posts */}
        <Card>
          <CardHeader>
            <div className="flex items-center justify-between">
              <CardTitle className="flex items-center gap-2 text-base">
                <FileText className="h-4 w-4 text-emerald-600" />
                हालिया पोस्टें
              </CardTitle>
              <Button
                variant="ghost"
                size="sm"
                className="text-xs"
                onClick={() => onNavigate('posts')}
              >
                सभी देखें →
              </Button>
            </div>
          </CardHeader>
          <CardContent className="px-0 pb-0">
            <div className="max-h-80 overflow-y-auto">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>शीर्षक</TableHead>
                    <TableHead className="hidden sm:table-cell">श्रेणी</TableHead>
                    <TableHead>स्थिति</TableHead>
                    <TableHead className="hidden md:table-cell">तिथि</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {recentPosts.length === 0 ? (
                    <TableRow>
                      <TableCell colSpan={4} className="text-center text-muted-foreground py-8">
                        कोई पोस्ट नहीं
                      </TableCell>
                    </TableRow>
                  ) : (
                    recentPosts.map((post) => (
                      <TableRow
                        key={post.id}
                        className="cursor-pointer"
                        onClick={() => onNavigate('edit-post', { id: post.id })}
                      >
                        <TableCell className="font-medium max-w-[200px] truncate">
                          {truncate(post.title, 35)}
                        </TableCell>
                        <TableCell className="hidden sm:table-cell">
                          <Badge variant="outline" className="text-xs">
                            {post.category?.nameHindi || '—'}
                          </Badge>
                        </TableCell>
                        <TableCell>
                          {post.published ? (
                            <Badge className="bg-emerald-100 text-emerald-700 hover:bg-emerald-100 dark:bg-emerald-900/30 dark:text-emerald-400">
                              प्रकाशित
                            </Badge>
                          ) : (
                            <Badge className="bg-amber-100 text-amber-700 hover:bg-amber-100 dark:bg-amber-900/30 dark:text-amber-400">
                              ड्राफ्ट
                            </Badge>
                          )}
                        </TableCell>
                        <TableCell className="hidden md:table-cell text-muted-foreground text-xs">
                          {formatDate(post.createdAt)}
                        </TableCell>
                      </TableRow>
                    ))
                  )}
                </TableBody>
              </Table>
            </div>
          </CardContent>
        </Card>

        {/* Recent Comments */}
        <Card>
          <CardHeader>
            <div className="flex items-center justify-between">
              <CardTitle className="flex items-center gap-2 text-base">
                <MessageSquare className="h-4 w-4 text-purple-600" />
                हालिया टिप्पणियाँ
              </CardTitle>
              <Button
                variant="ghost"
                size="sm"
                className="text-xs"
                onClick={() => onNavigate('comments')}
              >
                सभी देखें →
              </Button>
            </div>
          </CardHeader>
          <CardContent className="px-0 pb-0">
            <div className="max-h-80 overflow-y-auto">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>नाम</TableHead>
                    <TableHead className="hidden sm:table-cell">टिप्पणी</TableHead>
                    <TableHead>स्थिति</TableHead>
                    <TableHead className="hidden md:table-cell">तिथि</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {recentComments.length === 0 ? (
                    <TableRow>
                      <TableCell colSpan={4} className="text-center text-muted-foreground py-8">
                        कोई टिप्पणी नहीं
                      </TableCell>
                    </TableRow>
                  ) : (
                    recentComments.map((comment) => (
                      <TableRow key={comment.id}>
                        <TableCell className="font-medium">{comment.name}</TableCell>
                        <TableCell className="hidden sm:table-cell text-muted-foreground max-w-[200px] truncate text-xs">
                          {truncate(comment.content, 40)}
                        </TableCell>
                        <TableCell>
                          {comment.approved ? (
                            <Badge className="bg-emerald-100 text-emerald-700 hover:bg-emerald-100 dark:bg-emerald-900/30 dark:text-emerald-400">
                              स्वीकृत
                            </Badge>
                          ) : (
                            <Badge className="bg-amber-100 text-amber-700 hover:bg-amber-100 dark:bg-amber-900/30 dark:text-amber-400">
                              लंबित
                            </Badge>
                          )}
                        </TableCell>
                        <TableCell className="hidden md:table-cell text-muted-foreground text-xs">
                          {formatDate(comment.createdAt)}
                        </TableCell>
                      </TableRow>
                    ))
                  )}
                </TableBody>
              </Table>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  )
}

// Pencil icon alias to avoid naming conflict
function Edit3Icon(props: React.SVGProps<SVGSVGElement>) {
  return (
    <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" {...props}>
      <path d="M17 3a2.85 2.83 0 1 1 4 4L7.5 20.5 2 22l1.5-5.5Z" />
      <path d="m15 5 4 4" />
    </svg>
  )
}

// ==================== POSTS LIST ====================

function PostsList({
  onNavigate,
}: {
  onNavigate: (section: string, params?: Record<string, string>) => void
}) {
  const [posts, setPosts] = useState<(Post & { category: Category })[]>([])
  const [categories, setCategories] = useState<Category[]>([])
  const [loading, setLoading] = useState(true)
  const [searchQuery, setSearchQuery] = useState('')
  const [filterCategory, setFilterCategory] = useState('all')
  const [filterStatus, setFilterStatus] = useState('all')
  const [page, setPage] = useState(1)
  const [totalPages, setTotalPages] = useState(1)
  const [deleteId, setDeleteId] = useState<string | null>(null)
  const [deleting, setDeleting] = useState(false)
  const [togglingId, setTogglingId] = useState<string | null>(null)
  const pageSize = 10

  const fetchPosts = useCallback(async () => {
    setLoading(true)
    try {
      const params = new URLSearchParams({ limit: '200' })
      const res = await fetch(`/api/posts?${params}`)
      if (res.ok) {
        const data = await res.json()
        setPosts(data.posts || [])
        setTotalPages(Math.ceil((data.total || 0) / pageSize))
      }
    } catch {
      toast.error('पोस्टें लोड करने में त्रुटि')
    } finally {
      setLoading(false)
    }
  }, [])

  const fetchCategories = useCallback(async () => {
    try {
      const res = await fetch('/api/categories')
      if (res.ok) {
        const data = await res.json()
        setCategories(data.categories || [])
      }
    } catch {
      // silent fail
    }
  }, [])

  useEffect(() => {
    fetchPosts()
    fetchCategories()
  }, [fetchPosts, fetchCategories])

  const filteredPosts = useMemo(() => {
    let result = [...posts]

    if (searchQuery.trim()) {
      const q = searchQuery.toLowerCase()
      result = result.filter(
        (p) =>
          p.title.toLowerCase().includes(q) ||
          p.excerpt.toLowerCase().includes(q)
      )
    }

    if (filterCategory !== 'all') {
      result = result.filter((p) => p.category?.slug === filterCategory)
    }

    if (filterStatus === 'published') {
      result = result.filter((p) => p.published)
    } else if (filterStatus === 'draft') {
      result = result.filter((p) => !p.published)
    }

    return result
  }, [posts, searchQuery, filterCategory, filterStatus])

  const paginatedPosts = useMemo(() => {
    const start = (page - 1) * pageSize
    return filteredPosts.slice(start, start + pageSize)
  }, [filteredPosts, page])

  const filteredTotalPages = Math.max(1, Math.ceil(filteredPosts.length / pageSize))

  useEffect(() => {
    if (page > filteredTotalPages) {
      setPage(1)
    }
  }, [filteredTotalPages, page])

  const handleDelete = async () => {
    if (!deleteId) return
    setDeleting(true)
    try {
      const res = await fetch(`/api/posts?id=${deleteId}`, { method: 'DELETE' })
      if (res.ok) {
        toast.success('पोस्ट सफलतापूर्वक हटा दी गई')
        setPosts((prev) => prev.filter((p) => p.id !== deleteId))
      } else {
        toast.error('पोस्ट हटाने में त्रुटि')
      }
    } catch {
      toast.error('पोस्ट हटाने में त्रुटि')
    } finally {
      setDeleting(false)
      setDeleteId(null)
    }
  }

  const handleTogglePublished = async (post: Post) => {
    setTogglingId(post.id)
    try {
      const res = await fetch(`/api/posts?id=${post.id}`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ published: !post.published }),
      })
      if (res.ok) {
        setPosts((prev) =>
          prev.map((p) => (p.id === post.id ? { ...p, published: !p.published } : p))
        )
        toast.success(post.published ? 'पोस्ट ड्राफ्ट में ले जाई गई' : 'पोस्ट प्रकाशित की गई')
      }
    } catch {
      toast.error('स्थिति बदलने में त्रुटि')
    } finally {
      setTogglingId(null)
    }
  }

  if (loading) {
    return (
      <Card>
        <CardHeader>
          <Skeleton className="h-8 w-48" />
        </CardHeader>
        <CardContent>
          <div className="mb-4 flex gap-3">
            <Skeleton className="h-10 flex-1" />
            <Skeleton className="h-10 w-40" />
            <Skeleton className="h-10 w-36" />
          </div>
          <TableSkeleton rows={6} />
        </CardContent>
      </Card>
    )
  }

  return (
    <div className="space-y-4">
      {/* Header */}
      <div className="flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between">
        <div>
          <h2 className="text-xl font-bold">सभी पोस्टें</h2>
          <p className="text-sm text-muted-foreground">कुल {filteredPosts.length} पोस्टें</p>
        </div>
        <Button onClick={() => onNavigate('new-post')} className="gap-2 bg-emerald-600 hover:bg-emerald-700">
          <PlusCircle className="h-4 w-4" />
          नई पोस्ट
        </Button>
      </div>

      {/* Filters */}
      <div className="flex flex-col gap-3 sm:flex-row">
        <div className="relative flex-1">
          <Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
          <Input
            placeholder="पोस्ट खोजें..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="pl-9"
          />
        </div>
        <Select value={filterCategory} onValueChange={setFilterCategory}>
          <SelectTrigger className="w-full sm:w-44">
            <SelectValue placeholder="श्रेणी" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="all">सभी श्रेणियाँ</SelectItem>
            {categories.map((cat) => (
              <SelectItem key={cat.id} value={cat.slug}>
                {cat.nameHindi}
              </SelectItem>
            ))}
          </SelectContent>
        </Select>
        <Select value={filterStatus} onValueChange={setFilterStatus}>
          <SelectTrigger className="w-full sm:w-36">
            <SelectValue placeholder="स्थिति" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="all">सभी</SelectItem>
            <SelectItem value="published">प्रकाशित</SelectItem>
            <SelectItem value="draft">ड्राफ्ट</SelectItem>
          </SelectContent>
        </Select>
      </div>

      {/* Posts Table */}
      <Card>
        <CardContent className="px-0 py-0">
          <div className="max-h-[500px] overflow-y-auto">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>शीर्षक</TableHead>
                  <TableHead className="hidden md:table-cell">श्रेणी</TableHead>
                  <TableHead>स्थिति</TableHead>
                  <TableHead className="hidden sm:table-cell">व्यूज़</TableHead>
                  <TableHead className="hidden lg:table-cell">तिथि</TableHead>
                  <TableHead className="text-right">कार्य</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {paginatedPosts.length === 0 ? (
                  <TableRow>
                    <TableCell colSpan={6} className="text-center text-muted-foreground py-12">
                      <FileText className="mx-auto h-10 w-10 text-muted-foreground/30 mb-3" />
                      <p>कोई पोस्ट नहीं मिली</p>
                      <Button
                        variant="link"
                        className="mt-2"
                        onClick={() => onNavigate('new-post')}
                      >
                        नई पोस्ट बनाएं
                      </Button>
                    </TableCell>
                  </TableRow>
                ) : (
                  paginatedPosts.map((post) => (
                    <TableRow key={post.id}>
                      <TableCell className="font-medium max-w-[250px]">
                        <div className="flex items-center gap-2">
                          {post.featured && (
                            <Star className="h-3.5 w-3.5 text-amber-500 fill-amber-500 shrink-0" />
                          )}
                          <span className="truncate">{post.title}</span>
                        </div>
                      </TableCell>
                      <TableCell className="hidden md:table-cell">
                        <Badge variant="outline" className="text-xs">
                          {post.category?.nameHindi || '—'}
                        </Badge>
                      </TableCell>
                      <TableCell>
                        <button
                          onClick={() => handleTogglePublished(post)}
                          disabled={togglingId === post.id}
                          className="inline-flex items-center gap-1.5"
                        >
                          {post.published ? (
                            <Badge className="cursor-pointer bg-emerald-100 text-emerald-700 hover:bg-emerald-200 dark:bg-emerald-900/30 dark:text-emerald-400">
                              <Eye className="h-3 w-3 mr-1" />
                              प्रकाशित
                            </Badge>
                          ) : (
                            <Badge className="cursor-pointer bg-amber-100 text-amber-700 hover:bg-amber-200 dark:bg-amber-900/30 dark:text-amber-400">
                              <EyeOff className="h-3 w-3 mr-1" />
                              ड्राफ्ट
                            </Badge>
                          )}
                        </button>
                      </TableCell>
                      <TableCell className="hidden sm:table-cell text-muted-foreground">
                        <span className="flex items-center gap-1 text-xs">
                          <Eye className="h-3 w-3" />
                          {post.viewCount}
                        </span>
                      </TableCell>
                      <TableCell className="hidden lg:table-cell text-muted-foreground text-xs">
                        {formatDate(post.createdAt)}
                      </TableCell>
                      <TableCell className="text-right">
                        <div className="flex items-center justify-end gap-1">
                          <Button
                            variant="ghost"
                            size="sm"
                            onClick={() => onNavigate('edit-post', { id: post.id })}
                            className="h-8 w-8 p-0"
                          >
                            <Pencil className="h-3.5 w-3.5" />
                          </Button>
                          <Button
                            variant="ghost"
                            size="sm"
                            onClick={() => setDeleteId(post.id)}
                            className="h-8 w-8 p-0 text-destructive hover:text-destructive"
                          >
                            <Trash2 className="h-3.5 w-3.5" />
                          </Button>
                        </div>
                      </TableCell>
                    </TableRow>
                  ))
                )}
              </TableBody>
            </Table>
          </div>
        </CardContent>
      </Card>

      {/* Pagination */}
      {filteredTotalPages > 1 && (
        <div className="flex items-center justify-between">
          <p className="text-sm text-muted-foreground">
            पृष्ठ {page} / {filteredTotalPages} ({filteredPosts.length} पोस्टें)
          </p>
          <div className="flex items-center gap-2">
            <Button
              variant="outline"
              size="sm"
              onClick={() => setPage((p) => Math.max(1, p - 1))}
              disabled={page === 1}
            >
              <ChevronLeft className="h-4 w-4" />
              पिछला
            </Button>
            <Button
              variant="outline"
              size="sm"
              onClick={() => setPage((p) => Math.min(filteredTotalPages, p + 1))}
              disabled={page === filteredTotalPages}
            >
              अगला
              <ChevronRight className="h-4 w-4" />
            </Button>
          </div>
        </div>
      )}

      {/* Delete Dialog */}
      <AlertDialog open={!!deleteId} onOpenChange={(open) => !open && setDeleteId(null)}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle className="flex items-center gap-2">
              <AlertTriangle className="h-5 w-5 text-destructive" />
              क्या आप वाकई इस पोस्ट को हटाना चाहते हैं?
            </AlertDialogTitle>
            <AlertDialogDescription>
              यह क्रिया पूर्ववत नहीं की जा सकती। यह पोस्ट स्थायी रूप से हट जाएगी और इससे जुड़ी सभी टिप्पणियाँ भी हट जाएंगी।
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel disabled={deleting}>रद्द करें</AlertDialogCancel>
            <AlertDialogAction
              onClick={handleDelete}
              disabled={deleting}
              className="bg-destructive hover:bg-destructive/90"
            >
              {deleting ? 'हटा रहे हैं...' : 'हाँ, हटाएं'}
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  )
}

// ==================== POST EDITOR ====================

function PostEditor({
  postId,
  onNavigate,
}: {
  postId: string | null
  onNavigate: (section: string, params?: Record<string, string>) => void
}) {
  const [title, setTitle] = useState('')
  const [content, setContent] = useState('')
  const [excerpt, setExcerpt] = useState('')
  const [slug, setSlug] = useState('')
  const [coverImage, setCoverImage] = useState('')
  const [categoryId, setCategoryId] = useState('')
  const [published, setPublished] = useState(false)
  const [featured, setFeatured] = useState(false)
  const [categories, setCategories] = useState<Category[]>([])
  const [loading, setLoading] = useState(!!postId)
  const [saving, setSaving] = useState(false)
  const [imagePreview, setImagePreview] = useState(false)

  useEffect(() => {
    const fetchCategories = async () => {
      try {
        const res = await fetch('/api/categories')
        if (res.ok) {
          const data = await res.json()
          setCategories(data.categories || [])
        }
      } catch {
        // silent fail
      }
    }
    fetchCategories()
  }, [])

  useEffect(() => {
    if (!postId) return
    const fetchPost = async () => {
      try {
        const res = await fetch(`/api/posts?limit=200`)
        if (res.ok) {
          const data = await res.json()
          const post = data.posts?.find((p: Post) => p.id === postId)
          if (post) {
            setTitle(post.title)
            setContent(post.content)
            setExcerpt(post.excerpt)
            setSlug(post.slug)
            setCoverImage(post.coverImage)
            setCategoryId(post.categoryId)
            setPublished(post.published)
            setFeatured(post.featured)
          } else {
            toast.error('पोस्ट नहीं मिली')
            onNavigate('posts')
          }
        }
      } catch {
        toast.error('पोस्ट लोड करने में त्रुटि')
      } finally {
        setLoading(false)
      }
    }
    fetchPost()
  }, [postId, onNavigate])

  useEffect(() => {
    if (!postId) {
      setSlug(generateSlug(title))
    }
  }, [title, postId])

  const handleSave = async (publish: boolean) => {
    if (!title.trim()) {
      toast.error('कृपया पोस्ट का शीर्षक दर्ज करें')
      return
    }
    if (!categoryId) {
      toast.error('कृपया एक श्रेणी चुनें')
      return
    }

    setSaving(true)
    const payload = {
      title: title.trim(),
      slug: slug.trim() || generateSlug(title),
      excerpt: excerpt.trim(),
      content: content.trim(),
      coverImage: coverImage.trim(),
      published: publish,
      featured,
      categoryId,
    }

    try {
      let res: Response
      if (postId) {
        res = await fetch(`/api/posts?id=${postId}`, {
          method: 'PUT',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify(payload),
        })
      } else {
        res = await fetch('/api/posts', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify(payload),
        })
      }

      if (res.ok) {
        toast.success(postId ? 'पोस्ट सफलतापूर्वक अपडेट की गई!' : 'पोस्ट सफलतापूर्वक बनाई गई!')
        onNavigate('posts')
      } else {
        const err = await res.json()
        toast.error(err.error || 'पोस्ट सेव करने में त्रुटि')
      }
    } catch {
      toast.error('नेटवर्क त्रुटि')
    } finally {
      setSaving(false)
    }
  }

  if (loading) {
    return (
      <div className="space-y-6">
        <Skeleton className="h-12 w-64" />
        <div className="grid gap-6 lg:grid-cols-[1fr_320px]">
          <div className="space-y-4">
            <Skeleton className="h-14 w-full" />
            <Skeleton className="h-[500px] w-full" />
          </div>
          <div className="space-y-4">
            <Skeleton className="h-64 w-full" />
          </div>
        </div>
      </div>
    )
  }

  return (
    <div className="space-y-6">
      {/* Back Button & Title */}
      <div className="flex items-center gap-3">
        <Button variant="ghost" size="sm" onClick={() => onNavigate('posts')} className="gap-2">
          <ArrowLeft className="h-4 w-4" />
          पोस्टें
        </Button>
        <Separator orientation="vertical" className="h-6" />
        <h2 className="text-lg font-bold">
          {postId ? 'पोस्ट संपादित करें' : 'नई पोस्ट बनाएं'}
        </h2>
      </div>

      {/* Editor Layout */}
      <div className="grid gap-6 lg:grid-cols-[1fr_320px]">
        {/* Main Content */}
        <div className="space-y-4">
          {/* Title */}
          <div>
            <Input
              value={title}
              onChange={(e) => setTitle(e.target.value)}
              placeholder="पोस्ट का शीर्षक दर्ज करें..."
              className="text-xl font-bold border-0 border-b rounded-none px-0 shadow-none focus-visible:ring-0 h-14 placeholder:text-muted-foreground/50"
            />
          </div>

          {/* Cover Image */}
          <Card>
            <CardContent className="p-4">
              <Label className="text-sm font-medium flex items-center gap-2 mb-3">
                <ImageIcon className="h-4 w-4" />
                फीचर्ड इमेज URL
              </Label>
              <div className="flex gap-2">
                <Input
                  value={coverImage}
                  onChange={(e) => setCoverImage(e.target.value)}
                  placeholder="https://example.com/image.jpg"
                  className="flex-1"
                />
                <Button
                  variant="outline"
                  size="sm"
                  onClick={() => setImagePreview(!imagePreview)}
                  disabled={!coverImage.trim()}
                >
                  {imagePreview ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
                </Button>
              </div>
              {imagePreview && coverImage.trim() && (
                <div className="mt-3 overflow-hidden rounded-lg border bg-muted">
                  <img
                    src={coverImage}
                    alt="प्रीव्यू"
                    className="h-48 w-full object-cover"
                    onError={(e) => {
                      ;(e.target as HTMLImageElement).style.display = 'none'
                    }}
                  />
                </div>
              )}
            </CardContent>
          </Card>

          {/* Content Editor */}
          <div>
            <Label className="text-sm font-medium flex items-center gap-2 mb-3">
              <FileText className="h-4 w-4" />
              कंटेंट
            </Label>
            <MdxEditorClient
              value={content}
              onChange={setContent}
              placeholder="यहाँ अपना कंटेंट लिखें... (Markdown सपोर्ट)"
            />
          </div>
        </div>

        {/* Sidebar */}
        <div className="space-y-4">
          {/* Publish Settings */}
          <Card>
            <CardContent className="p-4 space-y-5">
              <h3 className="font-semibold flex items-center gap-2">
                <Send className="h-4 w-4" />
                प्रकाशन सेटिंग्स
              </h3>

              {/* Publish / Draft Toggle */}
              <div className="flex items-center justify-between">
                <Label htmlFor="published-toggle" className="text-sm">
                  प्रकाशित
                </Label>
                <Switch
                  id="published-toggle"
                  checked={published}
                  onCheckedChange={setPublished}
                />
              </div>

              {/* Featured Toggle */}
              <div className="flex items-center justify-between">
                <Label htmlFor="featured-toggle" className="text-sm flex items-center gap-1.5">
                  <Star className="h-3.5 w-3.5" />
                  फीचर्ड
                </Label>
                <Switch
                  id="featured-toggle"
                  checked={featured}
                  onCheckedChange={setFeatured}
                />
              </div>

              <Separator />

              {/* Category */}
              <div className="space-y-2">
                <Label className="text-sm">श्रेणी</Label>
                <Select value={categoryId} onValueChange={setCategoryId}>
                  <SelectTrigger className="w-full">
                    <SelectValue placeholder="श्रेणी चुनें..." />
                  </SelectTrigger>
                  <SelectContent>
                    {categories.map((cat) => (
                      <SelectItem key={cat.id} value={cat.id}>
                        {cat.nameHindi}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>

              {/* Slug */}
              <div className="space-y-2">
                <Label htmlFor="slug-input" className="text-sm flex items-center gap-1.5">
                  <Link2 className="h-3.5 w-3.5" />
                  स्लग (URL)
                </Label>
                <Input
                  id="slug-input"
                  value={slug}
                  onChange={(e) => setSlug(e.target.value)}
                  placeholder="post-slug"
                  className="text-sm"
                />
              </div>

              {/* Excerpt */}
              <div className="space-y-2">
                <Label htmlFor="excerpt-input" className="text-sm">अंश (Excerpt)</Label>
                <Textarea
                  id="excerpt-input"
                  value={excerpt}
                  onChange={(e) => setExcerpt(e.target.value)}
                  placeholder="पोस्ट का संक्षिप्त विवरण..."
                  rows={3}
                  className="text-sm resize-none"
                />
              </div>

              <Separator />

              {/* Action Buttons */}
              <div className="space-y-2">
                {postId ? (
                  <Button
                    onClick={() => handleSave(published)}
                    disabled={saving}
                    className="w-full gap-2 bg-blue-600 hover:bg-blue-700"
                  >
                    <RefreshCw className={`h-4 w-4 ${saving ? 'animate-spin' : ''}`} />
                    {saving ? 'अपडेट हो रही है...' : 'अपडेट करें'}
                  </Button>
                ) : (
                  <Button
                    onClick={() => handleSave(true)}
                    disabled={saving}
                    className="w-full gap-2 bg-emerald-600 hover:bg-emerald-700"
                  >
                    <Send className={`h-4 w-4 ${saving ? 'animate-pulse' : ''}`} />
                    {saving ? 'प्रकाशित हो रही है...' : 'प्रकाशित करें'}
                  </Button>
                )}
                <Button
                  onClick={() => handleSave(false)}
                  disabled={saving}
                  variant="outline"
                  className="w-full gap-2"
                >
                  <Edit3Icon className="h-4 w-4" />
                  ड्राफ्ट सेव करें
                </Button>
              </div>
            </CardContent>
          </Card>

          {/* Post Info */}
          {postId && (
            <Card>
              <CardContent className="p-4">
                <h3 className="font-semibold text-sm mb-3 flex items-center gap-2">
                  <BarChart3 className="h-4 w-4" />
                  पोस्ट जानकारी
                </h3>
                <div className="space-y-2 text-xs text-muted-foreground">
                  <div className="flex justify-between">
                    <span>स्थिति:</span>
                    <span className={published ? 'text-emerald-600' : 'text-amber-600'}>
                      {published ? 'प्रकाशित' : 'ड्राफ्ट'}
                    </span>
                  </div>
                  <div className="flex justify-between">
                    <span>फीचर्ड:</span>
                    <span className={featured ? 'text-amber-600' : ''}>
                      {featured ? 'हाँ ★' : 'नहीं'}
                    </span>
                  </div>
                </div>
              </CardContent>
            </Card>
          )}
        </div>
      </div>
    </div>
  )
}

// ==================== COMMENTS SECTION ====================

function CommentsSection() {
  const [comments, setComments] = useState<Comment[]>([])
  const [loading, setLoading] = useState(true)
  const [deleteId, setDeleteId] = useState<string | null>(null)
  const [deleting, setDeleting] = useState(false)
  const [approvingId, setApprovingId] = useState<string | null>(null)

  const fetchComments = useCallback(async () => {
    try {
      const res = await fetch('/api/comments')
      if (res.ok) {
        const data = await res.json()
        setComments(data.comments || [])
      }
    } catch {
      toast.error('टिप्पणियाँ लोड करने में त्रुटि')
    } finally {
      setLoading(false)
    }
  }, [])

  useEffect(() => {
    fetchComments()
  }, [fetchComments])

  const handleApprove = async (comment: Comment) => {
    setApprovingId(comment.id)
    try {
      const res = await fetch(`/api/comments?id=${comment.id}`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ approved: !comment.approved }),
      })
      if (res.ok) {
        setComments((prev) =>
          prev.map((c) => (c.id === comment.id ? { ...c, approved: !c.approved } : c))
        )
        toast.success(comment.approved ? 'टिप्पणी अस्वीकृत की गई' : 'टिप्पणी स्वीकृत की गई')
      }
    } catch {
      toast.error('त्रुटि')
    } finally {
      setApprovingId(null)
    }
  }

  const handleDelete = async () => {
    if (!deleteId) return
    setDeleting(true)
    try {
      const res = await fetch(`/api/comments?id=${deleteId}`, { method: 'DELETE' })
      if (res.ok) {
        toast.success('टिप्पणी हटा दी गई')
        setComments((prev) => prev.filter((c) => c.id !== deleteId))
      }
    } catch {
      toast.error('त्रुटि')
    } finally {
      setDeleting(false)
      setDeleteId(null)
    }
  }

  if (loading) {
    return (
      <Card>
        <CardHeader>
          <Skeleton className="h-8 w-48" />
        </CardHeader>
        <CardContent>
          <TableSkeleton rows={6} />
        </CardContent>
      </Card>
    )
  }

  const pendingCount = comments.filter((c) => !c.approved).length

  return (
    <div className="space-y-4">
      <div>
        <h2 className="text-xl font-bold">टिप्पणियाँ</h2>
        <p className="text-sm text-muted-foreground">
          कुल {comments.length} टिप्पणियाँ
          {pendingCount > 0 && (
            <Badge variant="destructive" className="ml-2 text-xs">
              {pendingCount} लंबित
            </Badge>
          )}
        </p>
      </div>

      <Card>
        <CardContent className="px-0 py-0">
          <div className="max-h-[600px] overflow-y-auto">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>नाम</TableHead>
                  <TableHead className="hidden sm:table-cell">टिप्पणी</TableHead>
                  <TableHead className="hidden md:table-cell">ईमेल</TableHead>
                  <TableHead>स्थिति</TableHead>
                  <TableHead className="hidden lg:table-cell">तिथि</TableHead>
                  <TableHead className="text-right">कार्य</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {comments.length === 0 ? (
                  <TableRow>
                    <TableCell colSpan={6} className="text-center text-muted-foreground py-12">
                      <MessageSquare className="mx-auto h-10 w-10 text-muted-foreground/30 mb-3" />
                      <p>कोई टिप्पणी नहीं</p>
                    </TableCell>
                  </TableRow>
                ) : (
                  comments.map((comment) => (
                    <TableRow key={comment.id}>
                      <TableCell className="font-medium">{comment.name}</TableCell>
                      <TableCell className="hidden sm:table-cell text-muted-foreground max-w-[250px] truncate text-xs">
                        {truncate(comment.content, 50)}
                      </TableCell>
                      <TableCell className="hidden md:table-cell text-muted-foreground text-xs">
                        {comment.email}
                      </TableCell>
                      <TableCell>
                        {comment.approved ? (
                          <Badge className="bg-emerald-100 text-emerald-700 hover:bg-emerald-100 dark:bg-emerald-900/30 dark:text-emerald-400">
                            <CheckCircle2 className="h-3 w-3 mr-1" />
                            स्वीकृत
                          </Badge>
                        ) : (
                          <Badge className="bg-amber-100 text-amber-700 hover:bg-amber-100 dark:bg-amber-900/30 dark:text-amber-400">
                            <Clock className="h-3 w-3 mr-1" />
                            लंबित
                          </Badge>
                        )}
                      </TableCell>
                      <TableCell className="hidden lg:table-cell text-muted-foreground text-xs">
                        {formatDate(comment.createdAt)}
                      </TableCell>
                      <TableCell className="text-right">
                        <div className="flex items-center justify-end gap-1">
                          <Button
                            variant="ghost"
                            size="sm"
                            onClick={() => handleApprove(comment)}
                            disabled={approvingId === comment.id}
                            className="h-8 gap-1 px-2 text-xs"
                          >
                            {comment.approved ? (
                              <>
                                <XCircle className="h-3.5 w-3.5" />
                                <span className="hidden xl:inline">अस्वीकृत</span>
                              </>
                            ) : (
                              <>
                                <CheckCircle2 className="h-3.5 w-3.5" />
                                <span className="hidden xl:inline">स्वीकृत</span>
                              </>
                            )}
                          </Button>
                          <Button
                            variant="ghost"
                            size="sm"
                            onClick={() => setDeleteId(comment.id)}
                            className="h-8 w-8 p-0 text-destructive hover:text-destructive"
                          >
                            <Trash2 className="h-3.5 w-3.5" />
                          </Button>
                        </div>
                      </TableCell>
                    </TableRow>
                  ))
                )}
              </TableBody>
            </Table>
          </div>
        </CardContent>
      </Card>

      {/* Delete Dialog */}
      <AlertDialog open={!!deleteId} onOpenChange={(open) => !open && setDeleteId(null)}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle className="flex items-center gap-2">
              <AlertTriangle className="h-5 w-5 text-destructive" />
              टिप्पणी हटाएं?
            </AlertDialogTitle>
            <AlertDialogDescription>
              यह टिप्पणी स्थायी रूप से हट जाएगी।
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel disabled={deleting}>रद्द करें</AlertDialogCancel>
            <AlertDialogAction
              onClick={handleDelete}
              disabled={deleting}
              className="bg-destructive hover:bg-destructive/90"
            >
              {deleting ? 'हटा रहे हैं...' : 'हाँ, हटाएं'}
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  )
}

// ==================== SUBSCRIBERS SECTION ====================

function SubscribersSection() {
  const [subscribers, setSubscribers] = useState<Newsletter[]>([])
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    const fetchData = async () => {
      try {
        const res = await fetch('/api/newsletter')
        if (res.ok) {
          const data = await res.json()
          setSubscribers(data.subscribers || [])
        }
      } catch {
        toast.error('सब्सक्राइबर्स लोड करने में त्रुटि')
      } finally {
        setLoading(false)
      }
    }
    fetchData()
  }, [])

  if (loading) {
    return (
      <Card>
        <CardHeader>
          <Skeleton className="h-8 w-48" />
        </CardHeader>
        <CardContent>
          <TableSkeleton rows={6} />
        </CardContent>
      </Card>
    )
  }

  return (
    <div className="space-y-4">
      <div>
        <h2 className="text-xl font-bold">सब्सक्राइबर्स</h2>
        <p className="text-sm text-muted-foreground">
          कुल {subscribers.length} सब्सक्राइबर्स
        </p>
      </div>

      <Card>
        <CardContent className="px-0 py-0">
          <div className="max-h-[600px] overflow-y-auto">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead className="w-10">#</TableHead>
                  <TableHead>ईमेल</TableHead>
                  <TableHead className="hidden sm:table-cell">स्थिति</TableHead>
                  <TableHead className="hidden md:table-cell">सदस्यता तिथि</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {subscribers.length === 0 ? (
                  <TableRow>
                    <TableCell colSpan={4} className="text-center text-muted-foreground py-12">
                      <Users className="mx-auto h-10 w-10 text-muted-foreground/30 mb-3" />
                      <p>कोई सब्सक्राइबर नहीं</p>
                    </TableCell>
                  </TableRow>
                ) : (
                  subscribers.map((sub, index) => (
                    <TableRow key={sub.id}>
                      <TableCell className="text-muted-foreground text-xs">
                        {index + 1}
                      </TableCell>
                      <TableCell className="font-medium">{sub.email}</TableCell>
                      <TableCell className="hidden sm:table-cell">
                        {sub.active ? (
                          <Badge className="bg-emerald-100 text-emerald-700 hover:bg-emerald-100 dark:bg-emerald-900/30 dark:text-emerald-400">
                            सक्रिय
                          </Badge>
                        ) : (
                          <Badge className="bg-gray-100 text-gray-700 hover:bg-gray-100 dark:bg-gray-900/30 dark:text-gray-400">
                            निष्क्रिय
                          </Badge>
                        )}
                      </TableCell>
                      <TableCell className="hidden md:table-cell text-muted-foreground text-xs">
                        {formatDate(sub.createdAt)}
                      </TableCell>
                    </TableRow>
                  ))
                )}
              </TableBody>
            </Table>
          </div>
        </CardContent>
      </Card>
    </div>
  )
}

// ==================== MESSAGES SECTION ====================

function MessagesSection() {
  const [messages, setMessages] = useState<ContactMessage[]>([])
  const [loading, setLoading] = useState(true)
  const [expandedId, setExpandedId] = useState<string | null>(null)
  const [markingId, setMarkingId] = useState<string | null>(null)

  const fetchMessages = useCallback(async () => {
    try {
      const res = await fetch('/api/contact')
      if (res.ok) {
        const data = await res.json()
        setMessages(data.messages || [])
      }
    } catch {
      toast.error('संदेश लोड करने में त्रुटि')
    } finally {
      setLoading(false)
    }
  }, [])

  useEffect(() => {
    fetchMessages()
  }, [fetchMessages])

  const handleMarkRead = async (msg: ContactMessage) => {
    setMarkingId(msg.id)
    try {
      const res = await fetch(`/api/contact?id=${msg.id}`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ read: !msg.read }),
      })
      if (res.ok) {
        setMessages((prev) =>
          prev.map((m) => (m.id === msg.id ? { ...m, read: !m.read } : m))
        )
        toast.success(msg.read ? 'अपठित के रूप में चिह्नित' : 'पठा गया')
      }
    } catch {
      toast.error('त्रुटि')
    } finally {
      setMarkingId(null)
    }
  }

  if (loading) {
    return (
      <Card>
        <CardHeader>
          <Skeleton className="h-8 w-48" />
        </CardHeader>
        <CardContent>
          <TableSkeleton rows={6} />
        </CardContent>
      </Card>
    )
  }

  const unreadCount = messages.filter((m) => !m.read).length

  return (
    <div className="space-y-4">
      <div>
        <h2 className="text-xl font-bold">संदेश</h2>
        <p className="text-sm text-muted-foreground">
          कुल {messages.length} संदेश
          {unreadCount > 0 && (
            <Badge variant="destructive" className="ml-2 text-xs">
              {unreadCount} अपठित
            </Badge>
          )}
        </p>
      </div>

      <div className="space-y-3">
        {messages.length === 0 ? (
          <Card>
            <CardContent className="py-12 text-center">
              <Mail className="mx-auto h-10 w-10 text-muted-foreground/30 mb-3" />
              <p className="text-muted-foreground">कोई संदेश नहीं</p>
            </CardContent>
          </Card>
        ) : (
          messages.map((msg) => (
            <Card
              key={msg.id}
              className={`cursor-pointer transition-all hover:shadow-md ${
                !msg.read ? 'border-l-4 border-l-emerald-500 bg-emerald-50/50 dark:bg-emerald-950/10' : ''
              }`}
              onClick={() => setExpandedId(expandedId === msg.id ? null : msg.id)}
            >
              <CardContent className="p-4">
                <div className="flex items-start justify-between gap-3">
                  <div className="min-w-0 flex-1">
                    <div className="flex items-center gap-2 mb-1">
                      {!msg.read && (
                        <div className="h-2 w-2 rounded-full bg-emerald-500 shrink-0" />
                      )}
                      <span className="font-semibold text-sm">{msg.name}</span>
                      <span className="text-xs text-muted-foreground">({msg.email})</span>
                    </div>
                    {msg.subject && (
                      <p className="text-sm font-medium truncate">{msg.subject}</p>
                    )}
                    <p className="text-xs text-muted-foreground mt-1">
                      {formatDateTime(msg.createdAt)}
                    </p>
                  </div>
                  <div className="flex items-center gap-1 shrink-0">
                    <Button
                      variant="ghost"
                      size="sm"
                      onClick={(e) => {
                        e.stopPropagation()
                        handleMarkRead(msg)
                      }}
                      disabled={markingId === msg.id}
                      className="h-8 gap-1 px-2 text-xs"
                    >
                      {msg.read ? (
                        <>
                          <Mail className="h-3.5 w-3.5" />
                          <span className="hidden sm:inline">अपठित</span>
                        </>
                      ) : (
                        <>
                          <CheckCircle2 className="h-3.5 w-3.5" />
                          <span className="hidden sm:inline">पठा गया</span>
                        </>
                      )}
                    </Button>
                  </div>
                </div>

                {/* Expanded Message */}
                {expandedId === msg.id && (
                  <div className="mt-4 rounded-lg border bg-muted/30 p-4">
                    <p className="text-sm leading-relaxed whitespace-pre-wrap">{msg.message}</p>
                  </div>
                )}
              </CardContent>
            </Card>
          ))
        )}
      </div>
    </div>
  )
}

// ==================== SETTINGS SECTION ====================

function SettingsSection() {
  const [siteName, setSiteName] = useState('हिंदी के पंडित')
  const [siteDescription, setSiteDescription] = useState(
    'हिंदी में ज्ञान की अनमोल धारा — शेयर मार्केट, कृषि और टेक्नोलॉजी'
  )
  const [saving, setSaving] = useState(false)

  const handleSave = async () => {
    setSaving(true)
    // Simulate save with toast
    await new Promise((r) => setTimeout(r, 800))
    toast.success('सेटिंग्स सेव की गईं!')
    setSaving(false)
  }

  return (
    <div className="space-y-6">
      <div>
        <h2 className="text-xl font-bold">सेटिंग्स</h2>
        <p className="text-sm text-muted-foreground">साइट की सेटिंग्स प्रबंधित करें</p>
      </div>

      {/* General Settings */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2 text-base">
            <Globe className="h-5 w-5 text-emerald-600" />
            सामान्य सेटिंग्स
          </CardTitle>
          <CardDescription>साइट की मूल जानकारी</CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="space-y-2">
            <Label htmlFor="site-name">साइट नाम</Label>
            <Input
              id="site-name"
              value={siteName}
              onChange={(e) => setSiteName(e.target.value)}
              placeholder="साइट का नाम"
            />
          </div>
          <div className="space-y-2">
            <Label htmlFor="site-desc">साइट विवरण</Label>
            <Textarea
              id="site-desc"
              value={siteDescription}
              onChange={(e) => setSiteDescription(e.target.value)}
              placeholder="साइट का विवरण"
              rows={3}
            />
          </div>
          <Button
            onClick={handleSave}
            disabled={saving}
            className="gap-2 bg-emerald-600 hover:bg-emerald-700"
          >
            {saving ? (
              <RefreshCw className="h-4 w-4 animate-spin" />
            ) : (
              <CheckCircle2 className="h-4 w-4" />
            )}
            सेव करें
          </Button>
        </CardContent>
      </Card>

      {/* Admin Info */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2 text-base">
            <Shield className="h-5 w-5 text-purple-600" />
            एडमिन जानकारी
          </CardTitle>
          <CardDescription>एडमिन पैनल की जानकारी</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="rounded-lg border bg-muted/30 p-4 space-y-2 text-sm">
            <div className="flex justify-between">
              <span className="text-muted-foreground">संस्करण:</span>
              <span className="font-medium">1.0.0</span>
            </div>
            <div className="flex justify-between">
              <span className="text-muted-foreground">फ्रेमवर्क:</span>
              <span className="font-medium">Next.js 16 + TypeScript</span>
            </div>
            <div className="flex justify-between">
              <span className="text-muted-foreground">UI:</span>
              <span className="font-medium">Tailwind CSS + shadcn/ui</span>
            </div>
            <div className="flex justify-between">
              <span className="text-muted-foreground">डेटाबेस:</span>
              <span className="font-medium">SQLite + Prisma ORM</span>
            </div>
            <div className="flex justify-between">
              <span className="text-muted-foreground">भाषा:</span>
              <span className="font-medium">हिंदी (Hindi)</span>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Stats & Info */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2 text-base">
            <TrendingUp className="h-5 w-5 text-orange-600" />
            उपयोग आँकड़े
          </CardTitle>
          <CardDescription>साइट के उपयोग संबंधित आँकड़े</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="rounded-lg border bg-muted/30 p-4 space-y-2 text-sm">
            <div className="flex justify-between">
              <span className="text-muted-foreground">API एंडपॉइंट्स:</span>
              <span className="font-medium">7 (GET/POST/PUT/DELETE)</span>
            </div>
            <div className="flex justify-between">
              <span className="text-muted-foreground">डेटाबेस मॉडल:</span>
              <span className="font-medium">5 (Category, Post, Comment, Newsletter, ContactMessage)</span>
            </div>
            <div className="flex justify-between">
              <span className="text-muted-foreground">एडमिन सेक्शन:</span>
              <span className="font-medium">6 (डैशबोर्ड, पोस्टें, टिप्पणियाँ, सब्सक्राइबर्स, संदेश, सेटिंग्स)</span>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  )
}

// ==================== MAIN ADMIN DASHBOARD ====================

export function AdminDashboard() {
  const { pageParams, navigate } = useAppStore()
  const section = pageParams.section || 'dashboard'

  const handleNavigate = useCallback(
    (newSection: string, params?: Record<string, string>) => {
      navigate('admin', { ...params, section: newSection })
    },
    [navigate]
  )

  // Determine active tab (new-post and edit-post both show 'posts' as active)
  const activeTab = ['new-post', 'edit-post'].includes(section) ? 'posts' : section

  return (
    <div className="min-h-screen bg-background">
      <div className="mx-auto max-w-7xl px-4 py-6 sm:px-6 lg:px-8">
        {/* Admin Header */}
        <div className="mb-6 flex items-center gap-3">
          <div className="flex h-10 w-10 items-center justify-center rounded-xl bg-emerald-600 shadow-lg">
            <Shield className="h-5 w-5 text-white" />
          </div>
          <div>
            <h1 className="text-xl font-bold tracking-tight">एडमिन डैशबोर्ड</h1>
            <p className="text-xs text-muted-foreground">हिंदी के पंडित — ब्लॉग प्रबंधन</p>
          </div>
        </div>

        {/* Tab Navigation */}
        <div className="mb-6 -mx-4 px-4 sm:mx-0 sm:px-0">
          <div className="overflow-x-auto scrollbar-thin pb-1">
            <div className="flex gap-1 rounded-xl bg-muted/50 p-1 min-w-max">
              {TABS.map((tab) => {
                const Icon = tab.icon
                const isActive = activeTab === tab.value
                return (
                  <button
                    key={tab.value}
                    onClick={() => handleNavigate(tab.value)}
                    className={`
                      flex items-center gap-2 rounded-lg px-3 py-2.5 text-sm font-medium transition-all whitespace-nowrap
                      ${
                        isActive
                          ? 'bg-background text-foreground shadow-sm'
                          : 'text-muted-foreground hover:text-foreground hover:bg-background/50'
                      }
                    `}
                  >
                    <Icon className="h-4 w-4" />
                    <span className="hidden sm:inline">{tab.label}</span>
                    <span className="sm:hidden">{tab.label.slice(0, 2)}</span>
                  </button>
                )
              })}
            </div>
          </div>
        </div>

        {/* Section Content */}
        <div>
          {section === 'dashboard' && (
            <DashboardOverview onNavigate={handleNavigate} />
          )}

          {section === 'posts' && (
            <PostsList onNavigate={handleNavigate} />
          )}

          {section === 'new-post' && (
            <PostEditor postId={null} onNavigate={handleNavigate} />
          )}

          {section === 'edit-post' && (
            <PostEditor
              postId={pageParams.id || null}
              onNavigate={handleNavigate}
            />
          )}

          {section === 'comments' && <CommentsSection />}

          {section === 'subscribers' && <SubscribersSection />}

          {section === 'messages' && <MessagesSection />}

          {section === 'settings' && <SettingsSection />}
        </div>
      </div>
    </div>
  )
}
