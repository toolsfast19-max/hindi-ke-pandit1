'use client'

import React, { useCallback, useRef } from 'react'
import {
  MDXEditor,
  headingsPlugin,
  listsPlugin,
  quotePlugin,
  linkPlugin,
  imagePlugin,
  tablePlugin,
  codeBlockPlugin,
  markdownShortcutPlugin,
  BoldItalicUnderlineToggles,
  ListsToggle,
  BlockTypeSelect,
  CreateLink,
  InsertImage,
  InsertTable,
  InsertThematicBreak,
  type MDXEditorMethods,
} from '@mdxeditor/editor'
import '@mdxeditor/editor/style.css'

interface MdxEditorClientProps {
  value: string
  onChange: (value: string) => void
  placeholder?: string
}

export function MdxEditorClient({ value, onChange, placeholder }: MdxEditorClientProps) {
  const editorRef = useRef<MDXEditorMethods>(null)

  const handleChange = useCallback((newContent: string) => {
    onChange(newContent)
  }, [onChange])

  return (
    <div className="mdx-editor-wrapper rounded-lg border border-input bg-background text-foreground shadow-sm focus-within:ring-2 focus-within:ring-ring focus-within:ring-offset-2 dark:focus-within:ring-offset-background">
      <style jsx global>{`
        .mdx-editor-wrapper .mdxeditor {
          --accentColor: hsl(var(--primary));
          --accentColorForeground: hsl(var(--primary-foreground));
          color-scheme: light;
        }
        .dark .mdx-editor-wrapper .mdxeditor {
          color-scheme: dark;
        }
        .mdx-editor-wrapper .mdxeditor-root-contenteditable {
          min-height: 400px;
          max-height: 600px;
          overflow-y: auto;
          padding: 1rem;
          font-size: 0.95rem;
          line-height: 1.75;
        }
        .mdx-editor-wrapper .mdxeditor-root-contenteditable h1,
        .mdx-editor-wrapper .mdxeditor-root-contenteditable h2,
        .mdx-editor-wrapper .mdxeditor-root-contenteditable h3 {
          font-weight: 700;
          margin-top: 1.5em;
          margin-bottom: 0.5em;
        }
        .mdx-editor-wrapper .mdxeditor-root-contenteditable h1 { font-size: 1.875rem; line-height: 1.2; }
        .mdx-editor-wrapper .mdxeditor-root-contenteditable h2 { font-size: 1.5rem; line-height: 1.3; }
        .mdx-editor-wrapper .mdxeditor-root-contenteditable h3 { font-size: 1.25rem; line-height: 1.4; }
        .mdx-editor-wrapper .mdxeditor-root-contenteditable p { margin-bottom: 0.75em; }
        .mdx-editor-wrapper .mdxeditor-root-contenteditable ul,
        .mdx-editor-wrapper .mdxeditor-root-contenteditable ol { padding-left: 1.5em; margin-bottom: 0.75em; }
        .mdx-editor-wrapper .mdxeditor-root-contenteditable blockquote {
          border-left: 4px solid hsl(var(--primary));
          padding-left: 1rem; margin: 1em 0; opacity: 0.85;
        }
        .mdx-editor-wrapper .mdxeditor-root-contenteditable code {
          background: hsl(var(--muted)); padding: 0.15em 0.4em; border-radius: 0.25rem; font-size: 0.9em;
        }
        .mdx-editor-wrapper .mdxeditor-root-contenteditable pre {
          background: hsl(var(--muted)); border-radius: 0.5rem; padding: 1rem; overflow-x: auto; margin: 1em 0;
        }
        .mdx-editor-wrapper .mdxeditor-root-contenteditable pre code { background: transparent; padding: 0; }
        .mdx-editor-wrapper .mdxeditor-root-contenteditable table { border-collapse: collapse; width: 100%; margin: 1em 0; }
        .mdx-editor-wrapper .mdxeditor-root-contenteditable th,
        .mdx-editor-wrapper .mdxeditor-root-contenteditable td { border: 1px solid hsl(var(--border)); padding: 0.5rem 0.75rem; text-align: left; }
        .mdx-editor-wrapper .mdxeditor-root-contenteditable th { background: hsl(var(--muted)); font-weight: 600; }
        .mdx-editor-wrapper .mdxeditor-root-contenteditable img { max-width: 100%; border-radius: 0.5rem; margin: 1em 0; }
        .mdx-editor-wrapper .mdxeditor-root-contenteditable a { color: hsl(var(--primary)); text-decoration: underline; }
        .mdx-editor-wrapper .mdxeditor-toolbar { border-bottom: 1px solid hsl(var(--border)); background: hsl(var(--card)); flex-wrap: wrap; gap: 2px; padding: 0.375rem; }
        .mdx-editor-wrapper [class*="_toolbarButton_"] {
          display: inline-flex; align-items: center; justify-content: center; width: 2rem; height: 2rem;
          border-radius: 0.375rem; color: hsl(var(--foreground)); transition: background-color 0.15s, color 0.15s;
          border: none; background: transparent; cursor: pointer;
        }
        .mdx-editor-wrapper [class*="_toolbarButton_"]:hover { background: hsl(var(--accent)); color: hsl(var(--accent-foreground)); }
        .mdx-editor-wrapper [class*="_separator_"] { display: inline-block; width: 1px; height: 1.5rem; background: hsl(var(--border)); margin: 0 0.25rem; vertical-align: middle; }
      `}</style>
      <MDXEditor
        ref={editorRef}
        className="mdxeditor"
        markdown={value}
        onChange={handleChange}
        contentEditableClassName="prose prose-sm dark:prose-invert max-w-none focus:outline-none"
        placeholder={placeholder || 'यहाँ अपना कंटेंट लिखें... (Markdown सपोर्ट)'}
        plugins={[
          headingsPlugin(),
          listsPlugin(),
          quotePlugin(),
          markdownShortcutPlugin(),
          linkPlugin(),
          imagePlugin({
            imageUploadHandler: async () => '',
          }),
          tablePlugin(),
          codeBlockPlugin({ defaultTabSize: 2 }),
        ]}
        toolbarContents={() => (
          <>
            <BoldItalicUnderlineToggles />
            <ListsToggle />
            <BlockTypeSelect />
            <CreateLink />
            <InsertImage />
            <InsertTable />
            <InsertThematicBreak />
          </>
        )}
      />
    </div>
  )
}
