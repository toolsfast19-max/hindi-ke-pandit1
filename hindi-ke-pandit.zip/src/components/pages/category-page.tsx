'use client'

import React, { useState } from 'react'
import { useQuery } from '@tanstack/react-query'
import { motion } from 'framer-motion'
import {
  TrendingUp,
  Wheat,
  Cpu,
  ArrowLeft,
  ArrowRight,
  Newspaper,
  BookOpen,
} from 'lucide-react'
import { Button } from '@/components/ui/button'
import { Badge } from '@/components/ui/badge'
import { Skeleton } from '@/components/ui/skeleton'
import { useAppStore } from '@/store'
import { PostCard } from '@/components/shared/post-card'
import type { Post } from '@/lib/types'

const categoryMeta: Record<string, { nameHindi: string; icon: React.ElementType; color: string; description: string }> = {
  'share-market': {
    nameHindi: 'शेयर मार्केट',
    icon: TrendingUp,
    color: '#16a34a',
    description: 'निवेश टिप्स, स्टॉक एनालिसिस, मार्केट अपडेट और वित्तीय सलाह',
  },
  krishi: {
    nameHindi: 'कृषि',
    icon: Wheat,
    color: '#ca8a04',
    description: 'आधुनिक खेती तकनीक, सरकारी योजनाएं, फसल गाइड और कृषि समाचार',
  },
  technology: {
    nameHindi: 'टेक्नोलॉजी',
    icon: Cpu,
    color: '#0891b2',
    description: 'AI, गैजेट रिव्यू, सॉफ्टवेयर टिप्स और तकनीकी अपडेट',
  },
}

const POSTS_PER_PAGE = 12

function PostsGridSkeleton() {
  return (
    <div className="grid gap-6 sm:grid-cols-2 lg:grid-cols-3">
      {[1, 2, 3, 4, 5, 6, 7, 8, 9].map((i) => (
        <div key={i} className="overflow-hidden rounded-xl border bg-card shadow-sm">
          <Skeleton className="aspect-video w-full" />
          <div className="space-y-3 p-4">
            <Skeleton className="h-4 w-24" />
            <Skeleton className="h-5 w-full" />
            <Skeleton className="h-5 w-3/4" />
            <Skeleton className="h-4 w-full" />
            <div className="flex gap-3">
              <Skeleton className="h-3 w-20" />
              <Skeleton className="h-3 w-16" />
              <Skeleton className="h-3 w-16" />
            </div>
          </div>
        </div>
      ))}
    </div>
  )
}

export function CategoryPage() {
  const { pageParams, navigate } = useAppStore()
  const categorySlug = pageParams.category || ''
  const [page, setPage] = useState(1)

  const category = categoryMeta[categorySlug] || {
    nameHindi: 'सभी लेख',
    icon: BookOpen,
    color: '#6b7280',
    description: 'हिंदी के पंडित पर प्रकाशित सभी लेख',
  }

  const Icon = category.icon

  const buildQueryUrl = (p: number) => {
    let url = `/api/posts?published=true&page=${p}&limit=${POSTS_PER_PAGE}`
    if (categorySlug && categorySlug !== 'all') {
      url += `&category=${categorySlug}`
    }
    return url
  }

  const {
    data,
    isLoading,
    isError,
  } = useQuery<{ posts: Post[]; total: number; page: number; limit: number; totalPages: number }>({
    queryKey: ['category-posts', categorySlug, page],
    queryFn: () => fetch(buildQueryUrl(page)).then((r) => r.json()),
  })

  const posts = data?.posts || []
  const totalPages = data?.totalPages || 1
  const total = data?.total || 0

  const goToPage = (p: number) => {
    setPage(p)
    window.scrollTo({ top: 0, behavior: 'smooth' })
  }

  return (
    <motion.div
      className="mx-auto max-w-7xl px-4 py-8 sm:px-6 lg:px-8"
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.5 }}
    >
      {/* Back Button */}
      <Button
        variant="ghost"
        onClick={() => navigate('home')}
        className="mb-6 gap-2 text-muted-foreground hover:text-foreground"
      >
        <ArrowLeft className="h-4 w-4" />
        होम पेज पर जाएं
      </Button>

      {/* Category Header */}
      <div
        className="relative mb-10 overflow-hidden rounded-2xl border p-6 sm:p-8"
        style={{
          background: `linear-gradient(135deg, ${category.color}08 0%, ${category.color}15 100%)`,
          borderColor: `${category.color}30`,
        }}
      >
        <div className="flex items-center gap-4">
          <div
            className="flex h-14 w-14 shrink-0 items-center justify-center rounded-xl"
            style={{ backgroundColor: `${category.color}20` }}
          >
            <Icon className="h-7 w-7" style={{ color: category.color }} />
          </div>
          <div className="flex-1">
            <h1 className="text-2xl font-bold sm:text-3xl">{category.nameHindi}</h1>
            <p className="mt-1 text-sm text-muted-foreground sm:text-base">
              {category.description}
            </p>
            {total > 0 && (
              <Badge
                variant="secondary"
                className="mt-2"
                style={{
                  backgroundColor: `${category.color}15`,
                  color: category.color,
                }}
              >
                {total} लेख
              </Badge>
            )}
          </div>
        </div>
      </div>

      {/* Posts Grid */}
      {isLoading ? (
        <PostsGridSkeleton />
      ) : isError ? (
        <div className="rounded-xl border border-dashed bg-muted/30 p-8 text-center">
          <Newspaper className="mx-auto mb-3 h-10 w-10 text-muted-foreground/50" />
          <p className="text-muted-foreground">लेख लोड करने में त्रुटि हुई। कृपया पुनः प्रयास करें।</p>
        </div>
      ) : posts.length > 0 ? (
        <>
          <div className="grid gap-6 sm:grid-cols-2 lg:grid-cols-3">
            {posts.map((post) => (
              <PostCard key={post.id} post={post} />
            ))}
          </div>

          {/* Pagination */}
          {totalPages > 1 && (
            <div className="mt-10 flex items-center justify-center gap-2">
              <Button
                variant="outline"
                size="sm"
                disabled={page <= 1}
                onClick={() => goToPage(page - 1)}
                className="gap-1"
              >
                <ArrowLeft className="h-4 w-4" />
                पिछला
              </Button>

              <div className="flex items-center gap-1">
                {Array.from({ length: totalPages }, (_, i) => i + 1).map((p) => (
                  <Button
                    key={p}
                    variant={p === page ? 'default' : 'outline'}
                    size="sm"
                    onClick={() => goToPage(p)}
                    className="w-9"
                  >
                    {p}
                  </Button>
                ))}
              </div>

              <Button
                variant="outline"
                size="sm"
                disabled={page >= totalPages}
                onClick={() => goToPage(page + 1)}
                className="gap-1"
              >
                अगला
                <ArrowRight className="h-4 w-4" />
              </Button>
            </div>
          )}
        </>
      ) : (
        <div className="rounded-xl border border-dashed bg-muted/30 p-12 text-center">
          <BookOpen className="mx-auto mb-3 h-12 w-12 text-muted-foreground/50" />
          <h3 className="mb-1 text-lg font-semibold">कोई लेख नहीं मिला</h3>
          <p className="text-sm text-muted-foreground">
            इस श्रेणी में अभी कोई लेख प्रकाशित नहीं हुआ है।
          </p>
        </div>
      )}
    </motion.div>
  )
}
