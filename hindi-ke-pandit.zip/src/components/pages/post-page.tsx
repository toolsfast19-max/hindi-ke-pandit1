'use client'

import React, { useState, useMemo, useEffect, useRef } from 'react'
import { useQuery, useQueryClient } from '@tanstack/react-query'
import { motion } from 'framer-motion'
import ReactMarkdown from 'react-markdown'
import {
  ArrowLeft,
  Calendar,
  Clock,
  Eye,
  User,
  Share2,
  MessageSquare,
  Send,
  Loader2,
  Copy,
  Check,
  ChevronRight,
  BookOpen,
  TrendingUp,
  Wheat,
  Cpu,
  ThumbsUp,
  Link as LinkIcon,
} from 'lucide-react'
import { Button } from '@/components/ui/button'
import { Badge } from '@/components/ui/badge'
import { Input } from '@/components/ui/input'
import { Textarea } from '@/components/ui/textarea'
import { Skeleton } from '@/components/ui/skeleton'
import { Separator } from '@/components/ui/separator'
import {
  Breadcrumb,
  BreadcrumbList,
  BreadcrumbItem,
  BreadcrumbLink,
  BreadcrumbPage,
  BreadcrumbSeparator,
} from '@/components/ui/breadcrumb'
import { useAppStore } from '@/store'
import { PostCard } from '@/components/shared/post-card'
import { toast } from 'sonner'
import type { Post, Comment } from '@/lib/types'

const categoryNames: Record<string, string> = {
  'share-market': 'शेयर मार्केट',
  krishi: 'कृषि',
  technology: 'टेक्नोलॉजी',
}

const categoryColors: Record<string, string> = {
  'share-market': '#16a34a',
  krishi: '#ca8a04',
  technology: '#0891b2',
}

const hindiMonths = [
  'जनवरी', 'फरवरी', 'मार्च', 'अप्रैल', 'मई', 'जून',
  'जुलाई', 'अगस्त', 'सितंबर', 'अक्टूबर', 'नवंबर', 'दिसंबर',
]

function formatDateHindi(dateStr: string): string {
  const date = new Date(dateStr)
  const day = date.getDate()
  const month = hindiMonths[date.getMonth()]
  const year = date.getFullYear()
  return `${day} ${month} ${year}`
}

function estimateReadTime(content: string): number {
  const wordsPerMinute = 200
  const textContent = content.replace(/<[^>]*>/g, '').replace(/[#*_\[\]()>`]/g, '')
  const wordCount = textContent.split(/\s+/).filter(Boolean).length
  const minutes = Math.ceil(wordCount / wordsPerMinute)
  return Math.max(1, minutes)
}

interface TOCItem {
  id: string
  text: string
  level: number
}

function extractTOC(content: string): TOCItem[] {
  const lines = content.split('\n')
  const toc: TOCItem[] = []
  for (const line of lines) {
    const match = line.match(/^(#{2,3})\s+(.+)/)
    if (match) {
      const level = match[1].length
      const text = match[2].replace(/[*_`[\]]/g, '').trim()
      const id = text
        .toLowerCase()
        .replace(/[^\w\s-]/g, '')
        .replace(/\s+/g, '-')
        .replace(/-+/g, '-')
      toc.push({ id, text, level })
    }
  }
  return toc
}

function PostSkeleton() {
  return (
    <div className="mx-auto max-w-7xl px-4 py-8 sm:px-6 lg:px-8">
      <Skeleton className="h-4 w-48 mb-6" />
      <Skeleton className="aspect-video w-full max-w-4xl mx-auto rounded-2xl mb-8" />
      <div className="max-w-4xl mx-auto space-y-4">
        <Skeleton className="h-8 w-3/4" />
        <div className="flex gap-4">
          <Skeleton className="h-4 w-32" />
          <Skeleton className="h-4 w-28" />
          <Skeleton className="h-4 w-24" />
        </div>
        <div className="space-y-3 mt-8">
          {[1, 2, 3, 4, 5, 6].map((i) => (
            <Skeleton key={i} className="h-4 w-full" />
          ))}
        </div>
      </div>
    </div>
  )
}

export function PostPage() {
  const { pageParams, navigate } = useAppStore()
  const slug = pageParams.slug || ''
  const queryClient = useQueryClient()

  const [commentName, setCommentName] = useState('')
  const [commentEmail, setCommentEmail] = useState('')
  const [commentContent, setCommentContent] = useState('')
  const [submittingComment, setSubmittingComment] = useState(false)
  const [linkCopied, setLinkCopied] = useState(false)
  const [activeHeading, setActiveHeading] = useState('')

  const postContentRef = useRef<HTMLDivElement>(null)

  const { data: postData, isLoading: postLoading } = useQuery<{ post: Post }>({
    queryKey: ['post', slug],
    queryFn: () => fetch(`/api/posts?slug=${encodeURIComponent(slug)}`).then((r) => r.json()),
    enabled: !!slug,
  })

  const post = postData?.post

  const postCategorySlug = post?.category?.slug || ''
  const postCategoryName = post?.category?.nameHindi || categoryNames[postCategorySlug] || ''
  const postCategoryColor = post?.category?.color || categoryColors[postCategorySlug] || '#6b7280'

  const { data: commentsData } = useQuery<{ comments: Comment[] }>({
    queryKey: ['comments', post?.id],
    queryFn: () => fetch(`/api/comments?postId=${post!.id}&approved=true`).then((r) => r.json()),
    enabled: !!post?.id,
  })

  const { data: relatedData } = useQuery<{ posts: Post[] }>({
    queryKey: ['related-posts', postCategorySlug, post?.id],
    queryFn: () =>
      fetch(`/api/posts?category=${postCategorySlug}&published=true&limit=3`).then((r) => r.json()),
    enabled: !!postCategorySlug,
  })

  const relatedPosts = useMemo(() => {
    if (!relatedData?.posts || !post) return []
    return relatedData.posts.filter((p) => p.id !== post.id).slice(0, 3)
  }, [relatedData, post])

  const toc = useMemo(() => {
    if (!post?.content) return []
    return extractTOC(post.content)
  }, [post?.content])

  const readTime = useMemo(() => {
    if (!post?.content) return 1
    return estimateReadTime(post.content)
  }, [post?.content])

  // Scroll spy for TOC
  useEffect(() => {
    const container = postContentRef.current
    if (!container || toc.length === 0) return

    const headings = container.querySelectorAll('h2, h3')
    if (headings.length === 0) return

    const observer = new IntersectionObserver(
      (entries) => {
        for (const entry of entries) {
          if (entry.isIntersecting) {
            setActiveHeading(entry.target.id)
          }
        }
      },
      { rootMargin: '-80px 0px -60% 0px', threshold: 0 }
    )

    headings.forEach((heading) => observer.observe(heading))
    return () => observer.disconnect()
  }, [toc.length, post?.content])

  const handleCommentSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    if (!post || !commentName || !commentEmail || !commentContent) return

    setSubmittingComment(true)
    try {
      const res = await fetch('/api/comments', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          name: commentName,
          email: commentEmail,
          content: commentContent,
          postId: post.id,
        }),
      })
      if (res.ok) {
        toast.success('टिप्पणी सबमिट हो गई!', {
          description: 'आपकी टिप्पणी समीक्षा के बाद प्रकाशित की जाएगी।',
        })
        setCommentName('')
        setCommentEmail('')
        setCommentContent('')
        queryClient.invalidateQueries({ queryKey: ['comments', post.id] })
      } else {
        const data = await res.json()
        toast.error('त्रुटि', { description: data.error || 'कृपया पुनः प्रयास करें।' })
      }
    } catch {
      toast.error('त्रुटि', { description: 'नेटवर्क त्रुटि। कृपया बाद में पुनः प्रयास करें।' })
    } finally {
      setSubmittingComment(false)
    }
  }

  const handleCopyLink = () => {
    navigator.clipboard.writeText(window.location.href)
    setLinkCopied(true)
    toast.success('लिंक कॉपी हो गया!')
    setTimeout(() => setLinkCopied(false), 2000)
  }

  const shareUrl = typeof window !== 'undefined' ? window.location.href : ''
  const shareTitle = post?.title || ''

  const scrollToHeading = (id: string) => {
    const el = document.getElementById(id)
    if (el) {
      el.scrollIntoView({ behavior: 'smooth', block: 'start' })
    }
  }

  if (postLoading) return <PostSkeleton />

  if (!post) {
    return (
      <div className="mx-auto max-w-7xl px-4 py-8 sm:px-6 lg:px-8">
        <Button variant="ghost" onClick={() => navigate('home')} className="mb-6 gap-2">
          <ArrowLeft className="h-4 w-4" />
          होम पेज पर जाएं
        </Button>
        <div className="rounded-xl border border-dashed bg-muted/30 p-12 text-center">
          <BookOpen className="mx-auto mb-3 h-12 w-12 text-muted-foreground/50" />
          <h3 className="mb-1 text-lg font-semibold">लेख नहीं मिला</h3>
          <p className="text-sm text-muted-foreground">आप जो लेख खोज रहे हैं वह मौजूद नहीं है।</p>
        </div>
      </div>
    )
  }

  return (
    <motion.div
      className="mx-auto max-w-7xl px-4 py-8 sm:px-6 lg:px-8"
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.5 }}
    >
      {/* Back Button */}
      <Button
        variant="ghost"
        onClick={() => navigate('home')}
        className="mb-6 gap-2 text-muted-foreground hover:text-foreground"
      >
        <ArrowLeft className="h-4 w-4" />
        होम पेज पर जाएं
      </Button>

      {/* Breadcrumb */}
      <Breadcrumb className="mb-6">
        <BreadcrumbList>
          <BreadcrumbItem>
            <BreadcrumbLink
              onClick={() => navigate('home')}
              className="cursor-pointer text-muted-foreground hover:text-foreground"
            >
              होम
            </BreadcrumbLink>
          </BreadcrumbItem>
          <BreadcrumbSeparator />
          <BreadcrumbItem>
            <BreadcrumbLink
              onClick={() => navigate('category', { category: postCategorySlug })}
              className="cursor-pointer text-muted-foreground hover:text-foreground"
            >
              {postCategoryName}
            </BreadcrumbLink>
          </BreadcrumbItem>
          <BreadcrumbSeparator />
          <BreadcrumbItem>
            <BreadcrumbPage className="line-clamp-1 max-w-[200px] sm:max-w-[400px]">
              {post.title}
            </BreadcrumbPage>
          </BreadcrumbItem>
        </BreadcrumbList>
      </Breadcrumb>

      <div className="flex flex-col gap-8 lg:flex-row">
        {/* Main Content */}
        <div className="min-w-0 flex-1">
          {/* Cover Image */}
          {post.coverImage && (
            <div className="mb-8 overflow-hidden rounded-2xl border shadow-sm">
              <img
                src={post.coverImage}
                alt={post.title}
                className="h-auto max-h-[500px] w-full object-cover"
              />
            </div>
          )}

          {/* Title */}
          <h1 className="mb-4 text-2xl font-bold leading-tight tracking-tight sm:text-3xl lg:text-4xl">
            {post.title}
          </h1>

          {/* Meta */}
          <div className="mb-6 flex flex-wrap items-center gap-3 text-sm text-muted-foreground">
            <Badge
              className="border-0"
              style={{ backgroundColor: postCategoryColor }}
            >
              {postCategoryName}
            </Badge>
            <Separator orientation="vertical" className="h-4" />
            <span className="flex items-center gap-1.5">
              <Calendar className="h-4 w-4" />
              {formatDateHindi(post.createdAt)}
            </span>
            <Separator orientation="vertical" className="h-4" />
            <span className="flex items-center gap-1.5">
              <User className="h-4 w-4" />
              हिंदी के पंडित टीम
            </span>
            <Separator orientation="vertical" className="h-4" />
            <span className="flex items-center gap-1.5">
              <Clock className="h-4 w-4" />
              {readTime} मिनट पढ़ें
            </span>
            <Separator orientation="vertical" className="h-4" />
            <span className="flex items-center gap-1.5">
              <Eye className="h-4 w-4" />
              {post.viewCount > 1000 ? `${(post.viewCount / 1000).toFixed(1)}K` : post.viewCount} बार देखा
            </span>
          </div>

          <Separator className="mb-8" />

          {/* Post Content (Markdown) */}
          <article
            ref={postContentRef}
            className="prose prose-lg prose-neutral dark:prose-invert max-w-none
              prose-headings:scroll-mt-20
              prose-h2:text-2xl prose-h2:font-bold prose-h2:mt-10 prose-h2:mb-4
              prose-h3:text-xl prose-h3:font-semibold prose-h3:mt-8 prose-h3:mb-3
              prose-p:leading-relaxed
              prose-a:text-emerald-600 dark:prose-a:text-emerald-400 prose-a:no-underline hover:prose-a:underline
              prose-blockquote:border-l-4 prose-blockquote:border-emerald-500 prose-blockquote:bg-emerald-50 dark:prose-blockquote:bg-emerald-950/20 prose-blockquote:rounded-r-lg prose-blockquote:py-2 prose-blockquote:px-4
              prose-code:rounded prose-code:bg-muted prose-code:px-1.5 prose-code:py-0.5 prose-code:text-sm prose-code:before:content-none prose-code:after:content-none
              prose-pre:rounded-xl prose-pre:border prose-pre:bg-muted
              prose-img:rounded-xl prose-img:shadow-sm
              prose-table:overflow-x-auto
              prose-th:bg-muted prose-th:px-4 prose-th:py-2 prose-th:text-left
              prose-td:px-4 prose-td:py-2 prose-td:border-b
              prose-li:marker:text-emerald-600 dark:prose-li:marker:text-emerald-400
              prose-hr:border-muted
              prose-strong:text-foreground"
          >
            <ReactMarkdown>
              {post.content}
            </ReactMarkdown>
          </article>

          <Separator className="my-8" />

          {/* Author Bio */}
          <div className="rounded-2xl border bg-card p-6 shadow-sm">
            <div className="flex items-start gap-4">
              <div className="flex h-14 w-14 shrink-0 items-center justify-center rounded-full bg-gradient-to-br from-emerald-500 to-cyan-500 text-white">
                <BookOpen className="h-7 w-7" />
              </div>
              <div>
                <h3 className="text-lg font-bold">हिंदी के पंडित टीम</h3>
                <p className="mt-1 text-sm leading-relaxed text-muted-foreground">
                  हिंदी के पंडित टीम शेयर मार्केट, कृषि और टेक्नोलॉजी जैसे विषयों पर
                  गुणवत्तापूर्ण हिंदी सामग्री प्रदान करने के लिए समर्पित है। हमारा लक्ष्य
                  हर पाठक को सही और सरल जानकारी उपलब्ध कराना है।
                </p>
              </div>
            </div>
          </div>

          {/* Social Share */}
          <div className="mt-8">
            <h3 className="mb-4 text-lg font-bold flex items-center gap-2">
              <Share2 className="h-5 w-5" />
              शेयर करें
            </h3>
            <div className="flex flex-wrap gap-2">
              <Button
                variant="outline"
                size="sm"
                className="gap-2 border-green-300 text-green-700 hover:bg-green-50 dark:border-green-700 dark:text-green-400"
                onClick={() => window.open(`https://wa.me/?text=${encodeURIComponent(shareTitle + ' ' + shareUrl)}`, '_blank')}
              >
                <svg className="h-4 w-4" viewBox="0 0 24 24" fill="currentColor"><path d="M17.472 14.382c-.297-.149-1.758-.867-2.03-.967-.273-.099-.471-.148-.67.15-.197.297-.767.966-.94 1.164-.173.199-.347.223-.644.075-.297-.15-1.255-.463-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.298-.347.446-.52.149-.174.198-.298.298-.497.099-.198.05-.371-.025-.52-.075-.149-.669-1.612-.916-2.207-.242-.579-.487-.5-.669-.51-.173-.008-.371-.01-.57-.01-.198 0-.52.074-.792.372-.272.297-1.04 1.016-1.04 2.479 0 1.462 1.065 2.875 1.213 3.074.149.198 2.096 3.2 5.077 4.487.709.306 1.262.489 1.694.625.712.227 1.36.195 1.871.118.571-.085 1.758-.719 2.006-1.413.248-.694.248-1.289.173-1.413-.074-.124-.272-.198-.57-.347m-5.421 7.403h-.004a9.87 9.87 0 01-5.031-1.378l-.361-.214-3.741.982.998-3.648-.235-.374a9.86 9.86 0 01-1.51-5.26c.001-5.45 4.436-9.884 9.888-9.884 2.64 0 5.122 1.03 6.988 2.898a9.825 9.825 0 012.893 6.994c-.003 5.45-4.437 9.884-9.885 9.884m8.413-18.297A11.815 11.815 0 0012.05 0C5.495 0 .16 5.335.157 11.892c0 2.096.547 4.142 1.588 5.945L.057 24l6.305-1.654a11.882 11.882 0 005.683 1.448h.005c6.554 0 11.89-5.335 11.893-11.893a11.821 11.821 0 00-3.48-8.413z"/></svg>
                WhatsApp
              </Button>
              <Button
                variant="outline"
                size="sm"
                className="gap-2 border-sky-300 text-sky-700 hover:bg-sky-50 dark:border-sky-700 dark:text-sky-400"
                onClick={() => window.open(`https://twitter.com/intent/tweet?text=${encodeURIComponent(shareTitle)}&url=${encodeURIComponent(shareUrl)}`, '_blank')}
              >
                <svg className="h-4 w-4" viewBox="0 0 24 24" fill="currentColor"><path d="M18.244 2.25h3.308l-7.227 8.26 8.502 11.24H16.17l-5.214-6.817L4.99 21.75H1.68l7.73-8.835L1.254 2.25H8.08l4.713 6.231zm-1.161 17.52h1.833L7.084 4.126H5.117z"/></svg>
                Twitter
              </Button>
              <Button
                variant="outline"
                size="sm"
                className="gap-2 border-blue-300 text-blue-700 hover:bg-blue-50 dark:border-blue-700 dark:text-blue-400"
                onClick={() => window.open(`https://www.facebook.com/sharer/sharer.php?u=${encodeURIComponent(shareUrl)}`, '_blank')}
              >
                <svg className="h-4 w-4" viewBox="0 0 24 24" fill="currentColor"><path d="M24 12.073c0-6.627-5.373-12-12-12s-12 5.373-12 12c0 5.99 4.388 10.954 10.125 11.854v-8.385H7.078v-3.47h3.047V9.43c0-3.007 1.792-4.669 4.533-4.669 1.312 0 2.686.235 2.686.235v2.953H15.83c-1.491 0-1.956.925-1.956 1.874v2.25h3.328l-.532 3.47h-2.796v8.385C19.612 23.027 24 18.062 24 12.073z"/></svg>
                Facebook
              </Button>
              <Button
                variant="outline"
                size="sm"
                className="gap-2 border-blue-400 text-blue-800 hover:bg-blue-50 dark:border-blue-600 dark:text-blue-300"
                onClick={() => window.open(`https://www.linkedin.com/sharing/share-offsite/?url=${encodeURIComponent(shareUrl)}`, '_blank')}
              >
                <svg className="h-4 w-4" viewBox="0 0 24 24" fill="currentColor"><path d="M20.447 20.452h-3.554v-5.569c0-1.328-.027-3.037-1.852-3.037-1.853 0-2.136 1.445-2.136 2.939v5.667H9.351V9h3.414v1.561h.046c.477-.9 1.637-1.85 3.37-1.85 3.601 0 4.267 2.37 4.267 5.455v6.286zM5.337 7.433c-1.144 0-2.063-.926-2.063-2.065 0-1.138.92-2.063 2.063-2.063 1.14 0 2.064.925 2.064 2.063 0 1.139-.925 2.065-2.064 2.065zm1.782 13.019H3.555V9h3.564v11.452zM22.225 0H1.771C.792 0 0 .774 0 1.729v20.542C0 23.227.792 24 1.771 24h20.451C23.2 24 24 23.227 24 22.271V1.729C24 .774 23.2 0 22.222 0h.003z"/></svg>
                LinkedIn
              </Button>
              <Button
                variant="outline"
                size="sm"
                className="gap-2"
                onClick={handleCopyLink}
              >
                {linkCopied ? <Check className="h-4 w-4" /> : <Copy className="h-4 w-4" />}
                {linkCopied ? 'कॉपी हो गया!' : 'लिंक कॉपी करें'}
              </Button>
            </div>
          </div>

          {/* Comments Section */}
          <div className="mt-10">
            <Separator className="mb-8" />
            <h3 className="mb-6 text-xl font-bold flex items-center gap-2">
              <MessageSquare className="h-5 w-5" />
              टिप्पणियाँ
              {commentsData?.comments && (
                <Badge variant="secondary" className="ml-1">
                  {commentsData.comments.length}
                </Badge>
              )}
            </h3>

            {/* Comment List */}
            {commentsData?.comments && commentsData.comments.length > 0 && (
              <div className="mb-8 space-y-4">
                {commentsData.comments.map((comment) => (
                  <div key={comment.id} className="rounded-xl border bg-muted/30 p-4">
                    <div className="flex items-center gap-3 mb-2">
                      <div className="flex h-8 w-8 items-center justify-center rounded-full bg-gradient-to-br from-emerald-400 to-cyan-400 text-xs font-bold text-white">
                        {comment.name.charAt(0).toUpperCase()}
                      </div>
                      <div>
                        <span className="text-sm font-semibold">{comment.name}</span>
                        <span className="ml-2 text-xs text-muted-foreground">
                          {formatDateHindi(comment.createdAt)}
                        </span>
                      </div>
                    </div>
                    <p className="text-sm leading-relaxed text-muted-foreground pl-11">
                      {comment.content}
                    </p>
                  </div>
                ))}
              </div>
            )}

            {/* Comment Form */}
            <div className="rounded-2xl border bg-card p-6 shadow-sm">
              <h4 className="mb-4 font-semibold">टिप्पणी जोड़ें</h4>
              <form onSubmit={handleCommentSubmit} className="space-y-4">
                <div className="grid gap-4 sm:grid-cols-2">
                  <div className="space-y-2">
                    <label className="text-sm font-medium">नाम *</label>
                    <Input
                      placeholder="अपना नाम दर्ज करें"
                      value={commentName}
                      onChange={(e) => setCommentName(e.target.value)}
                      required
                    />
                  </div>
                  <div className="space-y-2">
                    <label className="text-sm font-medium">ईमेल *</label>
                    <Input
                      type="email"
                      placeholder="अपना ईमेल दर्ज करें"
                      value={commentEmail}
                      onChange={(e) => setCommentEmail(e.target.value)}
                      required
                    />
                  </div>
                </div>
                <div className="space-y-2">
                  <label className="text-sm font-medium">टिप्पणी *</label>
                  <Textarea
                    placeholder="अपनी टिप्पणी यहाँ लिखें..."
                    rows={4}
                    value={commentContent}
                    onChange={(e) => setCommentContent(e.target.value)}
                    required
                  />
                </div>
                <Button
                  type="submit"
                  disabled={submittingComment || !commentName || !commentEmail || !commentContent}
                  className="gap-2"
                >
                  {submittingComment ? (
                    <Loader2 className="h-4 w-4 animate-spin" />
                  ) : (
                    <Send className="h-4 w-4" />
                  )}
                  टिप्पणी भेजें
                </Button>
              </form>
            </div>
          </div>

          {/* Related Posts */}
          {relatedPosts.length > 0 && (
            <div className="mt-12">
              <Separator className="mb-8" />
              <h3 className="mb-6 text-xl font-bold flex items-center gap-2">
                <BookOpen className="h-5 w-5" />
                संबंधित लेख
              </h3>
              <div className="grid gap-6 sm:grid-cols-2 lg:grid-cols-3">
                {relatedPosts.map((relPost) => (
                  <PostCard key={relPost.id} post={relPost} />
                ))}
              </div>
            </div>
          )}
        </div>

        {/* Sidebar - TOC (Desktop) */}
        {toc.length > 0 && (
          <aside className="hidden lg:block lg:w-72 xl:w-80">
            <div className="sticky top-24">
              <div className="rounded-2xl border bg-card p-5 shadow-sm">
                <h4 className="mb-4 font-semibold flex items-center gap-2">
                  <BookOpen className="h-4 w-4" />
                  विषय सूची
                </h4>
                <nav className="space-y-1">
                  {toc.map((item) => (
                    <button
                      key={item.id}
                      onClick={() => scrollToHeading(item.id)}
                      className={`block w-full text-left rounded-lg px-3 py-2 text-sm transition-colors ${
                        activeHeading === item.id
                          ? 'bg-emerald-100 font-medium text-emerald-700 dark:bg-emerald-950/40 dark:text-emerald-400'
                          : 'text-muted-foreground hover:bg-muted hover:text-foreground'
                      } ${item.level === 3 ? 'pl-7' : ''}`}
                    >
                      {item.text}
                    </button>
                  ))}
                </nav>
              </div>
            </div>
          </aside>
        )}
      </div>
    </motion.div>
  )
}
