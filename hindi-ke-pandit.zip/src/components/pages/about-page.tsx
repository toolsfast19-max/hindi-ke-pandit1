'use client'

import React from 'react'
import { useQuery } from '@tanstack/react-query'
import { motion } from 'framer-motion'
import {
  TrendingUp,
  Wheat,
  Cpu,
  BookOpen,
  Users,
  Eye,
  PenTool,
  Target,
  Heart,
  Mail,
  ArrowRight,
} from 'lucide-react'
import { Button } from '@/components/ui/button'
import { Card, CardContent } from '@/components/ui/card'
import { Separator } from '@/components/ui/separator'
import { Skeleton } from '@/components/ui/skeleton'
import { useAppStore } from '@/store'

const topics = [
  {
    icon: TrendingUp,
    title: 'शेयर मार्केट',
    description: 'स्टॉक मार्केट की जानकारी, निवेश सलाह, IPO गाइड, म्यूचुअल फंड, और वित्तीय नियोजन',
    color: '#16a34a',
  },
  {
    icon: Wheat,
    title: 'कृषि',
    description: 'आधुनिक खेती तकनीक, सरकारी योजनाएं, फसल प्रबंधन, कृषि बाजार भाव, और जैविक खेती',
    color: '#ca8a04',
  },
  {
    icon: Cpu,
    title: 'टेक्नोलॉजी',
    description: 'कृत्रिम बुद्धिमत्ता, गैजेट रिव्यू, सॉफ्टवेयर टिप्स, साइबर सुरक्षा, और डिजिटल अपडेट',
    color: '#0891b2',
  },
]

export function AboutPage() {
  const { navigate } = useAppStore()

  const { data: statsData, isLoading: statsLoading } = useQuery<{
    stats: {
      totalPosts: number
      publishedPosts: number
      totalViews: number
      totalSubscribers: number
    }
  }>({
    queryKey: ['dashboard-stats'],
    queryFn: () => fetch('/api/dashboard').then((r) => r.json()),
  })

  const totalPosts = statsData?.stats?.publishedPosts || 0
  const totalViews = statsData?.stats?.totalViews || 0
  const totalSubscribers = statsData?.stats?.totalSubscribers || 0

  const statCards = [
    {
      icon: PenTool,
      label: 'लेख',
      value: `${totalPosts}+`,
      color: '#16a34a',
    },
    {
      icon: Eye,
      label: 'पाठक',
      value: totalViews > 1000 ? `${(totalViews / 1000).toFixed(0)}K+` : `${totalViews}+`,
      color: '#0891b2',
    },
    {
      icon: Users,
      label: 'सब्सक्राइबर',
      value: `${totalSubscribers}+`,
      color: '#ca8a04',
    },
    {
      icon: BookOpen,
      label: 'श्रेणियाँ',
      value: '3',
      color: '#8b5cf6',
    },
  ]

  return (
    <motion.div
      className="mx-auto max-w-4xl px-4 py-8 sm:px-6 lg:px-8"
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.5 }}
    >
      {/* Header */}
      <div className="mb-10 text-center">
        <div className="mx-auto mb-4 flex h-16 w-16 items-center justify-center rounded-2xl bg-gradient-to-br from-emerald-500 to-cyan-500 shadow-lg">
          <BookOpen className="h-8 w-8 text-white" />
        </div>
        <h1 className="mb-3 text-3xl font-bold tracking-tight sm:text-4xl">
          हमारे बारे में
        </h1>
        <p className="mx-auto max-w-2xl text-base text-muted-foreground sm:text-lg">
          हिंदी भाषा में गुणवत्तापूर्ण सामग्री का स्रोत
        </p>
      </div>

      {/* Mission */}
      <Card className="mb-8 overflow-hidden">
        <CardContent className="p-6 sm:p-8">
          <div className="flex items-start gap-4">
            <div className="flex h-12 w-12 shrink-0 items-center justify-center rounded-xl bg-emerald-100 dark:bg-emerald-950/40">
              <Target className="h-6 w-6 text-emerald-600 dark:text-emerald-400" />
            </div>
            <div>
              <h2 className="mb-2 text-xl font-bold">हमारा मिशन</h2>
              <p className="leading-relaxed text-muted-foreground">
                &quot;हिंदी के पंडित&quot; का मिशन है शेयर मार्केट, कृषि और टेक्नोलॉजी जैसे
                महत्वपूर्ण विषयों पर गुणवत्तापूर्ण, सटीक और सरल हिंदी सामग्री प्रदान करना।
                हम चाहते हैं कि हर हिंदी भाषी पाठक को तकनीकी और विशेषज्ञ जानकारी
                आसानी से समझ में आए।
              </p>
              <p className="mt-3 leading-relaxed text-muted-foreground">
                हम मानते हैं कि भाषा कभी ज्ञान की बाधा नहीं होनी चाहिए। इसलिए हम
                जटिल विषयों को सरल हिंदी में समझाने का प्रयास करते हैं।
              </p>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* What We Cover */}
      <div className="mb-8">
        <h2 className="mb-6 text-center text-2xl font-bold">हम क्या कवर करते हैं</h2>
        <div className="grid gap-6 sm:grid-cols-3">
          {topics.map((topic) => {
            const Icon = topic.icon
            return (
              <motion.div
                key={topic.title}
                whileHover={{ y: -4 }}
                transition={{ duration: 0.2 }}
              >
                <Card className="h-full border transition-shadow hover:shadow-md">
                  <CardContent className="p-6">
                    <div
                      className="mb-4 flex h-12 w-12 items-center justify-center rounded-xl"
                      style={{ backgroundColor: `${topic.color}15` }}
                    >
                      <Icon className="h-6 w-6" style={{ color: topic.color }} />
                    </div>
                    <h3 className="mb-2 text-lg font-bold">{topic.title}</h3>
                    <p className="text-sm leading-relaxed text-muted-foreground">
                      {topic.description}
                    </p>
                  </CardContent>
                </Card>
              </motion.div>
            )
          })}
        </div>
      </div>

      {/* Team */}
      <Card className="mb-8 overflow-hidden">
        <CardContent className="p-6 sm:p-8">
          <div className="flex items-start gap-4">
            <div className="flex h-12 w-12 shrink-0 items-center justify-center rounded-xl bg-cyan-100 dark:bg-cyan-950/40">
              <Heart className="h-6 w-6 text-cyan-600 dark:text-cyan-400" />
            </div>
            <div>
              <h2 className="mb-2 text-xl font-bold">हमारी टीम</h2>
              <p className="leading-relaxed text-muted-foreground">
                &quot;हिंदी के पंडित&quot; एक छोटी लेकिन समर्पित टीम है जिसमें अनुभवी
                लेखक, वित्तीय विशेषज्ञ, कृषि वैज्ञानिक और तकनीकी विश्लेषक शामिल हैं।
                हमारी टीम का प्रत्येक सदस्य अपने क्षेत्र में विशेषज्ञ है और हिंदी भाषा
                को समझने वाले पाठकों के लिए सामग्री लिखने में विशेष रुचि रखता है।
              </p>
              <p className="mt-3 leading-relaxed text-muted-foreground">
                हम सभी लेखों को गहन शोध और विशेषज्ञ समीक्षा के बाद ही प्रकाशित करते हैं,
                ताकि पाठकों को सबसे सटीक और विश्वसनीय जानकारी मिल सके।
              </p>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Stats */}
      <div className="mb-8">
        <h2 className="mb-6 text-center text-2xl font-bold">हमारी उपलब्धियाँ</h2>
        {statsLoading ? (
          <div className="grid gap-4 sm:grid-cols-4">
            {[1, 2, 3, 4].map((i) => (
              <Card key={i}>
                <CardContent className="flex flex-col items-center gap-2 p-6">
                  <Skeleton className="h-10 w-10 rounded-xl" />
                  <Skeleton className="h-8 w-16" />
                  <Skeleton className="h-4 w-12" />
                </CardContent>
              </Card>
            ))}
          </div>
        ) : (
          <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
            {statCards.map((stat) => {
              const Icon = stat.icon
              return (
                <motion.div
                  key={stat.label}
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ duration: 0.3 }}
                >
                  <Card className="text-center transition-shadow hover:shadow-md">
                    <CardContent className="flex flex-col items-center gap-2 p-6">
                      <div
                        className="flex h-12 w-12 items-center justify-center rounded-xl"
                        style={{ backgroundColor: `${stat.color}15` }}
                      >
                        <Icon className="h-6 w-6" style={{ color: stat.color }} />
                      </div>
                      <span className="text-2xl font-bold" style={{ color: stat.color }}>
                        {stat.value}
                      </span>
                      <span className="text-sm text-muted-foreground">{stat.label}</span>
                    </CardContent>
                  </Card>
                </motion.div>
              )
            })}
          </div>
        )}
      </div>

      {/* Contact CTA */}
      <Card className="overflow-hidden border-emerald-200 bg-gradient-to-br from-emerald-50 to-cyan-50 dark:border-emerald-800 dark:from-emerald-950/20 dark:to-cyan-950/20">
        <CardContent className="p-6 text-center sm:p-8">
          <Mail className="mx-auto mb-3 h-8 w-8 text-emerald-600 dark:text-emerald-400" />
          <h3 className="mb-2 text-xl font-bold">हमसे संपर्क करें</h3>
          <p className="mb-4 text-sm text-muted-foreground">
            कोई सुझाव या प्रश्न है? हमसे संपर्क करें, हम जल्द से जल्द जवाब देंगे।
          </p>
          <Button
            onClick={() => navigate('contact')}
            className="gap-2 bg-emerald-600 hover:bg-emerald-700"
          >
            <Mail className="h-4 w-4" />
            संपर्क करें
            <ArrowRight className="h-4 w-4" />
          </Button>
        </CardContent>
      </Card>
    </motion.div>
  )
}
