'use client'

import React from 'react'
import { motion } from 'framer-motion'
import { AlertTriangle } from 'lucide-react'
import { Card, CardContent } from '@/components/ui/card'
import { Separator } from '@/components/ui/separator'

export function DisclaimerPage() {
  return (
    <motion.div
      className="mx-auto max-w-4xl px-4 py-8 sm:px-6 lg:px-8"
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.5 }}
    >
      {/* Header */}
      <div className="mb-10 text-center">
        <div className="mx-auto mb-4 flex h-16 w-16 items-center justify-center rounded-2xl bg-gradient-to-br from-amber-500 to-orange-500 shadow-lg">
          <AlertTriangle className="h-8 w-8 text-white" />
        </div>
        <h1 className="mb-3 text-3xl font-bold tracking-tight sm:text-4xl">
          अस्वीकरण
        </h1>
        <p className="text-sm text-muted-foreground">
          अंतिम अपडेट: 1 जनवरी 2024
        </p>
      </div>

      <Card>
        <CardContent className="p-6 sm:p-8">
          <div className="prose prose-neutral dark:prose-invert max-w-none space-y-6">
            {/* General Disclaimer */}
            <section>
              <h2 className="text-xl font-bold">1. सामान्य अस्वीकरण</h2>
              <p className="leading-relaxed text-muted-foreground">
                &quot;हिंदी के पंडित&quot; वेबसाइट (hindikeyapandit.com) पर प्रकाशित सभी
                जानकारी केवल सामान्य सूचनात्मक उद्देश्यों के लिए है। हम पूरी तरह
                से प्रयास करते हैं कि जानकारी सटीक और अप-टू-डेट हो, लेकिन हम इसकी
                पूर्णता, सटीकता, विश्वसनीयता या उपलब्धता के लिए कोई वारंटी या
                गारंटी नहीं देते हैं।
              </p>
            </section>

            <Separator />

            {/* Financial Disclaimer */}
            <section>
              <h2 className="text-xl font-bold flex items-center gap-2">
                <AlertTriangle className="h-5 w-5 text-amber-500" />
                2. वित्तीय अस्वीकरण
              </h2>
              <div className="mt-3 rounded-xl border border-amber-200 bg-amber-50 p-4 dark:border-amber-800 dark:bg-amber-950/20">
                <p className="font-semibold text-amber-800 dark:text-amber-300">
                  ⚠️ यह बहुत महत्वपूर्ण है!
                </p>
              </div>
              <p className="mt-3 leading-relaxed text-muted-foreground">
                शेयर मार्केट, म्यूचुअल फंड, आईपीओ और अन्य निवेश से संबंधित सभी
                लेख और जानकारी केवल शैक्षिक और सूचनात्मक उद्देश्यों के लिए हैं। ये
                <strong> वित्तीय सलाह नहीं हैं</strong> और न ही इन्हें ऐसा ही माना जाना
                चाहिए।
              </p>
              <ul className="mt-3 list-disc space-y-2 pl-5 text-muted-foreground">
                <li>
                  निवेश हमेशा जोखिम के साथ आता है। आपका निवेश मूल्य में गिरावट आ
                  सकती है और आप अपना निवेशित धन पूरी तरह से खो सकते हैं।
                </li>
                <li>
                  पिछले प्रदर्शन भविष्य के परिणामों का संकेत नहीं है।
                </li>
                <li>
                  किसी भी निवेश निर्णय लेने से पहले एक योग्य और लाइसेंस प्राप्त
                  वित्तीय सलाहकार से परामर्श करें।
                </li>
                <li>
                  हम किसी भी स्टॉक, म्यूचुअल फंड या निवेश उत्पाद को खरीदने या बेचने
                  की सिफारिश नहीं करते हैं।
                </li>
              </ul>
            </section>

            <Separator />

            {/* Agriculture Disclaimer */}
            <section>
              <h2 className="text-xl font-bold">3. कृषि अस्वीकरण</h2>
              <p className="leading-relaxed text-muted-foreground">
                कृषि से संबंधित लेख और जानकारी सामान्य मार्गदर्शन के लिए हैं।
                कृषि प्रथाएं और परिणाम क्षेत्र, मौसम, मिट्टी के प्रकार और अन्य कारकों
                के अनुसार भिन्न हो सकते हैं। हम सलाह देते हैं:
              </p>
              <ul className="mt-3 list-disc space-y-2 pl-5 text-muted-foreground">
                <li>कृषि विशेषज्ञों और स्थानीय कृषि विभाग से परामर्श करें</li>
                <li>सरकारी योजनाओं के लिए आधिकारिक सूत्रों से सत्यापन करें</li>
                <li>बीज, उर्वरक और कीटनाशकों का उपयोग निर्माता के निर्देशों के अनुसार करें</li>
              </ul>
            </section>

            <Separator />

            {/* Technology Disclaimer */}
            <section>
              <h2 className="text-xl font-bold">4. तकनीकी अस्वीकरण</h2>
              <p className="leading-relaxed text-muted-foreground">
                टेक्नोलॉजी से संबंधित लेख, गैजेट रिव्यू और सॉफ्टवेयर टिप्स सामान्य
                जानकारी के लिए हैं। तकनीकी उत्पाद और सॉफ्टवेयर समय-समय पर अपडेट
                होते हैं, इसलिए जानकारी पुरानी हो सकती है। हम सलाह देते हैं:
              </p>
              <ul className="mt-3 list-disc space-y-2 pl-5 text-muted-foreground">
                <li>किसी भी सॉफ्टवेयर या ऐप को इंस्टॉल करने से पहले आधिकारिक स्रोत से सत्यापन करें</li>
                <li>साइबर सुरक्षा के लिए सर्वोत्तम प्रथाओं का पालन करें</li>
                <li>तकनीकी समस्याओं के लिए पेशेवर सहायता लें</li>
              </ul>
            </section>

            <Separator />

            {/* Third Party */}
            <section>
              <h2 className="text-xl font-bold">5. तृतीय-पक्ष सामग्री</h2>
              <p className="leading-relaxed text-muted-foreground">
                हमारी वेबसाइट में तृतीय-पक्ष उत्पादों, सेवाओं या वेबसाइटों के संदर्भ
                शामिल हो सकते हैं। ये संदर्भ अनुमोदन का संकेत नहीं हैं। हम तृतीय-पक्ष
                सामग्री की गुणवत्ता, सटीकता या विश्वसनीयता के लिए जिम्मेदार नहीं
                हैं।
              </p>
            </section>

            <Separator />

            {/* Accuracy */}
            <section>
              <h2 className="text-xl font-bold">6. सटीकता</h2>
              <p className="leading-relaxed text-muted-foreground">
                हम प्रकाशित सामग्री में त्रुटियों और चूक को ठीक करने का प्रयास करते
                हैं। हालांकि, हम सभी सामग्री की सटीकता की गारंटी नहीं दे सकते। यदि
                आपको कोई त्रुटि मिलती है, तो कृपया हमें सूचित करें ताकि हम उसे ठीक
                कर सकें।
              </p>
            </section>

            <Separator />

            {/* External Links */}
            <section>
              <h2 className="text-xl font-bold">7. बाहरी लिंक</h2>
              <p className="leading-relaxed text-muted-foreground">
                हमारी वेबसाइट में बाहरी वेबसाइटों के लिंक हो सकते हैं। बाहरी
                लिंक पर क्लिक करने से आप हमारी वेबसाइट छोड़ देते हैं। हम बाहरी
                वेबसाइटों की सामग्री, गोपनीयता नीतियों या अभ्यासों के लिए जिम्मेदार
                नहीं हैं।
              </p>
            </section>

            <Separator />

            {/* Limitation */}
            <section>
              <h2 className="text-xl font-bold">8. देयता की सीमा</h2>
              <p className="leading-relaxed text-muted-foreground">
                किसी भी परिस्थिति में &quot;हिंदी के पंडित&quot; इस वेबसाइट पर दी गई
                जानकारी के उपयोग से उत्पन्न किसी भी प्रत्यक्ष, अप्रत्यक्ष, आकस्मिक,
                विशेष या परिणामी क्षति के लिए जिम्मेदार नहीं होगा।
              </p>
            </section>

            <Separator />

            {/* Contact */}
            <section>
              <h2 className="text-xl font-bold">9. संपर्क</h2>
              <p className="leading-relaxed text-muted-foreground">
                इस अस्वीकरण से संबंधित किसी भी प्रश्न के लिए, कृपया हमसे संपर्क करें:
              </p>
              <p className="mt-2 leading-relaxed text-muted-foreground">
                <strong>ईमेल:</strong> info@hindikeyapandit.com
              </p>
            </section>
          </div>
        </CardContent>
      </Card>
    </motion.div>
  )
}
