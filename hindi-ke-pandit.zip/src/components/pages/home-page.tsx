'use client'

import React from 'react'
import { useQuery } from '@tanstack/react-query'
import { motion } from 'framer-motion'
import {
  BookOpen,
  TrendingUp,
  Wheat,
  Cpu,
  ArrowRight,
  Sparkles,
  Newspaper,
  ChevronRight,
} from 'lucide-react'
import { Button } from '@/components/ui/button'
import { Badge } from '@/components/ui/badge'
import { Skeleton } from '@/components/ui/skeleton'
import { useAppStore } from '@/store'
import { PostCard } from '@/components/shared/post-card'
import { StockTicker } from '@/components/shared/stock-ticker'
import { NewsletterSignup } from '@/components/shared/newsletter-signup'
import type { Post, Category } from '@/lib/types'

const categoryMeta: Record<string, { nameHindi: string; icon: React.ElementType; color: string; description: string }> = {
  'share-market': {
    nameHindi: 'शेयर मार्केट',
    icon: TrendingUp,
    color: '#16a34a',
    description: 'निवेश टिप्स, स्टॉक एनालिसिस, मार्केट अपडेट और वित्तीय सलाह',
  },
  krishi: {
    nameHindi: 'कृषि',
    icon: Wheat,
    color: '#ca8a04',
    description: 'आधुनिक खेती तकनीक, सरकारी योजनाएं, फसल गाइड और कृषि समाचार',
  },
  technology: {
    nameHindi: 'टेक्नोलॉजी',
    icon: Cpu,
    color: '#0891b2',
    description: 'AI, गैजेट रिव्यू, सॉफ्टवेयर टिप्स और तकनीकी अपडेट',
  },
}

const fadeUp = {
  initial: { opacity: 0, y: 20 },
  animate: { opacity: 1, y: 0 },
  transition: { duration: 0.5 },
}

function FeaturedPostsSkeleton() {
  return (
    <div className="grid gap-6 sm:grid-cols-2 lg:grid-cols-3">
      {[1, 2, 3].map((i) => (
        <div key={i} className="overflow-hidden rounded-xl border bg-card shadow-sm">
          <Skeleton className="aspect-video w-full" />
          <div className="space-y-3 p-4">
            <Skeleton className="h-4 w-24" />
            <Skeleton className="h-5 w-full" />
            <Skeleton className="h-5 w-3/4" />
            <Skeleton className="h-4 w-full" />
            <div className="flex gap-3">
              <Skeleton className="h-3 w-20" />
              <Skeleton className="h-3 w-16" />
              <Skeleton className="h-3 w-16" />
            </div>
          </div>
        </div>
      ))}
    </div>
  )
}

function LatestPostsSkeleton() {
  return (
    <div className="grid gap-6 sm:grid-cols-2 lg:grid-cols-3">
      {[1, 2, 3, 4, 5, 6].map((i) => (
        <div key={i} className="overflow-hidden rounded-xl border bg-card shadow-sm">
          <Skeleton className="aspect-video w-full" />
          <div className="space-y-3 p-4">
            <Skeleton className="h-4 w-24" />
            <Skeleton className="h-5 w-full" />
            <Skeleton className="h-4 w-full" />
            <div className="flex gap-3">
              <Skeleton className="h-3 w-20" />
              <Skeleton className="h-3 w-16" />
            </div>
          </div>
        </div>
      ))}
    </div>
  )
}

function CategoryCardsSkeleton() {
  return (
    <div className="grid gap-6 sm:grid-cols-3">
      {[1, 2, 3].map((i) => (
        <div key={i} className="rounded-xl border bg-card p-6 shadow-sm">
          <div className="flex items-center gap-4">
            <Skeleton className="h-12 w-12 rounded-xl" />
            <div className="space-y-2 flex-1">
              <Skeleton className="h-5 w-32" />
              <Skeleton className="h-4 w-48" />
            </div>
          </div>
          <div className="mt-4 space-y-2">
            <Skeleton className="h-4 w-full" />
            <Skeleton className="h-3 w-16" />
          </div>
        </div>
      ))}
    </div>
  )
}

export function HomePage() {
  const { navigate } = useAppStore()

  const {
    data: featuredData,
    isLoading: featuredLoading,
  } = useQuery<{ posts: Post[] }>({
    queryKey: ['featured-posts'],
    queryFn: () => fetch('/api/posts?featured=true&published=true&limit=3').then((r) => r.json()),
  })

  const {
    data: latestData,
    isLoading: latestLoading,
  } = useQuery<{ posts: Post[]; total: number }>({
    queryKey: ['latest-posts'],
    queryFn: () => fetch('/api/posts?published=true&limit=6').then((r) => r.json()),
  })

  const {
    data: categoriesData,
    isLoading: categoriesLoading,
  } = useQuery<{ categories: (Category & { _count: { posts: number } })[] }>({
    queryKey: ['categories'],
    queryFn: () => fetch('/api/categories').then((r) => r.json()),
  })

  const categoryMap = React.useMemo(() => {
    if (!categoriesData?.categories) return categoryMeta
    const map: Record<string, { nameHindi: string; icon: React.ElementType; color: string; description: string; count: number }> = {}
    for (const cat of categoriesData.categories) {
      const meta = categoryMeta[cat.slug]
      if (meta) {
        map[cat.slug] = { ...meta, count: cat._count?.posts || 0 }
      }
    }
    return map
  }, [categoriesData])

  return (
    <div>
      {/* Stock Ticker */}
      <StockTicker />

      {/* Hero Section */}
      <motion.section
        className="relative overflow-hidden border-b bg-gradient-to-br from-emerald-50 via-white to-cyan-50 dark:from-emerald-950/20 dark:via-background dark:to-cyan-950/20"
        {...fadeUp}
      >
        {/* Decorative elements */}
        <div className="absolute -right-16 -top-16 h-64 w-64 rounded-full bg-emerald-100/50 dark:bg-emerald-900/20 blur-3xl" />
        <div className="absolute -bottom-16 -left-16 h-64 w-64 rounded-full bg-cyan-100/50 dark:bg-cyan-900/20 blur-3xl" />

        <div className="relative mx-auto max-w-7xl px-4 py-16 sm:px-6 sm:py-24 lg:px-8">
          <div className="flex flex-col items-center gap-6 text-center">
            <div className="flex h-16 w-16 items-center justify-center rounded-2xl bg-primary shadow-lg">
              <BookOpen className="h-8 w-8 text-primary-foreground" />
            </div>
            <h1 className="max-w-3xl text-3xl font-bold tracking-tight sm:text-4xl lg:text-5xl">
              हिंदी के <span className="text-emerald-600 dark:text-emerald-400">पंडित</span>
            </h1>
            <p className="max-w-2xl text-base text-muted-foreground sm:text-lg">
              शेयर मार्केट, कृषि और टेक्नोलॉजी से जुड़ी नवीनतम जानकारी, विशेषज्ञ सलाह और
              सरल गाइड — सब कुछ हिंदी में।
            </p>
            <div className="flex flex-wrap items-center justify-center gap-3">
              <Button
                size="lg"
                onClick={() => navigate('category', { category: 'share-market' })}
                className="gap-2 bg-emerald-600 hover:bg-emerald-700"
              >
                <TrendingUp className="h-4 w-4" />
                शेयर मार्केट
              </Button>
              <Button
                size="lg"
                variant="outline"
                onClick={() => navigate('category', { category: 'krishi' })}
                className="gap-2 border-amber-300 text-amber-700 hover:bg-amber-50 dark:border-amber-700 dark:text-amber-400 dark:hover:bg-amber-950/30"
              >
                <Wheat className="h-4 w-4" />
                कृषि
              </Button>
              <Button
                size="lg"
                variant="outline"
                onClick={() => navigate('category', { category: 'technology' })}
                className="gap-2 border-cyan-300 text-cyan-700 hover:bg-cyan-50 dark:border-cyan-700 dark:text-cyan-400 dark:hover:bg-cyan-950/30"
              >
                <Cpu className="h-4 w-4" />
                टेक्नोलॉजी
              </Button>
            </div>
          </div>
        </div>
      </motion.section>

      {/* Featured Posts Section */}
      <motion.section
        className="mx-auto max-w-7xl px-4 py-12 sm:px-6 lg:px-8"
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5, delay: 0.1 }}
      >
        <div className="mb-8 flex items-center gap-3">
          <Sparkles className="h-6 w-6 text-amber-500" />
          <h2 className="text-2xl font-bold tracking-tight">विशेष लेख</h2>
          <div className="h-px flex-1 bg-border" />
        </div>

        {featuredLoading ? (
          <FeaturedPostsSkeleton />
        ) : featuredData?.posts && featuredData.posts.length > 0 ? (
          <div className="grid gap-6 sm:grid-cols-2 lg:grid-cols-3">
            {featuredData.posts.map((post) => (
              <PostCard key={post.id} post={post} />
            ))}
          </div>
        ) : (
          <div className="rounded-xl border border-dashed bg-muted/30 p-8 text-center">
            <Newspaper className="mx-auto mb-3 h-10 w-10 text-muted-foreground/50" />
            <p className="text-muted-foreground">अभी कोई विशेष लेख उपलब्ध नहीं है।</p>
          </div>
        )}
      </motion.section>

      {/* Latest Posts Section */}
      <motion.section
        className="mx-auto max-w-7xl px-4 py-12 sm:px-6 lg:px-8"
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5, delay: 0.2 }}
      >
        <div className="mb-8 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <Newspaper className="h-6 w-6 text-emerald-500" />
            <h2 className="text-2xl font-bold tracking-tight">नवीनतम लेख</h2>
            <div className="h-px flex-1 bg-border" />
          </div>
          {latestData?.total !== undefined && latestData.total > 6 && (
            <Button
              variant="ghost"
              onClick={() => navigate('category', { category: 'all' })}
              className="gap-1 text-sm text-muted-foreground"
            >
              सभी देखें <ArrowRight className="h-4 w-4" />
            </Button>
          )}
        </div>

        {latestLoading ? (
          <LatestPostsSkeleton />
        ) : latestData?.posts && latestData.posts.length > 0 ? (
          <div className="grid gap-6 sm:grid-cols-2 lg:grid-cols-3">
            {latestData.posts.map((post) => (
              <PostCard key={post.id} post={post} />
            ))}
          </div>
        ) : (
          <div className="rounded-xl border border-dashed bg-muted/30 p-8 text-center">
            <Newspaper className="mx-auto mb-3 h-10 w-10 text-muted-foreground/50" />
            <p className="text-muted-foreground">अभी कोई लेख प्रकाशित नहीं हुआ है।</p>
          </div>
        )}
      </motion.section>

      {/* Category Cards Section */}
      <motion.section
        className="mx-auto max-w-7xl px-4 py-12 sm:px-6 lg:px-8"
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5, delay: 0.3 }}
      >
        <div className="mb-8 flex items-center gap-3">
          <BookOpen className="h-6 w-6 text-cyan-500" />
          <h2 className="text-2xl font-bold tracking-tight">श्रेणियाँ</h2>
          <div className="h-px flex-1 bg-border" />
        </div>

        {categoriesLoading ? (
          <CategoryCardsSkeleton />
        ) : (
          <div className="grid gap-6 sm:grid-cols-3">
            {Object.entries(categoryMap).map(([slug, cat]) => {
              const Icon = cat.icon
              return (
                <motion.button
                  key={slug}
                  onClick={() => navigate('category', { category: slug })}
                  className="group relative overflow-hidden rounded-2xl border bg-card p-6 text-left shadow-sm transition-all duration-300 hover:-translate-y-1 hover:shadow-lg"
                  whileHover={{ scale: 1.02 }}
                  transition={{ duration: 0.2 }}
                >
                  {/* Colored accent line */}
                  <div
                    className="absolute left-0 top-0 h-full w-1.5 rounded-r-full"
                    style={{ backgroundColor: cat.color }}
                  />

                  <div className="flex items-start gap-4">
                    <div
                      className="flex h-14 w-14 shrink-0 items-center justify-center rounded-xl transition-transform duration-300 group-hover:scale-110"
                      style={{ backgroundColor: `${cat.color}15` }}
                    >
                      <Icon className="h-7 w-7" style={{ color: cat.color }} />
                    </div>
                    <div className="flex flex-1 flex-col gap-2">
                      <h3 className="text-lg font-bold">{cat.nameHindi}</h3>
                      <p className="text-sm leading-relaxed text-muted-foreground">
                        {cat.description}
                      </p>
                      <div className="flex items-center gap-2 pt-1">
                        <Badge
                          variant="secondary"
                          className="text-xs font-medium"
                          style={{
                            backgroundColor: `${cat.color}15`,
                            color: cat.color,
                          }}
                        >
                          {'count' in cat ? cat.count : 0} लेख
                        </Badge>
                        <ChevronRight className="h-4 w-4 text-muted-foreground transition-transform group-hover:translate-x-1" />
                      </div>
                    </div>
                  </div>
                </motion.button>
              )
            })}
          </div>
        )}
      </motion.section>

      {/* Newsletter Section */}
      <motion.section
        className="mx-auto max-w-7xl px-4 pb-12 sm:px-6 lg:px-8"
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5, delay: 0.4 }}
      >
        <NewsletterSignup />
      </motion.section>
    </div>
  )
}
