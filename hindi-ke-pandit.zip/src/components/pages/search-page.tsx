'use client'

import React from 'react'
import { useQuery } from '@tanstack/react-query'
import { motion } from 'framer-motion'
import {
  Search,
  ArrowLeft,
  FileQuestion,
  Newspaper,
} from 'lucide-react'
import { Button } from '@/components/ui/button'
import { Skeleton } from '@/components/ui/skeleton'
import { useAppStore } from '@/store'
import { PostCard } from '@/components/shared/post-card'
import type { Post } from '@/lib/types'

function SearchResultsSkeleton() {
  return (
    <div className="space-y-4">
      <Skeleton className="h-6 w-64" />
      <Skeleton className="h-4 w-96" />
      <div className="mt-6 grid gap-6 sm:grid-cols-2 lg:grid-cols-3">
        {[1, 2, 3, 4, 5, 6].map((i) => (
          <div key={i} className="overflow-hidden rounded-xl border bg-card shadow-sm">
            <Skeleton className="aspect-video w-full" />
            <div className="space-y-3 p-4">
              <Skeleton className="h-4 w-24" />
              <Skeleton className="h-5 w-full" />
              <Skeleton className="h-4 w-full" />
              <div className="flex gap-3">
                <Skeleton className="h-3 w-20" />
                <Skeleton className="h-3 w-16" />
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  )
}

export function SearchPage() {
  const { pageParams, navigate } = useAppStore()
  const query = pageParams.query || ''

  const {
    data,
    isLoading,
    isError,
  } = useQuery<{ posts: Post[] }>({
    queryKey: ['search', query],
    queryFn: () => fetch(`/api/search?q=${encodeURIComponent(query)}`).then((r) => r.json()),
    enabled: query.length > 0,
  })

  const posts = data?.posts || []
  const hasResults = posts.length > 0
  const isInitial = !query

  return (
    <motion.div
      className="mx-auto max-w-7xl px-4 py-8 sm:px-6 lg:px-8"
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.5 }}
    >
      {/* Back Button */}
      <Button
        variant="ghost"
        onClick={() => navigate('home')}
        className="mb-6 gap-2 text-muted-foreground hover:text-foreground"
      >
        <ArrowLeft className="h-4 w-4" />
        होम पेज पर जाएं
      </Button>

      {/* Search Header */}
      <div className="mb-8">
        <div className="flex items-center gap-3 mb-2">
          <Search className="h-7 w-7 text-emerald-600 dark:text-emerald-400" />
          <h1 className="text-2xl font-bold tracking-tight sm:text-3xl">खोज परिणाम</h1>
        </div>

        {isLoading ? (
          <SearchResultsSkeleton />
        ) : isError ? (
          <div className="mt-6 rounded-xl border border-dashed bg-muted/30 p-8 text-center">
            <FileQuestion className="mx-auto mb-3 h-10 w-10 text-muted-foreground/50" />
            <p className="text-muted-foreground">खोजने में त्रुटि हुई। कृपया पुनः प्रयास करें।</p>
          </div>
        ) : isInitial ? (
          <div className="mt-6 rounded-xl border border-dashed bg-muted/30 p-12 text-center">
            <Search className="mx-auto mb-3 h-12 w-12 text-muted-foreground/50" />
            <h3 className="mb-1 text-lg font-semibold">कुछ खोजें</h3>
            <p className="text-sm text-muted-foreground">
              शेयर मार्केट, कृषि, टेक्नोलॉजी या किसी भी विषय के बारे में खोजें।
            </p>
            <Button
              variant="outline"
              className="mt-4"
              onClick={() => navigate('home')}
            >
              होम पेज पर जाएं
            </Button>
          </div>
        ) : hasResults ? (
          <>
            <p className="text-base text-muted-foreground">
              <span className="font-semibold text-foreground">&quot;{query}&quot;</span> के लिए{' '}
              <span className="font-semibold text-foreground">{posts.length}</span> परिणाम मिले
            </p>
            <div className="mt-6 grid gap-6 sm:grid-cols-2 lg:grid-cols-3">
              {posts.map((post) => (
                <PostCard key={post.id} post={post} />
              ))}
            </div>
          </>
        ) : (
          <div className="mt-6">
            <p className="mb-4 text-base text-muted-foreground">
              <span className="font-semibold text-foreground">&quot;{query}&quot;</span> के लिए कोई परिणाम नहीं मिला
            </p>
            <div className="rounded-xl border border-dashed bg-muted/30 p-12 text-center">
              <Newspaper className="mx-auto mb-3 h-12 w-12 text-muted-foreground/50" />
              <h3 className="mb-1 text-lg font-semibold">कोई परिणाम नहीं मिला</h3>
              <p className="text-sm text-muted-foreground">
                कृपया अलग-अलग शब्दों का उपयोग करके पुनः खोजें।
              </p>
              <div className="mt-4 flex flex-wrap items-center justify-center gap-2">
                {['शेयर मार्केट', 'कृषि', 'टेक्नोलॉजी', 'निवेश', 'AI'].map((suggestion) => (
                  <Button
                    key={suggestion}
                    variant="outline"
                    size="sm"
                    onClick={() => navigate('search', { query: suggestion })}
                    className="text-sm"
                  >
                    {suggestion}
                  </Button>
                ))}
              </div>
            </div>
          </div>
        )}
      </div>
    </motion.div>
  )
}
