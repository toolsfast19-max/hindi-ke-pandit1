'use client'

import React, { useState } from 'react'
import { motion } from 'framer-motion'
import {
  Mail,
  Phone,
  MapPin,
  Send,
  Loader2,
  Facebook,
  Twitter,
  Instagram,
  Youtube,
  MessageCircle,
  Globe,
} from 'lucide-react'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Textarea } from '@/components/ui/textarea'
import { Card, CardContent } from '@/components/ui/card'
import { toast } from 'sonner'

export function ContactPage() {
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    subject: '',
    message: '',
  })
  const [loading, setLoading] = useState(false)

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    setFormData((prev) => ({ ...prev, [e.target.name]: e.target.value }))
  }

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    if (!formData.name || !formData.email || !formData.subject || !formData.message) return

    setLoading(true)
    try {
      const res = await fetch('/api/contact', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(formData),
      })
      if (res.ok) {
        toast.success('संदेश भेजा गया!', {
          description: 'हम जल्द से जल्द आपसे संपर्क करेंगे।',
        })
        setFormData({ name: '', email: '', subject: '', message: '' })
      } else {
        const data = await res.json()
        toast.error('त्रुटि', { description: data.error || 'कृपया पुनः प्रयास करें।' })
      }
    } catch {
      toast.error('त्रुटि', { description: 'नेटवर्क त्रुटि। कृपया बाद में पुनः प्रयास करें।' })
    } finally {
      setLoading(false)
    }
  }

  const contactInfo = [
    {
      icon: Mail,
      label: 'ईमेल',
      value: 'contact@hindikeyapandit.com',
      href: 'mailto:contact@hindikeyapandit.com',
      color: '#16a34a',
    },
    {
      icon: Phone,
      label: 'फ़ोन',
      value: '+91 98765 43210',
      href: 'tel:+919876543210',
      color: '#0891b2',
    },
    {
      icon: MapPin,
      label: 'पता',
      value: 'नई दिल्ली, भारत',
      href: '#',
      color: '#ca8a04',
    },
  ]

  const socialLinks = [
    { icon: Facebook, label: 'Facebook', color: '#1877F2' },
    { icon: Twitter, label: 'Twitter', color: '#1DA1F2' },
    { icon: Instagram, label: 'Instagram', color: '#E4405F' },
    { icon: Youtube, label: 'YouTube', color: '#FF0000' },
  ]

  return (
    <motion.div
      className="mx-auto max-w-6xl px-4 py-8 sm:px-6 lg:px-8"
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.5 }}
    >
      {/* Header */}
      <div className="mb-10 text-center">
        <div className="mx-auto mb-4 flex h-16 w-16 items-center justify-center rounded-2xl bg-gradient-to-br from-emerald-500 to-cyan-500 shadow-lg">
          <MessageCircle className="h-8 w-8 text-white" />
        </div>
        <h1 className="mb-3 text-3xl font-bold tracking-tight sm:text-4xl">
          संपर्क करें
        </h1>
        <p className="mx-auto max-w-2xl text-base text-muted-foreground sm:text-lg">
          कोई सुझाव, प्रश्न या विचार है? हमसे संपर्क करें, हम आपके संदेश का इंतज़ार कर रहे हैं।
        </p>
      </div>

      <div className="grid gap-8 lg:grid-cols-5">
        {/* Contact Form */}
        <div className="lg:col-span-3">
          <Card>
            <CardContent className="p-6 sm:p-8">
              <h2 className="mb-6 text-xl font-bold flex items-center gap-2">
                <Send className="h-5 w-5 text-emerald-600 dark:text-emerald-400" />
                संदेश भेजें
              </h2>
              <form onSubmit={handleSubmit} className="space-y-5">
                <div className="grid gap-5 sm:grid-cols-2">
                  <div className="space-y-2">
                    <label className="text-sm font-medium">
                      आपका नाम <span className="text-red-500">*</span>
                    </label>
                    <Input
                      name="name"
                      placeholder="अपना पूरा नाम दर्ज करें"
                      value={formData.name}
                      onChange={handleChange}
                      required
                    />
                  </div>
                  <div className="space-y-2">
                    <label className="text-sm font-medium">
                      ईमेल <span className="text-red-500">*</span>
                    </label>
                    <Input
                      name="email"
                      type="email"
                      placeholder="आपका ईमेल दर्ज करें"
                      value={formData.email}
                      onChange={handleChange}
                      required
                    />
                  </div>
                </div>
                <div className="space-y-2">
                  <label className="text-sm font-medium">
                    विषय <span className="text-red-500">*</span>
                  </label>
                  <Input
                    name="subject"
                    placeholder="संदेश का विषय"
                    value={formData.subject}
                    onChange={handleChange}
                    required
                  />
                </div>
                <div className="space-y-2">
                  <label className="text-sm font-medium">
                    संदेश <span className="text-red-500">*</span>
                  </label>
                  <Textarea
                    name="message"
                    placeholder="अपना संदेश यहाँ लिखें..."
                    rows={6}
                    value={formData.message}
                    onChange={handleChange}
                    required
                  />
                </div>
                <Button
                  type="submit"
                  disabled={loading || !formData.name || !formData.email || !formData.subject || !formData.message}
                  className="w-full gap-2 bg-emerald-600 hover:bg-emerald-700 sm:w-auto"
                >
                  {loading ? (
                    <>
                      <Loader2 className="h-4 w-4 animate-spin" />
                      भेज रहे हैं...
                    </>
                  ) : (
                    <>
                      <Send className="h-4 w-4" />
                      संदेश भेजें
                    </>
                  )}
                </Button>
              </form>
            </CardContent>
          </Card>
        </div>

        {/* Contact Info Sidebar */}
        <div className="space-y-6 lg:col-span-2">
          {/* Contact Cards */}
          <div className="space-y-4">
            {contactInfo.map((info) => {
              const Icon = info.icon
              return (
                <Card key={info.label} className="transition-shadow hover:shadow-md">
                  <CardContent className="flex items-center gap-4 p-4">
                    <div
                      className="flex h-10 w-10 shrink-0 items-center justify-center rounded-xl"
                      style={{ backgroundColor: `${info.color}15` }}
                    >
                      <Icon className="h-5 w-5" style={{ color: info.color }} />
                    </div>
                    <div className="min-w-0">
                      <p className="text-xs font-medium text-muted-foreground">{info.label}</p>
                      <a
                        href={info.href}
                        className="text-sm font-medium hover:underline truncate block"
                      >
                        {info.value}
                      </a>
                    </div>
                  </CardContent>
                </Card>
              )
            })}
          </div>

          {/* Social Links */}
          <Card>
            <CardContent className="p-4">
              <h3 className="mb-3 text-sm font-semibold flex items-center gap-2">
                <Globe className="h-4 w-4 text-muted-foreground" />
                सोशल मीडिया
              </h3>
              <div className="grid grid-cols-4 gap-2">
                {socialLinks.map((social) => {
                  const Icon = social.icon
                  return (
                    <button
                      key={social.label}
                      className="flex h-10 w-full items-center justify-center rounded-lg border transition-colors hover:bg-muted"
                      title={social.label}
                    >
                      <Icon className="h-5 w-5" style={{ color: social.color }} />
                    </button>
                  )
                })}
              </div>
            </CardContent>
          </Card>

          {/* Map Placeholder */}
          <Card className="overflow-hidden">
            <div className="relative aspect-[4/3] w-full bg-muted">
              <div className="absolute inset-0 flex flex-col items-center justify-center gap-2 text-muted-foreground">
                <MapPin className="h-10 w-10" />
                <span className="text-sm font-medium">नई दिल्ली, भारत</span>
                <span className="text-xs">मैप लोड हो रहा है...</span>
              </div>
            </div>
          </Card>
        </div>
      </div>
    </motion.div>
  )
}
