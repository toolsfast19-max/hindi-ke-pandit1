'use client'

import React from 'react'
import { motion } from 'framer-motion'
import { FileText } from 'lucide-react'
import { Card, CardContent } from '@/components/ui/card'
import { Separator } from '@/components/ui/separator'

export function TermsPage() {
  return (
    <motion.div
      className="mx-auto max-w-4xl px-4 py-8 sm:px-6 lg:px-8"
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.5 }}
    >
      {/* Header */}
      <div className="mb-10 text-center">
        <div className="mx-auto mb-4 flex h-16 w-16 items-center justify-center rounded-2xl bg-gradient-to-br from-emerald-500 to-cyan-500 shadow-lg">
          <FileText className="h-8 w-8 text-white" />
        </div>
        <h1 className="mb-3 text-3xl font-bold tracking-tight sm:text-4xl">
          नियम और शर्तें
        </h1>
        <p className="text-sm text-muted-foreground">
          अंतिम अपडेट: 1 जनवरी 2024
        </p>
      </div>

      <Card>
        <CardContent className="p-6 sm:p-8">
          <div className="prose prose-neutral dark:prose-invert max-w-none space-y-6">
            {/* Acceptance */}
            <section>
              <h2 className="text-xl font-bold">1. स्वीकृति</h2>
              <p className="leading-relaxed text-muted-foreground">
                &quot;हिंदी के पंडित&quot; वेबसाइट (hindikeyapandit.com) का उपयोग करके, आप इन
                नियमों और शर्तों से सहमत होते हैं। यदि आप इन शर्तों से सहमत नहीं
                हैं, तो कृपया वेबसाइट का उपयोग करना बंद करें। हम इन शर्तों को किसी भी
                समय बदल सकते हैं, और आपका निरंतर उपयोग परिवर्तित शर्तों से आपकी
                सहमति का संकेत होगा।
              </p>
            </section>

            <Separator />

            {/* Use of Website */}
            <section>
              <h2 className="text-xl font-bold">2. वेबसाइट का उपयोग</h2>
              <p className="leading-relaxed text-muted-foreground">
                आप सहमत हैं कि आप वेबसाइट का उपयोग केवल कानूनी उद्देश्यों के लिए
                करेंगे। आप वेबसाइट का उपयोग ऐसे तरीके से नहीं करेंगे जो:
              </p>
              <ul className="mt-3 list-disc space-y-2 pl-5 text-muted-foreground">
                <li>किसी भी लागू कानून का उल्लंघन करे</li>
                <li>दूसरों के अधिकारों का हनन करे</li>
                <li>वेबसाइट की सुरक्षा या कार्यक्षमता को नुकसान पहुंचाए</li>
                <li>वायरस, मैलवेयर या हानिकारक कोड फैलाए</li>
                <li>स्पैम, फ़िशिंग या धोखाधड़ी की गतिविधियां करे</li>
                <li>वेबसाइट की सामग्री को अधिकृत के बिना कॉपी या पुनर्प्रकाशित करे</li>
              </ul>
            </section>

            <Separator />

            {/* Intellectual Property */}
            <section>
              <h2 className="text-xl font-bold">3. बौद्धिक संपदा</h2>
              <p className="leading-relaxed text-muted-foreground">
                वेबसाइट पर प्रकाशित सभी सामग्री — जिसमें लेख, चित्र, ग्राफ़िक्स, लोगो,
                आइकन, वीडियो और सॉफ्टवेयर शामिल हैं — &quot;हिंदी के पंडित&quot; की संपदा
                हैं और कॉपीराइट, ट्रेडमार्क और अन्य बौद्धिक संपदा कानूनों के अधीन
                संरक्षित हैं।
              </p>
              <p className="mt-3 leading-relaxed text-muted-foreground">
                आप वेबसाइट की सामग्री को व्यक्तिगत, गैर-व्यावसायिक उपयोग के लिए पढ़
                सकते हैं। सामग्री की किसी भी प्रकार की पुनर्प्रकाशन, वितरण या व्युत्पन्न
                निर्माण हमारी पूर्व लिखित सहमति के बिना निषिद्ध है।
              </p>
            </section>

            <Separator />

            {/* User Content */}
            <section>
              <h2 className="text-xl font-bold">4. उपयोगकर्ता सामग्री</h2>
              <p className="leading-relaxed text-muted-foreground">
                जब आप हमारी वेबसाइट पर टिप्पणी या अन्य सामग्री पोस्ट करते हैं, तो
                आप हमें ऐसी सामग्री को उपयोग, प्रदर्शित और वितरित करने के लिए एक
                गैर-एक्सक्लूसिव, रॉयल्टी-मुक्त लाइसेंस प्रदान करते हैं।
              </p>
              <p className="mt-3 leading-relaxed text-muted-foreground">
                आप सहमत हैं कि आप पोस्ट की गई सामग्री:
              </p>
              <ul className="mt-3 list-disc space-y-2 pl-5 text-muted-foreground">
                <li>सच्ची और सटीक होगी</li>
                <li>किसी भी तीसरे पक्ष के अधिकारों का उल्लंघन नहीं करेगी</li>
                <li>अश्लील, आपत्तिजनक, या हानिकारक नहीं होगी</li>
                <li>स्पैम या विज्ञापन नहीं होगी</li>
              </ul>
            </section>

            <Separator />

            {/* Disclaimer */}
            <section>
              <h2 className="text-xl font-bold">5. अस्वीकरण</h2>
              <p className="leading-relaxed text-muted-foreground">
                वेबसाइट पर दी गई जानकारी &quot;जैसी है&quot; और &quot;जैसी उपलब्ध है&quot; के
                आधार पर प्रदान की जाती है। हम सभी जानकारी की सटीकता, पूर्णता और
                विश्वसनीयता के लिए प्रयास करते हैं, लेकिन कोई भी वारंटी नहीं देते।
              </p>
              <p className="mt-3 leading-relaxed text-muted-foreground">
                <strong>विशेष रूप से:</strong> शेयर मार्केट और निवेश से संबंधित लेख केवल
                सूचनात्मक उद्देश्यों के लिए हैं और वित्तीय सलाह नहीं हैं। किसी भी
                निवेश निर्णय लेने से पहले एक योग्य वित्तीय सलाहकार से परामर्श करें।
              </p>
            </section>

            <Separator />

            {/* Limitation of Liability */}
            <section>
              <h2 className="text-xl font-bold">6. देयता की सीमा</h2>
              <p className="leading-relaxed text-muted-foreground">
                &quot;हिंदी के पंडित&quot;, इसके निदेशक, कर्मचारी, भागीदार और एजेंट किसी भी
                प्रत्यक्ष, अप्रत्यक्ष, आकस्मिक, विशेष, परिणामी या दंडात्मक क्षति के लिए
                जिम्मेदार नहीं होंगे जो वेबसाइट के उपयोग या उपयोग करने में असमर्थता
                से उत्पन्न होती है।
              </p>
            </section>

            <Separator />

            {/* External Links */}
            <section>
              <h2 className="text-xl font-bold">7. बाहरी लिंक</h2>
              <p className="leading-relaxed text-muted-foreground">
                हमारी वेबसाइट बाहरी वेबसाइटों के लिंक शामिल कर सकती है। ये लिंक
                केवल सुविधा के लिए हैं और अनुमोदन का संकेत नहीं हैं। हम बाहरी
                वेबसाइटों की सामग्री, गोपनीयता नीतियों या प्रथाओं के लिए जिम्मेदार
                नहीं हैं।
              </p>
            </section>

            <Separator />

            {/* Termination */}
            <section>
              <h2 className="text-xl font-bold">8. समापन</h2>
              <p className="leading-relaxed text-muted-foreground">
                हम अपने विवेक से किसी भी समय, किसी भी कारण से, बिना किसी सूचना के
                आपकी वेबसाइट तक पहुंच समाप्त कर सकते हैं। समापन के बाद भी, इन
                शर्तों के कुछ प्रावधान प्रभावी रहेंगे।
              </p>
            </section>

            <Separator />

            {/* Governing Law */}
            <section>
              <h2 className="text-xl font-bold">9. शासी कानून</h2>
              <p className="leading-relaxed text-muted-foreground">
                ये नियम और शर्तें भारतीय कानूनों के अधीन होंगी और उनके अनुसार
                व्याख्या की जाएंगी। किसी भी विवाद का समाधान नई दिल्ली, भारत के
                अधिकार क्षेत्र की अदालतों में किया जाएगा।
              </p>
            </section>

            <Separator />

            {/* Contact */}
            <section>
              <h2 className="text-xl font-bold">10. संपर्क</h2>
              <p className="leading-relaxed text-muted-foreground">
                इन नियमों और शर्तों के बारे में किसी भी प्रश्न के लिए, कृपया हमसे
                संपर्क करें:
              </p>
              <p className="mt-2 leading-relaxed text-muted-foreground">
                <strong>ईमेल:</strong> legal@hindikeyapandit.com
              </p>
            </section>
          </div>
        </CardContent>
      </Card>
    </motion.div>
  )
}
