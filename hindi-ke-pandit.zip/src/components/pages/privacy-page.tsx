'use client'

import React from 'react'
import { motion } from 'framer-motion'
import { Shield } from 'lucide-react'
import { Card, CardContent } from '@/components/ui/card'
import { Separator } from '@/components/ui/separator'

export function PrivacyPage() {
  return (
    <motion.div
      className="mx-auto max-w-4xl px-4 py-8 sm:px-6 lg:px-8"
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.5 }}
    >
      {/* Header */}
      <div className="mb-10 text-center">
        <div className="mx-auto mb-4 flex h-16 w-16 items-center justify-center rounded-2xl bg-gradient-to-br from-emerald-500 to-cyan-500 shadow-lg">
          <Shield className="h-8 w-8 text-white" />
        </div>
        <h1 className="mb-3 text-3xl font-bold tracking-tight sm:text-4xl">
          गोपनीयता नीति
        </h1>
        <p className="text-sm text-muted-foreground">
          अंतिम अपडेट: 1 जनवरी 2024
        </p>
      </div>

      <Card>
        <CardContent className="p-6 sm:p-8">
          <div className="prose prose-neutral dark:prose-invert max-w-none space-y-6">
            {/* Intro */}
            <section>
              <h2 className="text-xl font-bold">1. परिचय</h2>
              <p className="leading-relaxed text-muted-foreground">
                &quot;हिंदी के पंडित&quot; (&quot;हम&quot;, &quot;हमारा&quot;, &quot;वेबसाइट&quot;) अपने उपयोगकर्ताओं
                की गोपनीयता का सम्मान करता है। यह गोपनीयता नीति बताती है कि हम आपकी
                जानकारी कैसे एकत्र, उपयोग, संग्रहीत और सुरक्षित करते हैं जब आप हमारी
                वेबसाइट hindikeyapandit.com का उपयोग करते हैं।
              </p>
            </section>

            <Separator />

            {/* Information We Collect */}
            <section>
              <h2 className="text-xl font-bold">2. हम कौन सी जानकारी एकत्र करते हैं</h2>
              <p className="leading-relaxed text-muted-foreground">हम निम्नलिखित प्रकार की जानकारी एकत्र कर सकते हैं:</p>
              <ul className="mt-3 list-disc space-y-2 pl-5 text-muted-foreground">
                <li>
                  <strong>व्यक्तिगत जानकारी:</strong> जब आप हमसे संपर्क करते हैं, टिप्पणी
                  देते हैं, या न्यूज़लेटर सब्सक्राइब करते हैं, तो हम आपका नाम, ईमेल पता
                  और अन्य संपर्क विवरण एकत्र करते हैं।
                </li>
                <li>
                  <strong>उपयोग डेटा:</strong> हम स्वचालित रूप से आपके ब्राउज़र प्रकार,
                  ऑपरेटिंग सिस्टम, आईपी पता, एक्सेस समय और पेज व्यूज जैसी जानकारी
                  एकत्र करते हैं।
                </li>
                <li>
                  <strong>कुकीज़:</strong> हम कुकीज़ और समान तकनीकों का उपयोग करके आपके
                  अनुभव को बेहतर बनाते हैं और वेबसाइट उपयोग को ट्रैक करते हैं।
                </li>
              </ul>
            </section>

            <Separator />

            {/* How We Use */}
            <section>
              <h2 className="text-xl font-bold">3. हम आपकी जानकारी का उपयोग कैसे करते हैं</h2>
              <p className="leading-relaxed text-muted-foreground">हम एकत्रित जानकारी का उपयोग निम्नलिखित उद्देश्यों के लिए करते हैं:</p>
              <ul className="mt-3 list-disc space-y-2 pl-5 text-muted-foreground">
                <li>वेबसाइट की सेवाएं प्रदान करने और बनाए रखने के लिए</li>
                <li>न्यूज़लेटर और अपडेट भेजने के लिए (आपकी सहमति से)</li>
                <li>आपके प्रश्नों और संदेशों का जवाब देने के लिए</li>
                <li>वेबसाइट के प्रदर्शन और उपयोगकर्ता अनुभव को बेहतर बनाने के लिए</li>
                <li>विश्लेषणात्मक उद्देश्यों के लिए (एनोनिमाइज़्ड डेटा)</li>
                <li>कानूनी आवश्यकताओं को पूरा करने के लिए</li>
              </ul>
            </section>

            <Separator />

            {/* Data Sharing */}
            <section>
              <h2 className="text-xl font-bold">4. डेटा साझाकरण</h2>
              <p className="leading-relaxed text-muted-foreground">
                हम आपकी व्यक्तिगत जानकारी तीसरे पक्षों को नहीं बेचते, किराये पर नहीं
                देते या साझा नहीं करते, सिवाय:
              </p>
              <ul className="mt-3 list-disc space-y-2 pl-5 text-muted-foreground">
                <li>आपकी स्पष्ट सहमति से</li>
                <li>कानूनी आवश्यकताओं या सरकारी अनुरोधों के अनुसार</li>
                <li>हमारी सेवाओं को प्रदान करने वाले विश्वसनीय तीसरे पक्ष सेवा प्रदाताओं को (जैसे होस्टिंग, ईमेल सेवाएं)</li>
                <li>वेबसाइट की सुरक्षा और अखंडता बनाए रखने के लिए</li>
              </ul>
            </section>

            <Separator />

            {/* Data Security */}
            <section>
              <h2 className="text-xl font-bold">5. डेटा सुरक्षा</h2>
              <p className="leading-relaxed text-muted-foreground">
                हम आपकी व्यक्तिगत जानकारी की सुरक्षा के लिए उचित तकनीकी और
                संगठनात्मक उपाय लेते हैं। इसमें SSL एन्क्रिप्शन, सुरक्षित सर्वर,
                एक्सेस नियंत्रण और नियमित सुरक्षा ऑडिट शामिल हैं। हालांकि, कोई भी
                इंटरनेट-आधारित संचरण 100% सुरक्षित नहीं है, और हम पूर्ण सुरक्षा की
                गारंटी नहीं दे सकते।
              </p>
            </section>

            <Separator />

            {/* Cookies */}
            <section>
              <h2 className="text-xl font-bold">6. कुकीज़ नीति</h2>
              <p className="leading-relaxed text-muted-foreground">
                हमारी वेबसाइट कुकीज़ का उपयोग करती है। कुकीज़ छोटी टेक्स्ट फ़ाइलें हैं
                जो आपके ब्राउज़र में संग्रहीत होती हैं। आप अपने ब्राउज़र सेटिंग्स में
                कुकीज़ को अक्षम कर सकते हैं, लेकिन इससे वेबसाइट की कुछ सुविधाएं
                काम नहीं कर सकतीं।
              </p>
              <ul className="mt-3 list-disc space-y-2 pl-5 text-muted-foreground">
                <li>
                  <strong>आवश्यक कुकीज़:</strong> वेबसाइट की बुनियादी कार्यक्षमता के लिए आवश्यक
                </li>
                <li>
                  <strong>विश्लेषणात्मक कुकीज़:</strong> हमें यह समझने में मदद करती हैं कि
                  आप हमारी वेबसाइट का उपयोग कैसे करते हैं
                </li>
                <li>
                  <strong>प्राथमिकता कुकीज़:</strong> आपकी पसंद याद रखती हैं
                </li>
              </ul>
            </section>

            <Separator />

            {/* Third Party Links */}
            <section>
              <h2 className="text-xl font-bold">7. तृतीय-पक्ष लिंक</h2>
              <p className="leading-relaxed text-muted-foreground">
                हमारी वेबसाइट में तृतीय-पक्ष वेबसाइटों के लिंक हो सकते हैं। हम इन
                वेबसाइटों की सामग्री या गोपनीयता प्रथाओं के लिए जिम्मेदार नहीं हैं।
                हम आपको सलाह देते हैं कि किसी भी तृतीय-पक्ष वेबसाइट की गोपनीयता
                नीति पढ़ें।
              </p>
            </section>

            <Separator />

            {/* Children Privacy */}
            <section>
              <h2 className="text-xl font-bold">8. बच्चों की गोपनीयता</h2>
              <p className="leading-relaxed text-muted-foreground">
                हमारी सेवाएं 13 वर्ष से कम उम्र के बच्चों के लिए अभिप्रेत नहीं हैं। हम
                जानबूझकर 13 वर्ष से कम उम्र के बच्चों से व्यक्तिगत जानकारी एकत्र नहीं
                करते हैं। यदि आपको पता चले कि कोई बच्चा हमें व्यक्तिगत जानकारी
                प्रदान कर रहा है, तो कृपया हमसे संपर्क करें।
              </p>
            </section>

            <Separator />

            {/* User Rights */}
            <section>
              <h2 className="text-xl font-bold">9. आपके अधिकार</h2>
              <p className="leading-relaxed text-muted-foreground">आपके पास निम्नलिखित अधिकार हैं:</p>
              <ul className="mt-3 list-disc space-y-2 pl-5 text-muted-foreground">
                <li>अपनी व्यक्तिगत जानकारी तक पहुंचने का अधिकार</li>
                <li>अपनी जानकारी को सुधारने या अपडेट करने का अधिकार</li>
                <li>अपनी जानकारी को हटाने का अधिकार</li>
                <li>डेटा प्रोसेसिंग से आपत्ति करने का अधिकार</li>
                <li>डेटा पोर्टेबिलिटी का अधिकार</li>
              </ul>
              <p className="mt-3 leading-relaxed text-muted-foreground">
                इन अधिकारों का उपयोग करने के लिए कृपया हमसे संपर्क करें।
              </p>
            </section>

            <Separator />

            {/* Changes */}
            <section>
              <h2 className="text-xl font-bold">10. नीति में परिवर्तन</h2>
              <p className="leading-relaxed text-muted-foreground">
                हम इस गोपनीयता नीति को समय-समय पर अपडेट कर सकते हैं। कोई भी
                महत्वपूर्ण परिवर्तन इस पृष्ठ पर प्रकाशित किए जाएंगे। हम आपको सलाह
                देते हैं कि इस पृष्ठ को समय-समय पर देखें।
              </p>
            </section>

            <Separator />

            {/* Contact */}
            <section>
              <h2 className="text-xl font-bold">11. संपर्क</h2>
              <p className="leading-relaxed text-muted-foreground">
                यदि आपके कोई प्रश्न हैं इस गोपनीयता नीति के बारे में, तो कृपया
                हमसे संपर्क करें:
              </p>
              <p className="mt-2 leading-relaxed text-muted-foreground">
                <strong>ईमेल:</strong> privacy@hindikeyapandit.com
              </p>
            </section>
          </div>
        </CardContent>
      </Card>
    </motion.div>
  )
}
