'use client'

import React from 'react'
import { motion } from 'framer-motion'
import { Home, Search, ArrowRight } from 'lucide-react'
import { Button } from '@/components/ui/button'
import { useAppStore } from '@/store'

export function NotFoundPage() {
  const { navigate } = useAppStore()

  return (
    <motion.div
      className="flex min-h-[60vh] flex-col items-center justify-center px-4 py-16 text-center"
      initial={{ opacity: 0, y: 30 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.6 }}
    >
      {/* Fun Emoji Illustration */}
      <motion.div
        className="mb-6 text-8xl"
        initial={{ scale: 0, rotate: -10 }}
        animate={{ scale: 1, rotate: 0 }}
        transition={{ duration: 0.5, delay: 0.2, type: 'spring' }}
      >
        🔍
      </motion.div>

      {/* 404 Number */}
      <motion.div
        className="mb-4 text-7xl font-black tracking-tighter text-muted-foreground/20 sm:text-9xl"
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ duration: 0.5, delay: 0.3 }}
      >
        404
      </motion.div>

      {/* Heading */}
      <motion.h1
        className="mb-3 text-2xl font-bold tracking-tight sm:text-3xl"
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ duration: 0.5, delay: 0.4 }}
      >
        पेज नहीं मिला
      </motion.h1>

      {/* Description */}
      <motion.p
        className="mb-8 max-w-md text-base text-muted-foreground"
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ duration: 0.5, delay: 0.5 }}
      >
        ऐसा लगता है कि आप जिस पेज को खोज रहे हैं वह मौजूद नहीं है या
        हटा दिया गया है। कृपया होम पेज पर जाएं या खोजें।
      </motion.p>

      {/* Actions */}
      <motion.div
        className="flex flex-wrap items-center justify-center gap-3"
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ duration: 0.5, delay: 0.6 }}
      >
        <Button
          onClick={() => navigate('home')}
          className="gap-2 bg-emerald-600 hover:bg-emerald-700"
        >
          <Home className="h-4 w-4" />
          होम पेज पर जाएं
        </Button>
        <Button
          variant="outline"
          onClick={() => navigate('search', { query: '' })}
          className="gap-2"
        >
          <Search className="h-4 w-4" />
          खोजें
        </Button>
      </motion.div>

      {/* Decorative dots */}
      <div className="mt-12 flex items-center gap-2">
        <div className="h-2 w-2 rounded-full bg-emerald-400" />
        <div className="h-2 w-2 rounded-full bg-amber-400" />
        <div className="h-2 w-2 rounded-full bg-cyan-400" />
      </div>
    </motion.div>
  )
}
