export interface Category {
  id: string;
  name: string;
  nameHindi: string;
  slug: string;
  description: string;
  icon: string;
  color: string;
  _count?: { posts: number };
}

export interface Post {
  id: string;
  title: string;
  slug: string;
  excerpt: string;
  content: string;
  coverImage: string;
  published: boolean;
  featured: boolean;
  viewCount: number;
  categoryId: string;
  category?: Category;
  createdAt: string;
  updatedAt: string;
  comments?: Comment[];
}

export interface Comment {
  id: string;
  name: string;
  email: string;
  content: string;
  postId: string;
  approved: boolean;
  createdAt: string;
}

export interface Newsletter {
  id: string;
  email: string;
  active: boolean;
  createdAt: string;
}

export interface ContactMessage {
  id: string;
  name: string;
  email: string;
  subject: string;
  message: string;
  read: boolean;
  createdAt: string;
}

export type RouteParams = {
  page: string;
  slug?: string;
  category?: string;
  query?: string;
};

export const CATEGORIES = {
  'share-market': { name: 'Share Market', nameHindi: 'शेयर मार्केट', slug: 'share-market', icon: 'TrendingUp', color: '#16a34a' },
  'krishi': { name: 'Agriculture', nameHindi: 'कृषि', slug: 'krishi', icon: 'Wheat', color: '#ca8a04' },
  'technology': { name: 'Technology', nameHindi: 'टेक्नोलॉजी', slug: 'technology', icon: 'Cpu', color: '#0891b2' },
} as const;

export type CategorySlug = keyof typeof CATEGORIES;
