import { create } from 'zustand'

export type PageType = 
  | 'home' 
  | 'category' 
  | 'post' 
  | 'about' 
  | 'contact' 
  | 'privacy' 
  | 'terms' 
  | 'disclaimer' 
  | 'search' 
  | 'admin'
  | '404'

interface AppState {
  // Navigation
  currentPage: PageType
  pageParams: Record<string, string>
  previousPage: PageType | null
  navigate: (page: PageType, params?: Record<string, string>) => void
  goBack: () => void

  // Search
  searchQuery: string
  searchOpen: boolean
  setSearchQuery: (query: string) => void
  setSearchOpen: (open: boolean) => void

  // Admin
  isAdminOpen: boolean
  setAdminOpen: (open: boolean) => void

  // Mobile Menu
  mobileMenuOpen: boolean
  setMobileMenuOpen: (open: boolean) => void
}

export const useAppStore = create<AppState>((set, get) => ({
  currentPage: 'home',
  pageParams: {},
  previousPage: null,
  navigate: (page, params = {}) => {
    const { currentPage } = get()
    window.scrollTo({ top: 0, behavior: 'smooth' })
    set({ 
      currentPage: page, 
      pageParams: params, 
      previousPage: currentPage,
      mobileMenuOpen: false 
    })
  },
  goBack: () => {
    const { previousPage } = get()
    if (previousPage) {
      set({ currentPage: previousPage, previousPage: null })
    } else {
      set({ currentPage: 'home' })
    }
  },

  searchQuery: '',
  searchOpen: false,
  setSearchQuery: (query) => set({ searchQuery: query }),
  setSearchOpen: (open) => set({ searchOpen: open }),

  isAdminOpen: false,
  setAdminOpen: (open) => set({ isAdminOpen: open }),

  mobileMenuOpen: false,
  setMobileMenuOpen: (open) => set({ mobileMenuOpen: open }),
}))
