import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'

export async function GET(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url)
    const query = searchParams.get('q')
    
    if (!query || query.length < 2) {
      return NextResponse.json({ posts: [] })
    }

    const posts = await db.post.findMany({
      where: {
        published: true,
        OR: [
          { title: { contains: query } },
          { excerpt: { contains: query } },
          { content: { contains: query } },
        ],
      },
      include: { category: true },
      orderBy: { createdAt: 'desc' },
      take: 20,
    })

    return NextResponse.json({ posts })
  } catch (error) {
    console.error('GET /api/search error:', error)
    return NextResponse.json({ error: 'Search failed' }, { status: 500 })
  }
}
