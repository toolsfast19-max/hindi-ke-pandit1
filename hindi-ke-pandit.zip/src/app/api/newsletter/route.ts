import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'

export async function POST(request: NextRequest) {
  try {
    const body = await request.json()
    const { email } = body

    if (!email) {
      return NextResponse.json({ error: 'Email is required' }, { status: 400 })
    }

    const existing = await db.newsletter.findUnique({ where: { email } })
    if (existing) {
      return NextResponse.json({ message: 'Already subscribed!' })
    }

    await db.newsletter.create({ data: { email } })
    return NextResponse.json({ message: 'Successfully subscribed!' }, { status: 201 })
  } catch (error) {
    console.error('POST /api/newsletter error:', error)
    return NextResponse.json({ error: 'Failed to subscribe' }, { status: 500 })
  }
}

export async function GET() {
  try {
    const subscribers = await db.newsletter.findMany({
      orderBy: { createdAt: 'desc' },
    })
    return NextResponse.json({ subscribers })
  } catch (error) {
    return NextResponse.json({ error: 'Failed to fetch subscribers' }, { status: 500 })
  }
}
