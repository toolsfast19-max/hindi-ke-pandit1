import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'

// GET /api/posts?category=slug&featured=true&published=true&page=1&limit=10
export async function GET(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url)
    const category = searchParams.get('category')
    const featured = searchParams.get('featured')
    const published = searchParams.get('published')
    const slug = searchParams.get('slug')
    const page = parseInt(searchParams.get('page') || '1')
    const limit = parseInt(searchParams.get('limit') || '10')

    if (slug) {
      const post = await db.post.findUnique({
        where: { slug },
        include: { category: true, comments: { where: { approved: true } } },
      })
      if (!post) return NextResponse.json({ error: 'Post not found' }, { status: 404 })
      // Increment view count
      await db.post.update({ where: { id: post.id }, data: { viewCount: { increment: 1 } } })
      return NextResponse.json({ post: { ...post, viewCount: post.viewCount + 1 } })
    }

    const where: Record<string, unknown> = {}
    if (category) {
      const cat = await db.category.findUnique({ where: { slug: category } })
      if (cat) where.categoryId = cat.id
    }
    if (featured === 'true') where.featured = true
    if (published !== null) where.published = (published === 'true')

    const [posts, total] = await Promise.all([
      db.post.findMany({
        where,
        include: { category: true },
        orderBy: { createdAt: 'desc' },
        skip: (page - 1) * limit,
        take: limit,
      }),
      db.post.count({ where }),
    ])

    return NextResponse.json({ 
      posts, 
      total, 
      page, 
      limit, 
      totalPages: Math.ceil(total / limit) 
    })
  } catch (error) {
    console.error('GET /api/posts error:', error)
    return NextResponse.json({ error: 'Failed to fetch posts' }, { status: 500 })
  }
}

// POST /api/posts - Create new post
export async function POST(request: NextRequest) {
  try {
    const body = await request.json()
    const { title, slug, excerpt, content, coverImage, published, featured, categoryId } = body

    if (!title || !slug || !categoryId) {
      return NextResponse.json({ error: 'Title, slug, and categoryId are required' }, { status: 400 })
    }

    const post = await db.post.create({
      data: {
        title,
        slug,
        excerpt: excerpt || '',
        content: content || '',
        coverImage: coverImage || '',
        published: published ?? false,
        featured: featured ?? false,
        categoryId,
      },
    })

    return NextResponse.json({ post }, { status: 201 })
  } catch (error) {
    console.error('POST /api/posts error:', error)
    return NextResponse.json({ error: 'Failed to create post' }, { status: 500 })
  }
}

// PUT /api/posts?id=xxx - Update post
export async function PUT(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url)
    const id = searchParams.get('id')
    if (!id) return NextResponse.json({ error: 'Post ID required' }, { status: 400 })

    const body = await request.json()
    const post = await db.post.update({
      where: { id },
      data: body,
    })

    return NextResponse.json({ post })
  } catch (error) {
    console.error('PUT /api/posts error:', error)
    return NextResponse.json({ error: 'Failed to update post' }, { status: 500 })
  }
}

// DELETE /api/posts?id=xxx
export async function DELETE(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url)
    const id = searchParams.get('id')
    if (!id) return NextResponse.json({ error: 'Post ID required' }, { status: 400 })

    await db.post.delete({ where: { id } })
    return NextResponse.json({ success: true })
  } catch (error) {
    console.error('DELETE /api/posts error:', error)
    return NextResponse.json({ error: 'Failed to delete post' }, { status: 500 })
  }
}
