import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'

export async function GET(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url)
    const postId = searchParams.get('postId')
    const approved = searchParams.get('approved')

    const where: Record<string, unknown> = {}
    if (postId) where.postId = postId
    if (approved !== null) where.approved = (approved === 'true')

    const comments = await db.comment.findMany({
      where,
      orderBy: { createdAt: 'desc' },
      take: 50,
    })

    return NextResponse.json({ comments })
  } catch (error) {
    console.error('GET /api/comments error:', error)
    return NextResponse.json({ error: 'Failed to fetch comments' }, { status: 500 })
  }
}

export async function POST(request: NextRequest) {
  try {
    const body = await request.json()
    const { name, email, content, postId } = body

    if (!name || !email || !content || !postId) {
      return NextResponse.json({ error: 'All fields are required' }, { status: 400 })
    }

    const comment = await db.comment.create({
      data: { name, email, content, postId },
    })

    return NextResponse.json({ comment }, { status: 201 })
  } catch (error) {
    console.error('POST /api/comments error:', error)
    return NextResponse.json({ error: 'Failed to create comment' }, { status: 500 })
  }
}

export async function PUT(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url)
    const id = searchParams.get('id')
    if (!id) return NextResponse.json({ error: 'Comment ID required' }, { status: 400 })

    const body = await request.json()
    const comment = await db.comment.update({ where: { id }, data: body })
    return NextResponse.json({ comment })
  } catch (error) {
    console.error('PUT /api/comments error:', error)
    return NextResponse.json({ error: 'Failed to update comment' }, { status: 500 })
  }
}

export async function DELETE(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url)
    const id = searchParams.get('id')
    if (!id) return NextResponse.json({ error: 'Comment ID required' }, { status: 400 })

    await db.comment.delete({ where: { id } })
    return NextResponse.json({ success: true })
  } catch (error) {
    console.error('DELETE /api/comments error:', error)
    return NextResponse.json({ error: 'Failed to delete comment' }, { status: 500 })
  }
}
