import { NextResponse } from 'next/server'
import { db } from '@/lib/db'

export async function GET() {
  try {
    const [totalPosts, publishedPosts, draftPosts, totalComments, pendingComments, totalSubscribers, totalViews] = await Promise.all([
      db.post.count(),
      db.post.count({ where: { published: true } }),
      db.post.count({ where: { published: false } }),
      db.comment.count(),
      db.comment.count({ where: { approved: false } }),
      db.newsletter.count(),
      db.post.aggregate({ _sum: { viewCount: true } }),
    ])

    const recentPosts = await db.post.findMany({
      include: { category: true },
      orderBy: { createdAt: 'desc' },
      take: 5,
    })

    const recentComments = await db.comment.findMany({
      orderBy: { createdAt: 'desc' },
      take: 5,
    })

    const unreadMessages = await db.contactMessage.count({ where: { read: false } })

    return NextResponse.json({
      stats: {
        totalPosts,
        publishedPosts,
        draftPosts,
        totalComments,
        pendingComments,
        totalSubscribers,
        totalViews: totalViews._sum.viewCount || 0,
        unreadMessages,
      },
      recentPosts,
      recentComments,
    })
  } catch (error) {
    console.error('GET /api/dashboard error:', error)
    return NextResponse.json({ error: 'Failed to fetch dashboard data' }, { status: 500 })
  }
}
