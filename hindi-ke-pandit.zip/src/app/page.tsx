'use client'

import React from 'react'
import { Header } from '@/components/layout/header'
import { Footer } from '@/components/layout/footer'
import { SearchDialog } from '@/components/shared/search-dialog'
import { AdminSidebar } from '@/components/shared/admin-sidebar'
import { ReadingProgress } from '@/components/shared/reading-progress'
import { useAppStore } from '@/store'
import { HomePage } from '@/components/pages/home-page'
import { CategoryPage } from '@/components/pages/category-page'
import { PostPage } from '@/components/pages/post-page'
import { AboutPage } from '@/components/pages/about-page'
import { ContactPage } from '@/components/pages/contact-page'
import { PrivacyPage } from '@/components/pages/privacy-page'
import { TermsPage } from '@/components/pages/terms-page'
import { DisclaimerPage } from '@/components/pages/disclaimer-page'
import { NotFoundPage } from '@/components/pages/not-found-page'
import { SearchPage } from '@/components/pages/search-page'
import { AdminDashboard } from '@/components/admin/admin-dashboard'

export default function Home() {
  const { currentPage } = useAppStore()

  const renderPage = () => {
    switch (currentPage) {
      case 'home':
        return <HomePage />
      case 'category':
        return <CategoryPage />
      case 'post':
        return <PostPage />
      case 'about':
        return <AboutPage />
      case 'contact':
        return <ContactPage />
      case 'privacy':
        return <PrivacyPage />
      case 'terms':
        return <TermsPage />
      case 'disclaimer':
        return <DisclaimerPage />
      case 'search':
        return <SearchPage />
      case 'admin':
        return <AdminDashboard />
      case '404':
        return <NotFoundPage />
      default:
        return <HomePage />
    }
  }

  return (
    <div className="flex min-h-screen flex-col bg-background">
      <ReadingProgress />
      <Header />
      <SearchDialog />
      <AdminSidebar />

      <main className="flex-1">
        {renderPage()}
      </main>

      <Footer />
    </div>
  )
}
