import type { Metadata } from "next";
import { Geist, Geist_Mono } from "next/font/google";
import "./globals.css";
import { Toaster } from "@/components/ui/sonner";
import { ThemeProvider } from "@/components/layout/theme-provider";
import { Providers } from "@/components/providers";

const geistSans = Geist({
  variable: "--font-geist-sans",
  subsets: ["latin"],
});

const geistMono = Geist_Mono({
  variable: "--font-geist-mono",
  subsets: ["latin"],
});

export const metadata: Metadata = {
  title: "हिंदी के पंडित - शेयर मार्केट, कृषि और टेक्नोलॉजी की जानकारी",
  description: "हिंदी में शेयर मार्केट, कृषि, टेक्नोलॉजी की नवीनतम जानकारी। निवेश टिप्स, सरकारी योजनाएं, AI और तकनीक अपडेट।",
  keywords: "हिंदी ब्लॉग, शेयर मार्केट, कृषि, टेक्नोलॉजी, AI, निवेश, जैविक खेती",
  authors: [{ name: "हिंदी के पंडित" }],
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="hi" suppressHydrationWarning>
      <body
        className={`${geistSans.variable} ${geistMono.variable} antialiased bg-background text-foreground`}
      >
        <ThemeProvider
          attribute="class"
          defaultTheme="light"
          enableSystem
          disableTransitionOnChange
        >
          <Providers>
            {children}
            <Toaster position="top-center" richColors />
          </Providers>
        </ThemeProvider>
      </body>
    </html>
  );
}
