import { db } from '../src/lib/db'

async function main() {
  console.log('🌱 Seeding database...')

  // Clean existing data
  await db.comment.deleteMany()
  await db.post.deleteMany()
  await db.category.deleteMany()
  await db.newsletter.deleteMany()
  await db.contactMessage.deleteMany()

  // Create Categories
  const shareMarket = await db.category.create({
    data: {
      name: 'Share Market',
      nameHindi: 'शेयर मार्केट',
      slug: 'share-market',
      description: 'शेयर बाजार की नवीनतम जानकारी, IPO अपडेट, निवेश टिप्स और ट्रेडिंग स्ट्रैटेजी हिंदी में।',
      icon: 'TrendingUp',
      color: '#16a34a',
    },
  })

  const krishi = await db.category.create({
    data: {
      name: 'Agriculture',
      nameHindi: 'कृषि',
      slug: 'krishi',
      description: 'आधुनिक कृषि तकनीक, जैविक खेती, सरकारी योजनाएं और किसानों के लिए उपयोगी जानकारी।',
      icon: 'Wheat',
      color: '#ca8a04',
    },
  })

  const technology = await db.category.create({
    data: {
      name: 'Technology',
      nameHindi: 'टेक्नोलॉजी',
      slug: 'technology',
      description: 'AI, स्मार्टफोन, 5G, साइबर सुरक्षा और तकनीक की दुनिया की ताज़ा खबरें हिंदी में।',
      icon: 'Cpu',
      color: '#0891b2',
    },
  })

  console.log('✅ Categories created')

  // Create Posts - Share Market
  const shareMarketPosts = [
    {
      title: 'शेयर मार्केट क्या है? बिगिनर्स के लिए पूरी गाइड',
      slug: 'share-market-kya-hai',
      excerpt: 'शेयर मार्केट की बेसिक्स समझें - क्या होता है शेयर, कैसे काम करता है स्टॉक एक्सचेंज, और निवेश कैसे शुरू करें।',
      content: `## शेयर मार्केट क्या है?

शेयर मार्केट एक ऐसी जगह है जहाँ कंपनियों के शेयर (हिस्से) खरीदे और बेचे जाते हैं। जब आप किसी कंपनी का शेयर खरीदते हैं, तो आप उस कंपनी के एक हिस्से के मालिक बन जाते हैं।

### शेयर मार्केट के प्रकार

1. **प्राइमरी मार्केट** - जब कोई कंपनी पहली बार अपने शेयर जनता को बेचती है (IPO)
2. **सेकेंडरी मार्केट** - जहाँ पहले से खरीदे गए शेयरों का ट्रेडिंग होता है

### भारत के प्रमुख स्टॉक एक्सचेंज

- **BSE** (बॉम्बे स्टॉक एक्सचेंज) - 1875 में स्थापित
- **NSE** (नेशनल स्टॉक एक्सचेंज) - 1992 में स्थापित

### शेयर मार्केट में निवेश कैसे शुरू करें?

1. **DMAT खाता खुलवाएं** - Zerodha, Groww, Angel One जैसे ब्रोकर से
2. **PAN कार्ड** - ज़रूरी दस्तावेज़
3. **बैंक खाता** - लिंक्ड बैंक खाता
4. **शुरुआती निवेश** - ₹500 से भी शुरू कर सकते हैं

> 💡 **टिप:** हमेशा उन कंपनियों में निवेश करें जिनकी फंडामेंटल मजबूत हो।

### निष्कर्ष

शेयर मार्केट में निवेश एक अच्छा तरीका है अपनी सेविंग्स को बढ़ाने का। लेकिन सावधानी बरतें और अच्छी रिसर्च करें।`,
      coverImage: 'https://images.unsplash.com/photo-1611974789855-9c2a0a7236a3?w=800',
      published: true,
      featured: true,
    },
    {
      title: 'IPO क्या है? 2024 में आने वाले IPO की पूरी जानकारी',
      slug: 'ipo-kya-hai-2024',
      excerpt: 'IPO (Initial Public Offering) क्या होता है, कैसे अप्लाई करें, और 2024 में कौन से IPO आ रहे हैं।',
      content: `## IPO क्या है?

IPO यानी Initial Public Offering - जब कोई कंपनी पहली बार अपने शेयर स्टॉक मार्केट में लिस्ट कराती है।

### IPO में निवेश के फायदे

1. **शुरुआती मूल्य** पर मिलते हैं शेयर
2. **लिस्टिंग गेन** का मौका
3. **लंबी अवधि** में अच्छा रिटर्न

### IPO कैसे अप्लाई करें?

1. UPI आधारित ऑनलाइन अप्लीकेशन
2. ब्रोकर प्लेटफॉर्म से अप्लाई
3. ASBA के जरिए बैंक से

> ⚠️ IPO निवेश में भी जोखिम होता है। हमेशा RHP पढ़ें।`,
      coverImage: 'https://images.unsplash.com/photo-1590283603385-17ffb3a7f29f?w=800',
      published: true,
      featured: true,
    },
    {
      title: 'टेक्निकल एनालिसिस क्या है? पूरी जानकारी हिंदी में',
      slug: 'technical-analysis-kya-hai',
      excerpt: 'कैंडलस्टिक पैटर्न, मूविंग एवरेज, RSI और अन्य टेक्निकल इंडिकेटर्स के बारे में विस्तार से जानें।',
      content: `## टेक्निकल एनालिसिस क्या है?

टेक्निकल एनालिसिस एक ऐसी विधि है जिसमें पिछले प्राइस डेटा और वॉल्यूम के आधार पर भविष्य की कीमतों का अनुमान लगाया जाता है।

### प्रमुख टेक्निकल इंडिकेटर्स

1. **मूविंग एवरेज (MA)** - प्राइस ट्रेंड दिखाता है
2. **RSI (Relative Strength Index)** - ओवरबॉट/ओवरसोल्ड स्थिति
3. **MACD** - ट्रेंड की दिशा और ताकत
4. **बोलिंजर बैंड्स** - वॉलेटिलिटी का अनुमान

### कैंडलस्टिक पैटर्न

- **हैमर** - बुलिश रिवर्सल
- **डोजी** - अनिश्चितता
- **एंगलिफिंग** - बियरिश रिवर्सल`,
      coverImage: 'https://images.unsplash.com/photo-1642790106117-e829e14a795f?w=800',
      published: true,
      featured: false,
    },
    {
      title: 'म्यूचुअल फंड vs FD: कहाँ निवेश करें?',
      slug: 'mutual-fund-vs-fd',
      excerpt: 'म्यूचुअल फंड और फिक्स्ड डिपॉजिट में क्या अंतर है? कौन सा बेहतर है? पूरी तुलना पढ़ें।',
      content: `## म्यूचुअल फंड vs FD

दोनों अपने-अपने में बेहतर हैं। आइए जानते हैं तुलना:

### रिटर्न
- **म्यूचुअल फंड:** 12-18% (औसत)
- **FD:** 6-7% (औसत)

### जोखिम
- **म्यूचुअल फंड:** मार्केट जोखिम
- **FD:** लगभग शून्य

### लिक्विडिटी
- **म्यूचुअल फंड:** कुछ दिन
- **FD:** लॉक-इन पीरियड

> 💡 सलाह: पोर्टफोलियो में दोनों का मिश्रण रखें।`,
      coverImage: 'https://images.unsplash.com/photo-1554224155-6726b3ff858f?w=800',
      published: true,
      featured: false,
    },
    {
      title: 'टॉप 10 शेयर जो 2024 में बहुत पैसा दे सकते हैं',
      slug: 'top-10-shares-2024',
      excerpt: '2024 में निवेश के लिए बेस्ट शेयर्स की लिस्ट। फंडामेंटल एनालिसिस के आधार पर चुने गए शेयर्स।',
      content: `## टॉप 10 शेयर्स 2024

ये शेयर्स मजबूत फंडामेंटल्स के आधार पर चुने गए हैं।

1. **Reliance Industries** - डायवर्सिफाइड बिजनेस
2. **TCS** - IT सेक्टर का लीडर
3. **HDFC Bank** - बैंकिंग सेक्टर
4. **Infosys** - IT सर्विसेज
5. **Bharti Airtel** - टेलीकॉम

> ⚠️ यह निवेश सलाह नहीं है। खुद रिसर्च करें।`,
      coverImage: 'https://images.unsplash.com/photo-1611974789855-9c2a0a7236a3?w=800',
      published: true,
      featured: true,
    },
  ]

  const krishiPosts = [
    {
      title: 'जैविक खेती क्या है? पूरी जानकारी हिंदी में',
      slug: 'jaivik-kheti-kya-hai',
      excerpt: 'ऑर्गेनिक फार्मिंग की पूरी गाइड - फायदे, तरीके, सरकारी मदद और शुरुआत कैसे करें।',
      content: `## जैविक खेती क्या है?

जैविक खेती वह खेती है जिसमें कोई भी केमिकल फर्टिलाइजर या पेस्टिसाइड का उपयोग नहीं किया जाता।

### जैविक खेती के फायदे

1. **सेहत** के लिए अच्छा
2. **मिट्टी** की गुणवत्ता बढ़ती है
3. **पर्यावरण** को कोई नुकसान नहीं
4. **अच्छी कीमत** मिलती है बाज़ार में

### जैविक खेती कैसे शुरू करें?

1. मिट्टी की जांच कराएं
2. गोबर खाद और वर्मीकम्पोस्ट तैयार करें
3. प्राकृतिक सीड चुनें
4. नीम का तेल, तुलसी स्प्रे का उपयोग करें

> 💡 सरकार जैविक खेती पर ₹50,000 तक की सब्सिडी देती है।`,
      coverImage: 'https://images.unsplash.com/photo-1500937386664-56d1dfef3854?w=800',
      published: true,
      featured: true,
    },
    {
      title: 'PM-KISAN योजना: ₹6000 हर साल किसानों को',
      slug: 'pm-kisan-yojana',
      excerpt: 'प्रधानमंत्री किसान सम्मान निधि योजना की पूरी जानकारी - पात्रता, आवेदन, लाभ।',
      content: `## PM-KISAN योजना

प्रधानमंत्री किसान सम्मान निधि योजना केंद्र सरकार की एक महत्वपूर्ण योजना है।

### योजना के फायदे
- हर साल ₹6000 (₹2000 x 3 किस्त)
- सीधे बैंक खाते में

### पात्रता
- 2 हेक्टेयर तक भूमि वाले किसान
- भूमिहीन कृषि मजदूर
- पशुपालक भी आवेदन कर सकते हैं

### आवेदन कैसे करें?
1. pmkisan.gov.in पर जाएं
2. नया आवेदन पर क्लिक करें
3. आधार, बैंक डिटेल्स भरें
4. सबमिट करें`,
      coverImage: 'https://images.unsplash.com/photo-1574943320219-553eb213f72d?w=800',
      published: true,
      featured: true,
    },
    {
      title: 'मंडी भाव आज: ताज़ा मंडी रेट्स',
      slug: 'mandi-bhav-aaj',
      excerpt: 'आज के ताज़ा मंडी भाव - गेहूं, चावल, सरसों, धान और अन्य फसलों के भाव।',
      content: `## आज के मंडी भाव

प्रमुख फसलों के ताज़ा मंडी भाव:

### गेहूं
- **लखनऊ:** ₹2,200-2,400/क्विंटल
- **दिल्ली:** ₹2,300-2,500/क्विंटल
- **जयपुर:** ₹2,100-2,300/क्विंटल

### चावल
- **लखनऊ:** ₹3,000-3,500/क्विंटल
- **पटना:** ₹2,800-3,200/क्विंटल

> ⚠️ भाव हर दिन बदलते हैं। अपडेट के लिए विजिट करें।`,
      coverImage: 'https://images.unsplash.com/photo-1625246333195-78d9c38ad449?w=800',
      published: true,
      featured: false,
    },
    {
      title: 'सिंचाई की आधुनिक तकनीक: ड्रिप और स्प्रिंकलर',
      slug: 'sinchai-ki-takneek',
      excerpt: 'ड्रिप इरिगेशन और स्प्रिंकलर सिस्टम के बारे में पूरी जानकारी - फायदे, लागत, सरकारी सब्सिडी।',
      content: `## आधुनिक सिंचाई तकनीक

पानी की बचत और बेहतर उपज के लिए आधुनिक सिंचाई ज़रूरी है।

### ड्रिप इरिगेशन
- पानी की 60-70% बचत
- सीधे पौधों की जड़ तक पानी
- ₹30,000-50,000 प्रति एकड़

### स्प्रिंकलर सिस्टम
- बड़े क्षेत्र में आसान
- पानी की 40-50% बचत
- ₹20,000-40,000 प्रति एकड़

> 💡 सरकार माइक्रो इरिगेशन पर 55% सब्सिडी देती है।`,
      coverImage: 'https://images.unsplash.com/photo-1416879595882-3373a0480b5b?w=800',
      published: true,
      featured: false,
    },
    {
      title: 'सब्जी खेती: घर पर ही कमाई का ज़रिया',
      slug: 'sabzi-kheti-guide',
      excerpt: 'सब्जी खेती से अच्छी कमाई कैसे करें? टमाटर, मिर्च, बैंगन और अन्य सब्जियों की खेती की पूरी गाइड।',
      content: `## सब्जी खेती से कमाई

सब्जी खेती एक लाभदायक व्यवसाय है।

### सबसे ज़्यादा मुनाफ़ा देने वाली सब्जियां
1. **टमाटर** - ₹30-80/किलो
2. **हरी मिर्च** - ₹50-150/किलो
3. **कैप्सिकम** - ₹40-120/किलो
4. **ब्रोकली** - ₹80-200/किलो

### सब्जी खेती के टिप्स
- मिट्टी की जांच ज़रूर कराएं
- अच्छे बीज चुनें
- सही समय पर सिंचाई करें
- बाज़ार की मांग को देखें`,
      coverImage: 'https://images.unsplash.com/photo-1592841200221-a6898f307baa?w=800',
      published: true,
      featured: true,
    },
  ]

  const techPosts = [
    {
      title: 'AI (आर्टिफिशियल इंटेलिजेंस) क्या है? पूरी जानकारी',
      slug: 'ai-kya-hai',
      excerpt: 'Artificial Intelligence क्या है, कैसे काम करता है, और भविष्य में क्या बदलाव आएंगे? सब कुछ हिंदी में।',
      content: `## AI क्या है?

Artificial Intelligence (AI) यानी कृत्रिम बुद्धिमत्ता - यह कंप्यूटर सिस्टम है जो इंसानों की तरह सोच और काम कर सकता है।

### AI के प्रकार

1. **नैरो AI** - एक ही काम में माहिर (जैसे: चैटजीपीटी)
2. **जनरल AI** - कई काम कर सके (अभी विकास में)
3. **सुपर AI** - इंसान से भी ज़्यादा स्मार्ट (सैद्धांतिक)

### AI के उपयोग

- चैटबॉट्स (ChatGPT, Gemini)
- सेल्फ-ड्राइविंग कारें
- मेडिकल डायग्नोसिस
- वॉयस असिस्टेंट (Siri, Alexa)

> 🚀 भारत AI रिवोल्यूशन में अग्रणी भूमिका निभा रहा है।`,
      coverImage: 'https://images.unsplash.com/photo-1677442136019-21780ecad995?w=800',
      published: true,
      featured: true,
    },
    {
      title: '5G तकनीक क्या है? भारत में 5G कैसे काम करता है',
      slug: '5g-technology-hindi',
      excerpt: '5G नेटवर्क की पूरी जानकारी - स्पीड, फायदे, डिवाइस और भारत में 5G रोलआउट।',
      content: `## 5G क्या है?

5G (5th Generation) मोबाइल नेटवर्क की पांचवीं पीढ़ी है। यह 4G से 100 गुना तेज़ है।

### 5G के फायदे
- **स्पीड:** 1-10 Gbps
- **लेटेंसी:** 1 मिलीसेकंड
- **कनेक्टिविटी:** 10 लाख डिवाइस/किमी²

### भारत में 5G
- Jio और Airtel ने 5G लॉन्च किया
- 2025 तक पूरे भारत में कवरेज
- 5G फोन: ₹15,000 से शुरू`,
      coverImage: 'https://images.unsplash.com/photo-1562408590-e32931084e23?w=800',
      published: true,
      featured: true,
    },
    {
      title: 'साइबर सुरक्षा: अपने फोन और कंप्यूटर को सुरक्षित कैसे रखें?',
      slug: 'cyber-security-guide',
      excerpt: 'साइबर क्राइम से बचाव के तरीके - फिशिंग, हैकिंग, वायरस से कैसे बचें। सुरक्षा टिप्स हिंदी में।',
      content: `## साइबर सुरक्षा गाइड

डिजिटल दुनिया में सुरक्षा बहुत ज़रूरी है।

### साइबर अटैक के प्रकार
1. **फिशिंग** - नकली ईमेल/वेबसाइट
2. **मैलवेयर** - हानिकारक सॉफ्टवेयर
3. **रैंसमवेयर** - डेटा लॉक करना
4. **सोशल इंजीनियरिंग** - भरोसा जीतना

### सुरक्षा टिप्स
- बल्कि पासवर्ड रखें
- 2FA चालू करें
- अनजान लिंक पर क्लिक न करें
- सॉफ्टवेयर अपडेट रखें`,
      coverImage: 'https://images.unsplash.com/photo-1550751827-4bd374c3f58b?w=800',
      published: true,
      featured: false,
    },
    {
      title: '2024 के बेस्ट स्मार्टफोन्स: ₹10,000 से ₹50,000',
      slug: 'best-smartphones-2024',
      excerpt: '2024 में बेस्ट स्मार्टफोन लिस्ट - बजट से प्रीमियम तक। कैमरा, बैटरी, परफॉर्मेंस की पूरी जानकारी।',
      content: `## 2024 के बेस्ट स्मार्टफोन्स

### ₹10,000-20,000
- **Redmi Note 13 Pro** - 108MP कैमरा
- **Realme 12** - AMOLED डिस्प्ले
- **Samsung M14** - 6000mAh बैटरी

### ₹20,000-35,000
- **OnePlus Nord 3** - फ्लैगशिप परफॉर्मेंस
- **Pixel 7a** - बेस्ट कैमरा
- **Nothing Phone 2** - यूनिक डिज़ाइन

### ₹35,000-50,000
- **Samsung S23 FE** - प्रीमियम एक्सपीरियंस
- **iPhone 13** - iOS एक्सपीरियंस
- **OnePlus 11R** - गेमिंग बीस्ट`,
      coverImage: 'https://images.unsplash.com/photo-1511707171634-5f897ff02aa9?w=800',
      published: true,
      featured: false,
    },
    {
      title: 'ChatGPT क्या है? AI चैटबॉट की पूरी जानकारी',
      slug: 'chatgpt-kya-hai',
      excerpt: 'OpenAI का ChatGPT क्या है, कैसे काम करता है, और इसे कैसे इस्तेमाल करें? हिंदी में पूरी गाइड।',
      content: `## ChatGPT क्या है?

ChatGPT OpenAI का AI चैटबॉट है जो आपसे बातचीत कर सकता है।

### ChatGPT के फीचर्स
- किसी भी विषय पर जानकारी
- कोड लिखना
- लेख और कहानियां लिखना
- प्रोग्रामिंग में मदद

### कैसे इस्तेमाल करें?
1. chat.openai.com पर जाएं
2. फ्री अकाउंट बनाएं
3. अपना सवाल पूछें

> 🤖 ChatGPT ने दुनिया बदल दी है।`,
      coverImage: 'https://images.unsplash.com/photo-1684487747720-1ba29cda82c8?w=800',
      published: true,
      featured: true,
    },
  ]

  // Create all posts
  for (const post of shareMarketPosts) {
    await db.post.create({ data: { ...post, categoryId: shareMarket.id } })
  }
  for (const post of krishiPosts) {
    await db.post.create({ data: { ...post, categoryId: krishi.id } })
  }
  for (const post of techPosts) {
    await db.post.create({ data: { ...post, categoryId: technology.id } })
  }

  console.log('✅ Posts created')

  // Create some comments
  const posts = await db.post.findMany({ take: 3 })
  for (const post of posts) {
    await db.comment.create({
      data: {
        name: 'राहुल कुमार',
        email: 'rahul@example.com',
        content: 'बहुत अच्छा लेख है! इस तरह की और जानकारी दें।',
        postId: post.id,
        approved: true,
      },
    })
    await db.comment.create({
      data: {
        name: 'प्रिया सिंह',
        email: 'priya@example.com',
        content: 'धन्यवाद, बहुत हेल्पफुल जानकारी थी।',
        postId: post.id,
        approved: true,
      },
    })
  }

  console.log('✅ Comments created')

  // Create newsletter subscribers
  await db.newsletter.createMany({
    data: [
      { email: 'rahul@example.com' },
      { email: 'priya@example.com' },
      { email: 'amit@example.com' },
      { email: 'suman@example.com' },
      { email: 'vijay@example.com' },
    ],
  })

  console.log('✅ Newsletter subscribers created')

  // Create contact messages
  await db.contactMessage.create({
    data: {
      name: 'अशोक यादव',
      email: 'ashok@example.com',
      subject: 'शेयर मार्केट के बारे में',
      message: 'मुझे शेयर मार्केट में निवेश के बारे में जानकारी चाहिए।',
    },
  })

  console.log('✅ Contact message created')
  console.log('🎉 Database seeded successfully!')
}

main()
  .catch(console.error)
  .finally(() => db.$disconnect())
