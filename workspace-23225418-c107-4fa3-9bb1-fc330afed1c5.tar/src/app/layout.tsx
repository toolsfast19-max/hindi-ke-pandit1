import type { Metadata } from "next";
import { Geist, Geist_Mono } from "next/font/google";
import "./globals.css";
import { Toaster } from "@/components/ui/toaster";

const geistSans = Geist({
  variable: "--font-geist-sans",
  subsets: ["latin"],
});

const geistMono = Geist_Mono({
  variable: "--font-geist-mono",
  subsets: ["latin"],
});

export const metadata: Metadata = {
  title: "Shrinath Chanakya Coaching Classes - Online Test System",
  description: "Online Examination System for Shrinath Chanakya Coaching, Pune. Take online tests, get instant results with detailed analysis.",
  keywords: ["Shrinath Chanakya", "Coaching", "Online Test", "Pune", "Education"],
  authors: [{ name: "Sasane Sir & Shinde Sir" }],
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="en" suppressHydrationWarning>
      <body
        className={`${geistSans.variable} ${geistMono.variable} antialiased bg-background text-foreground`}
      >
        {children}
        <Toaster />
      </body>
    </html>
  );
}
