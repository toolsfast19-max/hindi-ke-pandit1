import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';

export async function GET(
  request: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const { id } = await params;
    const test = await db.test.findUnique({
      where: { id: parseInt(id) },
      include: {
        questions: true,
        _count: { select: { results: true } },
      },
    });

    if (!test) {
      return NextResponse.json({ success: false, message: 'Test not found' }, { status: 404 });
    }

    return NextResponse.json({ success: true, test });
  } catch {
    return NextResponse.json({ success: false, message: 'Server error' }, { status: 500 });
  }
}

export async function PUT(
  request: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const { id } = await params;
    const data = await request.json();

    const test = await db.test.update({
      where: { id: parseInt(id) },
      data: {
        title: data.title,
        description: data.description,
        duration: data.duration,
        marks_per_question: data.marks_per_question,
        class_for: data.class_for,
      },
    });

    return NextResponse.json({ success: true, test });
  } catch {
    return NextResponse.json({ success: false, message: 'Server error' }, { status: 500 });
  }
}

export async function DELETE(
  request: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const { id } = await params;

    // Delete questions first
    await db.question.deleteMany({ where: { test_id: parseInt(id) } });
    // Delete results
    await db.result.deleteMany({ where: { test_id: parseInt(id) } });
    // Delete test
    await db.test.delete({ where: { id: parseInt(id) } });

    return NextResponse.json({ success: true, message: 'Test deleted' });
  } catch {
    return NextResponse.json({ success: false, message: 'Server error' }, { status: 500 });
  }
}
