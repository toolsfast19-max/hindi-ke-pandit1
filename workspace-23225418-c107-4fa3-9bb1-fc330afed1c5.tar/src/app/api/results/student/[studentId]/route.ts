import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';

export async function GET(
  request: NextRequest,
  { params }: { params: Promise<{ studentId: string }> }
) {
  try {
    const { studentId } = await params;
    const results = await db.result.findMany({
      where: { student_id: parseInt(studentId) },
      include: { test: true },
      orderBy: { submitted_at: 'desc' },
    });

    // Parse answers JSON for each result
    const parsedResults = results.map(r => ({
      ...r,
      answers: JSON.parse(r.answers),
    }));

    return NextResponse.json({ success: true, results: parsedResults });
  } catch {
    return NextResponse.json({ success: false, message: 'Server error' }, { status: 500 });
  }
}
