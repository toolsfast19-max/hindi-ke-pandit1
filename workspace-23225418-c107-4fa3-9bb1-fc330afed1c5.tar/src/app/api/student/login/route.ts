import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';

export async function POST(request: NextRequest) {
  try {
    const { student_id, password } = await request.json();

    if (!student_id || !password) {
      return NextResponse.json({ success: false, message: 'Student ID and password are required' }, { status: 400 });
    }

    const student = await db.student.findFirst({
      where: {
        OR: [
          { student_id: student_id },
          { email: student_id },
        ],
      },
    });

    if (!student) {
      return NextResponse.json({ success: false, message: 'Invalid Student ID or password' }, { status: 401 });
    }

    if (password !== student.password) {
      return NextResponse.json({ success: false, message: 'Invalid Student ID or password' }, { status: 401 });
    }

    await db.student.update({
      where: { id: student.id },
      data: { lastLogin: new Date() },
    });

    return NextResponse.json({
      success: true,
      student: {
        id: student.id,
        student_id: student.student_id,
        name: student.name,
        email: student.email,
        roll_number: student.roll_number,
        photo: student.photo,
        class: student.class,
        mobile: student.mobile,
        password: student.password,
      },
      token: btoa(`${student.student_id}:${Date.now()}`),
    });
  } catch {
    return NextResponse.json({ success: false, message: 'Server error' }, { status: 500 });
  }
}
