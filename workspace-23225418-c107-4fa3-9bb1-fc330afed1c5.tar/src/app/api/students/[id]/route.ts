import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';

export async function GET(
  request: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const { id } = await params;
    const student = await db.student.findUnique({
      where: { id: parseInt(id) },
      include: { results: { include: { test: true }, orderBy: { submitted_at: 'desc' } } },
    });
    if (!student) {
      return NextResponse.json({ success: false, message: 'Student not found' }, { status: 404 });
    }
    return NextResponse.json({ success: true, student });
  } catch {
    return NextResponse.json({ success: false, message: 'Server error' }, { status: 500 });
  }
}

export async function PUT(
  request: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const { id } = await params;
    const data = await request.json();
    const updateData: Record<string, string> = {};
    if (data.name) updateData.name = data.name;
    if (data.email) updateData.email = data.email;
    if (data.roll_number) updateData.roll_number = data.roll_number;
    if (data.class) updateData.class = data.class;
    if (data.mobile) updateData.mobile = data.mobile;
    if (data.photo) updateData.photo = data.photo;
    if (data.password && data.password.trim()) updateData.password = data.password;

    const student = await db.student.update({
      where: { id: parseInt(id) },
      data: updateData,
    });
    return NextResponse.json({ success: true, student });
  } catch (error: unknown) {
    const err = error as { code?: string };
    if (err.code === 'P2002') {
      return NextResponse.json({ success: false, message: 'Student ID or Email already exists' }, { status: 400 });
    }
    return NextResponse.json({ success: false, message: 'Server error' }, { status: 500 });
  }
}

export async function DELETE(
  request: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const { id } = await params;
    await db.result.deleteMany({ where: { student_id: parseInt(id) } });
    await db.student.delete({ where: { id: parseInt(id) } });
    return NextResponse.json({ success: true, message: 'Student deleted' });
  } catch {
    return NextResponse.json({ success: false, message: 'Server error' }, { status: 500 });
  }
}
