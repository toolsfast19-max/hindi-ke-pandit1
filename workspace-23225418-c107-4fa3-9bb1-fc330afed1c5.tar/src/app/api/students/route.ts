import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';

export async function GET() {
  try {
    const students = await db.student.findMany({
      orderBy: { createdAt: 'desc' },
    });
    return NextResponse.json({ success: true, students });
  } catch {
    return NextResponse.json({ success: false, message: 'Server error' }, { status: 500 });
  }
}

export async function POST(request: NextRequest) {
  try {
    const data = await request.json();
    const student = await db.student.create({
      data: {
        student_id: data.student_id,
        roll_number: data.roll_number || '',
        name: data.name,
        email: data.email,
        password: data.password || 'student123',
        photo: data.photo || 'default.jpg',
        class: data.class || '10th',
        mobile: data.mobile || '',
      },
    });
    return NextResponse.json({ success: true, student });
  } catch (error: unknown) {
    const err = error as { code?: string };
    if (err.code === 'P2002') {
      return NextResponse.json({ success: false, message: 'Student ID or Email already exists' }, { status: 400 });
    }
    return NextResponse.json({ success: false, message: 'Server error' }, { status: 500 });
  }
}
