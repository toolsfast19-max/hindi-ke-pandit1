import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';

export async function POST(request: NextRequest) {
  try {
    const formData = await request.formData();
    const file = formData.get('file') as File | null;
    const title = formData.get('title') as string;
    const description = formData.get('description') as string;
    const duration = parseInt(formData.get('duration') as string) || 30;
    const marks_per_question = parseInt(formData.get('marks_per_question') as string) || 4;
    const class_for = formData.get('class_for') as string || '10th';

    if (!file) {
      return NextResponse.json({ success: false, message: 'No file uploaded' }, { status: 400 });
    }

    const text = await file.text();
    const questions = parseQuestions(text);

    if (questions.length === 0) {
      return NextResponse.json({
        success: false,
        message: 'No valid questions found. Supported formats:\n\nFormat 1 (multi-line):\nQ1. Question text here?\nA) Option A\nB) Option B\nC) Option C\nD) Option D\nAnswer: B\n\nFormat 2 (pipe-separated):\nQuestion | A) opt | B) opt | C) opt | D) opt | B\n\nFormat 3 (numbered):\n1. Question text here?\nA) Option A\nB) Option B\nC) Option C\nD) Option D\nAns: B',
      }, { status: 400 });
    }

    // Create test with questions
    const test = await db.test.create({
      data: {
        title,
        description: description || `Uploaded test with ${questions.length} questions`,
        duration,
        marks_per_question,
        class_for,
        total_questions: questions.length,
      },
    });

    for (const q of questions) {
      await db.question.create({
        data: {
          test_id: test.id,
          question_text: q.question_text,
          option_a: q.option_a,
          option_b: q.option_b,
          option_c: q.option_c,
          option_d: q.option_d,
          correct_answer: q.correct_answer,
        },
      });
    }

    return NextResponse.json({
      success: true,
      test: { ...test, question_count: questions.length },
      message: `Test created with ${questions.length} questions`,
    });
  } catch (error) {
    console.error('Upload test error:', error);
    return NextResponse.json({ success: false, message: 'Server error' }, { status: 500 });
  }
}

function parseQuestions(text: string) {
  const questions: Array<{
    question_text: string;
    option_a: string;
    option_b: string;
    option_c: string;
    option_d: string;
    correct_answer: string;
  }> = [];

  // ── Try pipe-separated format first ──
  // Question | A) opt | B) opt | C) opt | D) opt | B
  const pipeLines = text.split('\n').filter(l => l.trim() && l.includes('|'));
  if (pipeLines.length >= 1) {
    for (const line of pipeLines) {
      const parts = line.split('|').map(p => p.trim());
      if (parts.length >= 6) {
        const qText = parts[0].replace(/^\d+[\.\)]\s*/, '').trim();
        const opts: Record<string, string> = {};
        let ans = '';
        for (let i = 1; i < parts.length; i++) {
          const optMatch = parts[i].match(/^([A-Da-d])[\.\)]\s*(.+)/);
          if (optMatch) {
            opts[optMatch[1].toUpperCase()] = optMatch[2].trim();
          }
        }
        // Last part that is just a single letter = answer
        const lastPart = parts[parts.length - 1].trim();
        if (/^[A-Da-d]$/.test(lastPart)) {
          ans = lastPart.toUpperCase();
        }
        // Also check for "Answer: X" or "Ans: X" in parts
        for (const p of parts) {
          const aMatch = p.match(/(?:answer|ans)\s*[:\-=]\s*([A-Da-d])/i);
          if (aMatch) ans = aMatch[1].toUpperCase();
        }

        if (qText && opts['A'] && opts['B'] && opts['C'] && opts['D'] && ans) {
          questions.push({
            question_text: qText,
            option_a: opts['A'],
            option_b: opts['B'],
            option_c: opts['C'],
            option_d: opts['D'],
            correct_answer: ans,
          });
        }
      }
    }
    if (questions.length > 0) return questions;
  }

  // ── Multi-line format ──
  // Split by question delimiters: "Q1.", "Q2.", "1.", "2.", etc.
  // First, normalize the text
  const normalized = text.replace(/\r\n/g, '\n').replace(/\r/g, '\n');

  // Find all question start positions
  const qPattern = /(?:^|\n)\s*(?:Q\.?\s*(\d+)[\.\:]\s*|(\d+)\s*[\.\)]\s*)/gi;
  const starts: Array<{ pos: number; num: string }> = [];

  let match;
  while ((match = qPattern.exec(normalized)) !== null) {
    starts.push({ pos: match.index + match[0].length, num: match[1] || match[2] || '' });
  }

  if (starts.length === 0) {
    // Try single question - no Q prefix, just options
    const singleQ = parseSingleQuestionBlock(normalized.trim());
    if (singleQ) return [singleQ];
    return [];
  }

  // Extract blocks between question starts
  for (let i = 0; i < starts.length; i++) {
    const blockStart = starts[i].pos;
    const blockEnd = i + 1 < starts.length ? starts[i + 1].pos : normalized.length;
    const block = normalized.substring(blockStart, blockEnd).trim();

    const parsed = parseSingleQuestionBlock(block);
    if (parsed) questions.push(parsed);
  }

  return questions;
}

function parseSingleQuestionBlock(block: string) {
  const lines = block.split('\n').map(l => l.trim()).filter(l => l.length > 0);

  if (lines.length < 5) return null;

  // Extract question text (first line or until we hit an option)
  let questionText = '';
  let optionStartIdx = 0;
  let answer = '';

  // Find where options begin
  for (let i = 0; i < lines.length; i++) {
    const optMatch = lines[i].match(/^[A-Da-d][\.\)]\s*/);
    if (optMatch) {
      optionStartIdx = i;
      break;
    }
    // Check for "Answer:" line before options
    const ansMatch = lines[i].match(/^(?:answer|ans)\s*[:\-=]\s*([A-Da-d])/i);
    if (ansMatch) {
      answer = ansMatch[1].toUpperCase();
      continue;
    }
    if (questionText) questionText += ' ';
    questionText += lines[i];
  }

  if (!questionText || optionStartIdx === 0) return null;

  // Extract options
  const options: Record<string, string> = {};
  for (let i = optionStartIdx; i < lines.length; i++) {
    const optMatch = lines[i].match(/^([A-Da-d])[\.\)]\s*(.+)/);
    if (optMatch) {
      options[optMatch[1].toUpperCase()] = optMatch[2].trim();
    }
    // Check for answer line mixed in with options
    const ansMatch = lines[i].match(/^(?:answer|ans)\s*[:\-=]\s*([A-Da-d])/i);
    if (ansMatch) {
      answer = ansMatch[1].toUpperCase();
    }
  }

  // Also check if answer is in the last line
  const lastLine = lines[lines.length - 1];
  if (!answer) {
    const lastAns = lastLine.match(/^(?:answer|ans)?\s*[:\-=]?\s*([A-Da-d])$/i);
    if (lastAns) answer = lastAns[1].toUpperCase();
  }
  // Check if the last line is just a single letter
  if (!answer && /^[A-Da-d]$/.test(lastLine)) {
    answer = lastLine.toUpperCase();
  }

  if (!options['A'] && !options['B'] && !options['C'] && !options['D']) return null;

  // Allow missing one option but warn
  if (!answer) answer = 'A'; // default fallback

  return {
    question_text: questionText.trim(),
    option_a: options['A'] || '',
    option_b: options['B'] || '',
    option_c: options['C'] || '',
    option_d: options['D'] || '',
    correct_answer: answer,
  };
}
