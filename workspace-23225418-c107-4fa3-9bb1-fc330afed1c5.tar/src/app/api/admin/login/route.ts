import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';

const ADMIN_USERNAME = 'admin';
const ADMIN_PASSWORD = 'admin123';

export async function POST(request: NextRequest) {
  try {
    const { username, password } = await request.json();

    if (username === ADMIN_USERNAME && password === ADMIN_PASSWORD) {
      return NextResponse.json({
        success: true,
        admin: { username: ADMIN_USERNAME, name: 'Administrator' },
        token: btoa(`${ADMIN_USERNAME}:${Date.now()}`),
      });
    }

    return NextResponse.json({ success: false, message: 'Invalid credentials' }, { status: 401 });
  } catch {
    return NextResponse.json({ success: false, message: 'Server error' }, { status: 500 });
  }
}
