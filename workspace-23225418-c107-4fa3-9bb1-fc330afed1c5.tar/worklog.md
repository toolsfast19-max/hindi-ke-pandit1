---
Task ID: 3
Agent: Main Agent
Task: Fix answer evaluation bug and test upload parser

Work Log:
- Analyzed screenshot showing "No valid questions found in the file" error on upload page
- Identified two bugs: (1) Upload parser regex was too fragile and couldn't parse common formats, (2) Answer comparison didn't handle trim/case
- Completely rewrote upload-test parser with robust multi-format support (pipe-separated, multi-line Q1./1. format, single letter answer detection)
- Fixed exam submit to normalize answers with trim+uppercase comparison
- Fixed React lint errors: removed ref access during render, replaced with state-backed answers array
- All lint checks pass with 0 errors

Stage Summary:
- Upload parser now supports: pipe-separated format, multi-line Q1./1. format, "Answer:" / "Ans:" lines
- Answer comparison uses normalized (trimmed, uppercased) strings
- Exam answers tracked via state (not ref) for proper React rendering
